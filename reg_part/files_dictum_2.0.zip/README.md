# MEP Proof of Concept

## What this demonstrates

The full MEP pipeline end-to-end, running locally with zero cloud dependencies:

```
PDF (source)
  ↓  [already extracted]
JSON files (rules + benchmarks)
  ↓  [step 1: load_rules_to_db.py]
SQLite tables (stands in for BigQuery)
  ↓  [step 2: sql_scoring.py]
Scored & aggregated data
  ↓  [step 3: rule_engine.py]
Compliance results
  ↓  [step 4: report]
Console report + CSV
```

## Files

| File | Purpose |
|---|---|
| `run_poc.py` | **Run this.** Single entry point that executes all steps in order. |
| `sample_data.csv` | Simulated day-level aggregated order data with RTH/ETH flags |
| `mep_benchmarks.json` | Extracted from benchmark PDF — product group ratios by tier |
| `mep_rules.json` | Extracted from MEP spec PDF — weights, thresholds, EMT params |
| `mep_logic_rules.json` | Rule catalog — maps every rule to spec section + Python function |
| `load_rules_to_db.py` | Step 1: Reads JSON → inserts into SQLite tables |
| `sql_scoring.py` | Step 2: SQL queries to classify, weight, and aggregate data |
| `rule_engine.py` | Step 3: Python rule logic (exemption waterfall, EMT, etc.) |

## How to run

```bash
cd mep_poc
python3 run_poc.py
```

No installs needed. Uses only Python standard library (sqlite3, json, csv).

## What to look at

1. **JSON → DB**: Open `load_rules_to_db.py` — see how each JSON entry becomes a DB row
2. **SQL scoring**: Open `sql_scoring.py` — see the weight lookup join and aggregation
3. **Rule engine**: Open `rule_engine.py` — each function maps to a rule_id in the catalog
4. **Verification**: The console output shows each step with intermediate values so you
   can hand-check the math against the JSON parameters
