#!/usr/bin/env python3
"""
run_poc.py — MEP Proof of Concept
Runs the full pipeline end-to-end in one command.

Usage:
    python3 run_poc.py

Pipeline:
    Step 1: JSON files  →  SQLite tables     (load_rules_to_db.py)
    Step 2: SQL scoring →  daily_scores       (sql_scoring.py)
    Step 3: Rule engine →  compliance results (rule_engine.py)
    Step 4: Report + verification
"""

import os
import sys
import csv
import json
import sqlite3
from pathlib import Path
from datetime import datetime

# Ensure we're running from the POC directory
HERE = Path(__file__).parent
os.chdir(HERE)

import load_rules_to_db
import sql_scoring
import rule_engine

DB_PATH = HERE / "mep_poc.db"
BENCHMARKS_JSON = HERE / "mep_benchmarks.json"
RULES_JSON = HERE / "mep_rules.json"
LOGIC_CATALOG = HERE / "mep_logic_rules.json"
DATA_CSV = HERE / "sample_data.csv"
OUTPUT_CSV = HERE / "compliance_results.csv"


def banner(step, title):
    print(f"\n{'═'*65}")
    print(f"  Step {step}: {title}")
    print(f"{'═'*65}")


def step_0_show_catalog():
    """Show the rule catalog — this is what connects the PDF to the code."""
    banner("0", "Rule catalog (mep_logic_rules.json)")
    print(f"\n  This catalog maps every MEP rule to its Python function.")
    print(f"  When the spec changes, look up affected rules here.\n")

    with open(LOGIC_CATALOG) as f:
        catalog = json.load(f)

    print(f"  {'rule_id':<20} {'change_type':<15} {'function':<30} {'spec_section'}")
    print(f"  {'─'*20} {'─'*15} {'─'*30} {'─'*25}")

    for r in catalog["rules"]:
        print(f"  {r['rule_id']:<20} {r['change_type']:<15} "
              f"{r['function']:<30} {r['spec_section']}")


def step_1_load():
    """Load JSON → SQLite."""
    banner("1", "Load JSON rules + CSV data → SQLite")

    # Remove old DB for a clean run
    if DB_PATH.exists():
        DB_PATH.unlink()

    print(f"\n  Source files:")
    print(f"    Benchmarks: {BENCHMARKS_JSON.name}")
    print(f"    Rules:      {RULES_JSON.name}")
    print(f"    Data:       {DATA_CSV.name}")
    print(f"    Database:   {DB_PATH.name}\n")

    load_rules_to_db.run(str(DB_PATH), str(BENCHMARKS_JSON),
                         str(RULES_JSON), str(DATA_CSV))


def step_2_score():
    """Run SQL scoring and aggregation."""
    banner("2", "SQL scoring → daily_scores (weighted aggregation)")
    print(f"\n  Joining order_data × message_weights to compute:")
    print(f"    - raw_msg_count  = orders + mods + cancels + eliminations")
    print(f"    - messaging_score = mods×w_mod + cancels×w_can + elim×w_eli")
    print(f"    - Aggregated to GFID × product_group level")

    sql_scoring.run(str(DB_PATH))


def step_3_rules(results_holder):
    """Run Python rule engine."""
    banner("3", "Python rule engine (exemption waterfall)")
    print(f"\n  Applying rules in order:")
    print(f"    1. EXCL-50K:        Is raw msg count ≤ 50,000? → excluded")
    print(f"    2. TIER-ASSIGN:     Which tier? → determines benchmark multiplier")
    print(f"    3. RATIO-CALC:      Volume ratio = score / volume")
    print(f"    4. BREACH-DAILY:    Ratio > effective benchmark? → breach")
    print(f"    5. EXEMPT-6X-BLOCK: Ratio > 6× benchmark? → blocks all waivers")
    print(f"    6. Waterfall:       PASS → 6× surcharge → auto-waiver → potential")

    results = rule_engine.run(str(DB_PATH), str(RULES_JSON))
    results_holder.extend(results)


def step_4_verify(results):
    """Verify results by hand-checking one example."""
    banner("4", "Verification — hand-check one example")

    # Find firm BBB / ZN as our example
    r = next((x for x in results if x.gfid == "BBB" and x.product_group == "ZN"), None)
    if r is None:
        print("  BBB/ZN not found in results")
        return

    print(f"\n  Let's verify firm BBB in product group ZN step by step:\n")

    # Load the weights from DB to show the math
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.cursor()
    rth_row = c.execute("""
        SELECT modifications, cancels, elimination, trade_volume
        FROM order_data WHERE firm='BBB' AND session='RTH'
    """).fetchone()
    eth_row = c.execute("""
        SELECT modifications, cancels, elimination, trade_volume
        FROM order_data WHERE firm='BBB' AND session='ETH'
    """).fetchone()
    conn.close()

    rth_mods, rth_can, rth_eli, rth_vol = rth_row
    eth_mods, eth_can, eth_eli, eth_vol = eth_row

    print(f"  Source data (from CSV):")
    print(f"    RTH: mods={rth_mods}, cancels={rth_can}, elims={rth_eli}, volume={rth_vol}")
    print(f"    ETH: mods={eth_mods}, cancels={eth_can}, elims={eth_eli}, volume={eth_vol}")

    print(f"\n  Weights applied (from mep_rules.json → DB):")
    print(f"    RTH FRONT: mod=1.0, cancel=3.0, elim=3.0")
    print(f"    ETH ALL:   mod=0.1, cancel=0.3, elim=0.3")

    rth_score = rth_mods * 1.0 + rth_can * 3.0 + rth_eli * 3.0
    eth_score = eth_mods * 0.1 + eth_can * 0.3 + eth_eli * 0.3
    total_score = rth_score + eth_score
    total_volume = rth_vol + eth_vol
    raw_total = (rth_mods + rth_can + rth_eli + eth_mods + eth_can + eth_eli
                 + 1000 + 500)  # orders from CSV

    print(f"\n  Hand calculation:")
    print(f"    RTH score = {rth_mods}×1.0 + {rth_can}×3.0 + {rth_eli}×3.0 = {rth_score:.1f}")
    print(f"    ETH score = {eth_mods}×0.1 + {eth_can}×0.3 + {eth_eli}×0.3 = {eth_score:.1f}")
    print(f"    Total score = {rth_score:.1f} + {eth_score:.1f} = {total_score:.1f}")
    print(f"    Total volume = {rth_vol} + {eth_vol} = {total_volume}")
    print(f"    Volume ratio = {total_score:.1f} / {total_volume} = {total_score/total_volume:.1f}")

    print(f"\n  Rule engine produced:")
    print(f"    messaging_score = {r.messaging_score:.1f}")
    print(f"    volume = {r.volume}")
    print(f"    ratio = {r.volume_ratio:.1f}")
    print(f"    effective_benchmark = {r.effective_benchmark:.0f}")
    print(f"    status = {r.status}")

    match = abs(r.messaging_score - total_score) < 0.01
    print(f"\n  ✓ Score matches hand calculation: {match}")

    # Show the rule trace
    print(f"\n  Rule trace for this result:")
    print(f"    EXCL-50K:        raw={r.raw_msg_count:,} > 50,000 → not excluded")
    print(f"    TIER-ASSIGN:     raw={r.raw_msg_count:,} → {r.tier}")
    print(f"    RATIO-CALC:      {r.messaging_score:.1f} / {r.volume} = {r.volume_ratio:.1f}")
    print(f"    BREACH-DAILY:    {r.volume_ratio:.1f} > {r.effective_benchmark:.0f} → {'YES' if r.is_breach else 'NO'}")
    if r.is_breach:
        print(f"    EXEMPT-6X-BLOCK: {r.volume_ratio:.1f} > {6*r.effective_benchmark:.0f} → {'YES' if r.is_6x_breach else 'NO'}")
        print(f"    Waterfall:       → {r.status}")


def step_5_export(results):
    """Export results to CSV and show summary."""
    banner("5", "Export results + summary")

    # Write CSV
    fields = ["gfid", "product_group", "raw_msg_count", "messaging_score",
              "volume", "tier", "effective_benchmark", "volume_ratio",
              "is_breach", "is_6x_breach", "status", "notes"]

    with open(OUTPUT_CSV, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in results:
            writer.writerow({field: getattr(r, field, "") for field in fields})

    print(f"\n  Results written to: {OUTPUT_CSV.name}  ({len(results)} rows)")

    # Summary
    from collections import Counter
    counts = Counter(r.status for r in results)
    print(f"\n  Summary:")
    colors = {"PASS": "\033[92m", "AUTO_WAIVED": "\033[94m",
              "POTENTIAL": "\033[93m", "SURCHARGE_APPLIED": "\033[91m"}
    reset = "\033[0m"
    for status, count in sorted(counts.items()):
        c = colors.get(status, "")
        print(f"    {c}{status}{reset}: {count}")

    print(f"\n  Non-compliant firms:")
    for r in results:
        if r.status not in ("PASS",):
            print(f"    {r.gfid}/{r.product_group}: {r.status}  "
                  f"(ratio={r.volume_ratio:.1f} vs benchmark={r.effective_benchmark:.0f})")


def main():
    started = datetime.now()

    print(f"\n{'━'*65}")
    print(f"  MEP Proof of Concept")
    print(f"  Full pipeline: PDF → JSON → DB → SQL scoring → Rules → Report")
    print(f"  Started: {started.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'━'*65}")

    step_0_show_catalog()

    step_1_load()

    step_2_score()

    results = []
    step_3_rules(results)

    step_4_verify(results)

    step_5_export(results)

    elapsed = (datetime.now() - started).total_seconds()
    print(f"\n{'━'*65}")
    print(f"  POC completed in {elapsed:.2f}s")
    print(f"  Files: {DB_PATH.name}, {OUTPUT_CSV.name}")
    print(f"{'━'*65}\n")


if __name__ == "__main__":
    main()
