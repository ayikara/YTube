"""
Step 1: load_rules_to_db.py
Reads JSON files and inserts into SQLite tables.

In production: this is generate_bq_sql.py → BigQuery INSERT.
In POC: SQLite stands in for BigQuery so you can run locally.

This demonstrates:
  - How JSON parameters become database rows
  - How every row carries rule_id + spec_ref for traceability
  - How effective dates enable versioning
"""

import json
import sqlite3
import csv


def create_tables(conn):
    """Create the reference data tables (mirrors BQ schema)."""
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS benchmarks (
            benchmark_id  TEXT PRIMARY KEY,
            group_code    TEXT,
            exchange      TEXT,
            description   TEXT,
            tier_1        REAL,    -- base benchmark (>150k msgs)
            tier_2        REAL,    -- 2x tier (100k-150k msgs)
            tier_3        REAL,    -- 3x tier (50k-100k msgs)
            source_page   TEXT,
            effective_from TEXT
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS messaging_tiers (
            tier_id     TEXT PRIMARY KEY,
            min_msgs    INTEGER,
            max_msgs    INTEGER,
            multiplier  REAL,
            excluded    INTEGER  -- 1=true, 0=false
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS message_weights (
            rule_id    TEXT PRIMARY KEY,
            session    TEXT,     -- RTH or ETH
            month_type TEXT,     -- FRONT, BACK, or ALL
            msg_type   TEXT,     -- modifications, cancels, elimination
            weight     REAL,
            spec_ref   TEXT
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS order_data (
            trade_date          TEXT,
            account             TEXT,
            sessionid           TEXT,
            symbol              TEXT,    -- product group
            securitydescription TEXT,    -- instrument
            firm                TEXT,    -- GFID
            session             TEXT,    -- RTH or ETH
            orders              INTEGER,
            modifications       INTEGER,
            cancels             INTEGER,
            elimination         INTEGER,
            trade_volume        INTEGER
        )
    """)

    conn.commit()


def load_benchmarks(conn, json_path):
    """Load benchmark JSON into the benchmarks table."""
    with open(json_path) as f:
        data = json.load(f)

    c = conn.cursor()
    effective = data["_metadata"]["effective_from"]

    for b in data["benchmarks"]:
        c.execute(
            "INSERT OR REPLACE INTO benchmarks VALUES (?,?,?,?,?,?,?,?,?)",
            (b["benchmark_id"], b["group_code"], b["exchange"],
             b["description"], b["tier_1"], b["tier_2"], b["tier_3"],
             b["source_page"], effective)
        )

    for t in data["messaging_tiers"]:
        c.execute(
            "INSERT OR REPLACE INTO messaging_tiers VALUES (?,?,?,?,?)",
            (t["tier_id"], t["min_msgs"], t["max_msgs"],
             t["multiplier"], 1 if t["excluded"] else 0)
        )

    conn.commit()
    return len(data["benchmarks"]), len(data["messaging_tiers"])


def load_weights(conn, json_path):
    """Load message weight rules into the message_weights table."""
    with open(json_path) as f:
        data = json.load(f)

    c = conn.cursor()
    for w in data["message_weights"]:
        c.execute(
            "INSERT OR REPLACE INTO message_weights VALUES (?,?,?,?,?,?)",
            (w["rule_id"], w["session"], w["month_type"],
             w["msg_type"], w["weight"], w["spec_ref"])
        )

    conn.commit()
    return len(data["message_weights"])


def load_order_data(conn, csv_path):
    """Load sample aggregated order data."""
    c = conn.cursor()
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        rows = 0
        for row in reader:
            c.execute(
                "INSERT INTO order_data VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (row["trade_date"], row["account"], row["sessionid"],
                 row["symbol"], row["securitydescription"], row["firm"],
                 row["session"],
                 int(row["orders"]), int(row["modifications"]),
                 int(row["cancels"]), int(row["elimination"]),
                 int(row["trade_volume"]))
            )
            rows += 1

    conn.commit()
    return rows


def run(db_path, benchmarks_json, rules_json, data_csv):
    """Execute Step 1: load all JSON + CSV data into SQLite."""
    conn = sqlite3.connect(db_path)
    create_tables(conn)

    bm_count, tier_count = load_benchmarks(conn, benchmarks_json)
    wt_count = load_weights(conn, rules_json)
    row_count = load_order_data(conn, data_csv)

    # Print what was loaded
    print(f"  Benchmarks loaded:      {bm_count} product groups")
    print(f"  Messaging tiers loaded: {tier_count} tiers")
    print(f"  Message weights loaded: {wt_count} weight rules")
    print(f"  Order data loaded:      {row_count} rows from CSV")

    # Show a sample to verify
    c = conn.cursor()
    print(f"\n  Sample: ES benchmark from DB:")
    row = c.execute("SELECT * FROM benchmarks WHERE group_code='ES'").fetchone()
    print(f"    {row}")

    print(f"\n  Sample: RTH FRONT weights from DB:")
    for row in c.execute("SELECT rule_id, msg_type, weight, spec_ref FROM message_weights WHERE session='RTH' AND month_type='FRONT'"):
        print(f"    {row[0]:20s}  {row[1]:15s}  weight={row[2]}  ({row[3]})")

    conn.close()
    return True
