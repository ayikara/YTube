"""
Step 3: rule_engine.py
Python rule logic — reads daily_scores from DB and applies MEP rules.

Each function below implements a specific rule from the MEP spec.
The rule_id in the docstring matches mep_logic_rules.json — so when the spec
changes, you can look up which function to modify.

In production: reads from BigQuery. In POC: reads from SQLite.

This demonstrates:
  - How each MEP rule becomes a Python function
  - How parameters come from the DB (not hardcoded)
  - How the exemption waterfall works as a priority chain
  - How to verify: each function prints its inputs and outputs
"""

import json
import sqlite3
from dataclasses import dataclass


@dataclass
class DailyScore:
    """One row from daily_scores — input to the rule engine."""
    trade_date: str
    gfid: str
    product_group: str
    raw_msg_count: int
    messaging_score: float
    volume: int


@dataclass
class ComplianceResult:
    """Output of the rule engine for one GFID × product_group."""
    gfid: str
    product_group: str
    raw_msg_count: int
    messaging_score: float
    volume: int
    is_excluded: bool = False
    tier: str = ""
    effective_benchmark: float = 0.0
    volume_ratio: float = 0.0
    is_breach: bool = False
    is_6x_breach: bool = False
    status: str = "PASS"
    notes: str = ""


# ── Rule functions ────────────────────────────────────────────────────────
# Each function is named after its purpose and documents its rule_id.
# Parameters come from the database, not from hardcoded values.


def is_excluded(raw_msg_count: int, threshold: int) -> bool:
    """
    Rule: EXCL-50K  (Section 3, page 6)
    Firms with <= threshold raw daily messages per product group are excluded.
    The threshold value comes from mep_rules.json → DB, not hardcoded here.
    """
    return raw_msg_count <= threshold


def assign_tier(raw_msg_count: int, tiers: list[dict]) -> dict:
    """
    Rule: TIER-ASSIGN  (Section 6)
    Finds the tier whose range contains the raw message count.
    Tiers come from the messaging_tiers DB table (loaded from JSON).
    Returns: {tier_id, multiplier, excluded}
    """
    for tier in sorted(tiers, key=lambda t: t["min_msgs"]):
        if raw_msg_count <= tier["max_msgs"]:
            return tier
    return tiers[-1]  # fallback to highest tier


def calculate_ratio(messaging_score: float, volume: int) -> float | None:
    """
    Rule: RATIO-CALC  (Section 4)
    Volume Ratio = messaging_score / volume.
    Returns None if volume is zero (no trade day — not a breach).
    """
    if volume == 0:
        return None
    return messaging_score / volume


def check_breach(ratio: float | None, effective_benchmark: float) -> bool:
    """
    Rule: BREACH-DAILY  (Section 4 + Section 11)
    A firm is non-compliant if its ratio exceeds the effective benchmark.
    """
    if ratio is None:
        return False
    return ratio > effective_benchmark


def check_6x_breach(ratio: float | None, effective_benchmark: float, multiplier: int) -> bool:
    """
    Rule: EXEMPT-6X-BLOCK  (Section 11, Bullet 1 sub-clause)
    A 6x breach blocks ALL automatic waivers.
    The 6x multiplier comes from mep_rules.json, not hardcoded.
    """
    if ratio is None:
        return False
    return ratio > (multiplier * effective_benchmark)


def exemption_waterfall(is_breach: bool, is_6x: bool, waiver_available: bool) -> str:
    """
    Rules implemented (in priority order):
      1. BREACH-DAILY       → if no breach: PASS
      2. EXEMPT-6X-BLOCK    → if 6x breach: SURCHARGE (no waivers possible)
      3. EXEMPT-AUTO-WAIV   → if waiver available: AUTO_WAIVED
      4. Otherwise           → POTENTIAL (pending month-end)

    Section 11 of MEP spec defines this priority order.
    Monthly waiver (EXEMPT-MONTHLY) runs at month-end — not in daily processing.
    """
    if not is_breach:
        return "PASS"

    if is_6x:
        return "SURCHARGE_APPLIED"

    if waiver_available:
        return "AUTO_WAIVED"

    return "POTENTIAL"


def check_emt(gfid: str, product_group: str, raw_msg_count: int,
              ratio: float | None, emt_params: dict) -> bool:
    """
    Rule: EMT-GFID-SOFR  (Section 16, paragraph 5)
    EMT is a separate threshold track.
    Both raw count AND ratio must exceed thresholds simultaneously.
    SS product group uses tighter SOFR-specific thresholds.
    """
    if ratio is None:
        return False

    if product_group == emt_params.get("product_group", ""):
        # SOFR-specific thresholds
        sofr = emt_params
        return (raw_msg_count > sofr["raw_threshold"]
                and ratio > sofr["ratio_threshold"])

    # General GFID EMT (not implemented in POC for simplicity)
    return False


# ── Orchestrator ──────────────────────────────────────────────────────────

def run(db_path, rules_json_path):
    """Execute Step 3: apply rule engine to all daily_scores rows."""
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    # Load parameters from DB (they were loaded from JSON in Step 1)
    tiers = [
        {"tier_id": r[0], "min_msgs": r[1], "max_msgs": r[2],
         "multiplier": r[3], "excluded": bool(r[4])}
        for r in c.execute("SELECT * FROM messaging_tiers ORDER BY min_msgs")
    ]

    benchmarks = {
        r[0]: {"tier_1": r[1], "tier_2": r[2], "tier_3": r[3]}
        for r in c.execute("SELECT group_code, tier_1, tier_2, tier_3 FROM benchmarks")
    }

    # Load scalar params from JSON (in production: from mep_config_params table)
    with open(rules_json_path) as f:
        rules = json.load(f)
    excl_threshold = rules["exclusion_threshold"]
    six_x_mult = rules["six_x_multiplier"]
    emt_sofr = rules["emt_gfid_sofr"]

    # Load daily_scores from DB
    scores = [
        DailyScore(*r)
        for r in c.execute("""
            SELECT trade_date, gfid, product_group,
                   raw_msg_count_total, messaging_score_total, volume_total
            FROM daily_scores
            ORDER BY gfid, product_group
        """)
    ]

    # Track waivers used this month: (gfid, product_group) → count
    waivers_used: dict[tuple, int] = {}

    results = []

    print(f"\n  Processing {len(scores)} GFID × product group combinations:\n")

    for s in scores:
        r = ComplianceResult(
            gfid=s.gfid, product_group=s.product_group,
            raw_msg_count=s.raw_msg_count, messaging_score=s.messaging_score,
            volume=s.volume,
        )

        # ── Step 1: Exclusion check ──────────────────────────────────────
        # Rule: EXCL-50K — threshold loaded from DB, not hardcoded
        if is_excluded(s.raw_msg_count, excl_threshold):
            r.is_excluded = True
            r.status = "PASS"
            r.tier = "EXCLUDED"
            r.notes = f"raw_msgs={s.raw_msg_count:,} <= threshold={excl_threshold:,}"
            results.append(r)
            _print_result(r)
            continue

        # ── Step 2: Tier assignment ──────────────────────────────────────
        # Rule: TIER-ASSIGN — tiers loaded from DB
        tier = assign_tier(s.raw_msg_count, tiers)
        r.tier = tier["tier_id"]

        # Look up the base benchmark for this product group
        bm = benchmarks.get(s.product_group)
        if bm is None:
            r.status = "PASS"
            r.notes = f"product group {s.product_group} not in MEP benchmarks"
            results.append(r)
            _print_result(r)
            continue

        # Effective benchmark = base benchmark from the matching tier
        if tier["tier_id"] == "TIER_3":
            r.effective_benchmark = bm["tier_3"]
        elif tier["tier_id"] == "TIER_2":
            r.effective_benchmark = bm["tier_2"]
        else:
            r.effective_benchmark = bm["tier_1"]

        # ── Step 3: Volume ratio ─────────────────────────────────────────
        # Rule: RATIO-CALC
        r.volume_ratio = calculate_ratio(s.messaging_score, s.volume) or 0.0

        # ── Step 4: Daily breach check ───────────────────────────────────
        # Rule: BREACH-DAILY
        ratio = calculate_ratio(s.messaging_score, s.volume)
        r.is_breach = check_breach(ratio, r.effective_benchmark)

        # ── Step 5: 6× breach check ─────────────────────────────────────
        # Rule: EXEMPT-6X-BLOCK — 6x multiplier loaded from JSON
        r.is_6x_breach = check_6x_breach(ratio, r.effective_benchmark, six_x_mult)

        # ── Step 6: Exemption waterfall ──────────────────────────────────
        key = (s.gfid, s.product_group)
        waiver_available = waivers_used.get(key, 0) < rules["auto_waivers_per_month"]

        r.status = exemption_waterfall(r.is_breach, r.is_6x_breach, waiver_available)

        # If waiver was consumed, track it
        if r.status == "AUTO_WAIVED":
            waivers_used[key] = waivers_used.get(key, 0) + 1

        r.notes = (f"ratio={r.volume_ratio:.1f} vs benchmark={r.effective_benchmark:.0f} "
                   f"({r.tier}, multiplier={tier['multiplier']})")

        # ── Step 7: EMT check (separate track) ──────────────────────────
        # Rule: EMT-GFID-SOFR — thresholds loaded from JSON
        emt_hit = check_emt(s.gfid, s.product_group, s.raw_msg_count, ratio, emt_sofr)
        if emt_hit:
            r.notes += " | EMT BREACH"

        results.append(r)
        _print_result(r)

    conn.close()
    return results


# ── Display helper ────────────────────────────────────────────────────────

STATUS_COLOR = {
    "PASS": "\033[92m", "AUTO_WAIVED": "\033[94m",
    "POTENTIAL": "\033[93m", "SURCHARGE_APPLIED": "\033[91m",
}
RESET = "\033[0m"

def _print_result(r: ComplianceResult):
    color = STATUS_COLOR.get(r.status, "")
    excluded = " [EXCLUDED]" if r.is_excluded else ""
    breach = " BREACH" if r.is_breach else ""
    six_x = " 6×!" if r.is_6x_breach else ""
    print(f"  {r.gfid:<6} {r.product_group:<5} "
          f"raw={r.raw_msg_count:>7,}  score={r.messaging_score:>9.1f}  vol={r.volume:>6,}  "
          f"ratio={r.volume_ratio:>7.1f}  bm={r.effective_benchmark:>5.0f}  "
          f"{r.tier:<8} {color}{r.status}{RESET}{excluded}{breach}{six_x}")
