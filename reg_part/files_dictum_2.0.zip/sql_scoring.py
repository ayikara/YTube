"""
Step 2: sql_scoring.py
Runs SQL against SQLite to classify, weight, and aggregate order data.

In production: these are BigQuery views (vw_classified_events, vw_event_scores)
               and a materialised table (daily_scores).
In POC: same SQL logic runs on SQLite.

This demonstrates:
  - How the weight lookup JOIN works (session × month_type × msg_type)
  - How raw message count is computed for tier determination
  - How weighted messaging score is computed for the volume ratio
  - How everything aggregates to GFID × product_group level

POC simplification: all instruments treated as FRONT month outright.
In production, a JOIN to ref.front_month_flag resolves month type per instrument.
"""

import sqlite3


def run(db_path):
    """Execute Step 2: SQL scoring and aggregation."""
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    # ── Create the scored + aggregated view ──────────────────────────────
    # This is the equivalent of mep_calc.daily_scores in the design doc.
    #
    # POC simplification: we treat all instruments as FRONT month.
    # In production, a JOIN to ref.front_month_flag determines month_type.

    c.execute("DROP TABLE IF EXISTS daily_scores")
    c.execute("""
        CREATE TABLE daily_scores AS

        -- Step A: Score each row by joining the weight table
        WITH scored AS (
            SELECT
                o.trade_date,
                o.firm                          AS gfid,
                o.symbol                        AS product_group,
                o.session                       AS session_type,

                -- Raw message count (for tier determination)
                -- All message types count: orders + mods + cancels + eliminations
                -- This determines which tier the firm falls into
                (o.orders + o.modifications + o.cancels + o.elimination)
                    AS raw_msg_count,

                -- Weighted messaging score (for volume ratio)
                -- New orders always weight 0 — they don't appear in the formula
                -- Each message type multiplied by its weight from the rules table
                (o.modifications * COALESCE(w_mod.weight, 0)
                 + o.cancels     * COALESCE(w_can.weight, 0)
                 + o.elimination * COALESCE(w_eli.weight, 0)
                ) AS messaging_score,

                o.trade_volume,

                -- Keep individual weights for transparency
                COALESCE(w_mod.weight, 0) AS mod_weight_used,
                COALESCE(w_can.weight, 0) AS can_weight_used,
                COALESCE(w_eli.weight, 0) AS eli_weight_used

            FROM order_data o

            -- Join modification weight
            LEFT JOIN message_weights w_mod
                ON  w_mod.msg_type = 'modifications'
                AND (w_mod.session = o.session OR w_mod.session = 'ALL')
                AND (w_mod.month_type = 'FRONT' OR w_mod.month_type = 'ALL')
                -- POC: assumes FRONT month. Production: join front_month_flag

            -- Join cancellation weight
            LEFT JOIN message_weights w_can
                ON  w_can.msg_type = 'cancels'
                AND (w_can.session = o.session OR w_can.session = 'ALL')
                AND (w_can.month_type = 'FRONT' OR w_can.month_type = 'ALL')

            -- Join elimination weight
            LEFT JOIN message_weights w_eli
                ON  w_eli.msg_type = 'elimination'
                AND (w_eli.session = o.session OR w_eli.session = 'ALL')
                AND (w_eli.month_type = 'FRONT' OR w_eli.month_type = 'ALL')
        )

        -- Step B: Aggregate to GFID × product_group level (one row per firm per product)
        SELECT
            trade_date,
            gfid,
            product_group,

            SUM(raw_msg_count)                                                  AS raw_msg_count_total,
            SUM(CASE WHEN session_type='RTH' THEN raw_msg_count ELSE 0 END)    AS raw_msg_rth,
            SUM(CASE WHEN session_type='ETH' THEN raw_msg_count ELSE 0 END)    AS raw_msg_eth,

            SUM(messaging_score)                                                AS messaging_score_total,
            SUM(CASE WHEN session_type='RTH' THEN messaging_score ELSE 0 END)  AS messaging_score_rth,
            SUM(CASE WHEN session_type='ETH' THEN messaging_score ELSE 0 END)  AS messaging_score_eth,

            SUM(trade_volume)                                                   AS volume_total

        FROM scored
        GROUP BY trade_date, gfid, product_group
    """)
    conn.commit()

    # ── Print the results ────────────────────────────────────────────────
    print(f"\n  daily_scores table created. Contents:\n")
    print(f"  {'GFID':<6} {'PG':<5} {'RawMsgs':>8} {'Score':>10} {'Volume':>8}   Breakdown")
    print(f"  {'─'*6} {'─'*5} {'─'*8} {'─'*10} {'─'*8}   {'─'*30}")

    rows = c.execute("""
        SELECT gfid, product_group,
               raw_msg_count_total, messaging_score_total, volume_total,
               raw_msg_rth, raw_msg_eth,
               messaging_score_rth, messaging_score_eth
        FROM daily_scores
        ORDER BY gfid, product_group
    """).fetchall()

    for r in rows:
        gfid, pg, raw, score, vol, raw_r, raw_e, sc_r, sc_e = r
        print(f"  {gfid:<6} {pg:<5} {raw:>8,} {score:>10.1f} {vol:>8,}   "
              f"RTH: raw={raw_r:,} score={sc_r:.1f}  ETH: raw={raw_e:,} score={sc_e:.1f}")

    conn.close()
    return rows
