"""
generate_bq_sql.py
Reads mep_benchmarks_q3_2026.json and mep_rules_v11_8.json and produces
BigQuery INSERT scripts. JSON is the single source of truth — SQL is derived.

Usage:
    python3 generate_bq_sql.py

Outputs:
    insert_mep_rules.sql         — ref.mep_rules (benchmarks per product group)
    insert_mep_message_weights.sql — ref.mep_message_weights
    insert_mep_messaging_tiers.sql — ref.messaging_tiers
"""

import json
import itertools
from pathlib import Path
from datetime import datetime

HERE = Path(__file__).parent
BENCHMARKS_FILE = HERE / "mep_benchmarks_q3_2026.json"
RULES_FILE      = HERE / "mep_rules_v11_8.json"
OUT_DIR         = HERE

GENERATED_AT = datetime.utcnow().strftime("%Y-%m-%d %:%M UTC")


def q(value):
    """Quote a string for SQL, or return NULL."""
    if value is None:
        return "NULL"
    return f"'{str(value).replace(chr(39), chr(39)*2)}'"


def b(value):
    """Boolean to SQL."""
    if value is None:
        return "NULL"
    return "TRUE" if value else "FALSE"


def n(value):
    """Numeric — pass through or NULL."""
    return "NULL" if value is None else str(value)


# ── 1. ref.mep_rules ─────────────────────────────────────────────────────────

def generate_mep_rules_sql(benchmarks: dict) -> str:
    lines = [
        "-- ============================================================",
        "-- ref.mep_rules  — MEP product group benchmark ratios",
        f"-- Generated: {GENERATED_AT}",
        f"-- Source:    {benchmarks['_metadata']['source_document']}",
        f"-- Quarter:   {benchmarks['_metadata']['quarter']}",
        "-- REVIEW STATUS: " + benchmarks["_metadata"]["status"],
        "-- ============================================================",
        "",
        "-- Expire previous Q2 benchmarks before inserting Q3",
        "-- IMPORTANT: Review and adjust the effective_to date for prior quarter rows",
        "UPDATE `project.ref.mep_rules`",
        "   SET effective_to = '2026-06-30'",
        " WHERE effective_to IS NULL",
        "   AND effective_from < '2026-07-01';",
        "",
        "-- Insert Q3 2026 benchmarks",
        "INSERT INTO `project.ref.mep_rules` (",
        "  group_code, exchange, description, asset_class, instrument_type,",
        "  tier_3_benchmark, tier_2_benchmark, tier_1_benchmark,",
        "  second_level_eval, special_rules, effective_from, effective_to,",
        "  source_document, source_quarter, loaded_at",
        ")",
        "VALUES",
    ]

    all_groups = []
    pg = benchmarks["product_group_benchmarks"]
    for category in pg.values():
        if isinstance(category, list): all_groups.extend(category)

    rows = []
    for g in all_groups:
        special = json.dumps(g.get("special_rules", [])).replace("'", "''")
        rows.append(
            f"  ({q(g['group_code'])}, {q(g['exchange'])}, {q(g['description'])}, "
            f"{q(g['asset_class'])}, {q(g['instrument_type'])}, "
            f"{n(g['tier_3_benchmark'])}, {n(g['tier_2_benchmark'])}, {n(g['tier_1_benchmark'])}, "
            f"{b(g.get('second_level_eval', False))}, "
            f"JSON {q(special)}, "
            f"{q(g['effective_from'])}, {q(g['effective_to'])}, "
            f"{q(benchmarks['_metadata']['source_document'])}, "
            f"{q(benchmarks['_metadata']['quarter'])}, "
            f"CURRENT_TIMESTAMP())"
        )

    lines.append(",\n".join(rows) + ";")
    lines.append("")
    lines.append("-- Mass quote benchmarks")
    lines.append("INSERT INTO `project.ref.mep_mass_quote_rules` (")
    lines.append("  group_code, exchange, description, benchmark_ratio,")
    lines.append("  effective_from, effective_to, source_quarter, loaded_at")
    lines.append(")")
    lines.append("VALUES")

    mq_rows = []
    for g in benchmarks["mass_quote_benchmarks"]["product_groups"]:
        mq_rows.append(
            f"  ({q(g['group_code'])}, {q(g['exchange'])}, {q(g['description'])}, "
            f"{n(g['benchmark'])}, "
            f"{q(g['effective_from'])}, {q(g['effective_to'])}, "
            f"{q(benchmarks['_metadata']['quarter'])}, CURRENT_TIMESTAMP())"
        )

    lines.append(",\n".join(mq_rows) + ";")
    return "\n".join(lines)


# ── 2. ref.messaging_tiers ───────────────────────────────────────────────────

def generate_tiers_sql(benchmarks: dict) -> str:
    tiers = benchmarks["messaging_tiers"]["tiers"]
    eff_from = benchmarks["messaging_tiers"]["effective_from"]
    eff_to   = benchmarks["messaging_tiers"]["effective_to"]

    lines = [
        "-- ============================================================",
        "-- ref.messaging_tiers  — Raw daily message count tiers",
        f"-- Generated: {GENERATED_AT}",
        "-- NOTE: Tiers are program-level, not quarter-specific.",
        "-- Only update if MEP spec changes tier boundaries.",
        "-- ============================================================",
        "",
        "INSERT INTO `project.ref.messaging_tiers` (",
        "  tier_id, min_raw_msgs, max_raw_msgs, benchmark_multiplier,",
        "  is_excluded, label, effective_from, effective_to, notes, loaded_at",
        ")",
        "VALUES",
    ]

    rows = []
    for t in tiers:
        rows.append(
            f"  ({q(t['tier_id'])}, {n(t['min_raw_msgs'])}, {n(t['max_raw_msgs'])}, "
            f"{n(t['benchmark_multiplier'])}, {b(t['is_excluded'])}, "
            f"{q(t['label'])}, {q(eff_from)}, {q(eff_to)}, "
            f"{q(t.get('notes',''))}, CURRENT_TIMESTAMP())"
        )

    lines.append(",\n".join(rows) + ";")
    return "\n".join(lines)


# ── 3. ref.mep_message_weights ───────────────────────────────────────────────

def generate_weights_sql(rules: dict) -> str:
    weights = rules["message_weights"]["weights"]
    eff_from = rules["message_weights"]["effective_from"]
    eff_to   = rules["message_weights"]["effective_to"]

    lines = [
        "-- ============================================================",
        "-- ref.mep_message_weights  — Per-message weighting factors",
        f"-- Generated: {GENERATED_AT}",
        f"-- Source:    MEP v{rules['_metadata']['source_version']}",
        "-- NOTE: Only update if MEP spec changes weighting factors.",
        "-- ============================================================",
        "",
        "INSERT INTO `project.ref.mep_message_weights` (",
        "  session_type, month_type, instrument_type, msg_type, msg_description,",
        "  ilink_tag, weight_factor, weight_is_per_order_cancelled,",
        "  raw_count_is_per_order_cancelled, effective_from, effective_to,",
        "  notes, loaded_at",
        ")",
        "VALUES",
    ]

    rows = []
    for w in weights:
        rows.append(
            f"  ({q(w['session_type'])}, {q(w['month_type'])}, {q(w['instrument_type'])}, "
            f"{q(w['msg_type'])}, {q(w['msg_description'])}, {q(w['ilink_tag'])}, "
            f"{n(w['weight_factor'])}, "
            f"{b(w.get('weight_is_per_order_cancelled', False))}, "
            f"{b(w.get('raw_count_is_per_order_cancelled', False))}, "
            f"{q(eff_from)}, {q(eff_to)}, "
            f"{q(w.get('notes',''))}, CURRENT_TIMESTAMP())"
        )

    lines.append(",\n".join(rows) + ";")
    return "\n".join(lines)


# ── 4. Validation report ─────────────────────────────────────────────────────

def generate_validation_report(benchmarks: dict, rules: dict) -> str:
    pg = benchmarks["product_group_benchmarks"]
    all_groups = list(itertools.chain.from_iterable(pg.values()))

    lines = [
        "-- ============================================================",
        "-- VALIDATION QUERIES — Run after INSERT to verify data",
        f"-- Generated: {GENERATED_AT}",
        "-- ============================================================",
        "",
        "-- 1. Count product groups loaded for Q3 2026",
        "SELECT COUNT(*) AS product_group_count",
        "FROM `project.ref.mep_rules`",
        "WHERE effective_from = '2026-07-01';",
        f"-- Expected: {len(all_groups)} product groups",
        "",
        "-- 2. Verify SS-SOFR has second_level_eval = TRUE",
        "SELECT group_code, second_level_eval",
        "FROM `project.ref.mep_rules`",
        "WHERE group_code = 'SS' AND effective_to IS NULL;",
        "-- Expected: second_level_eval = TRUE",
        "",
        "-- 3. Spot check key benchmarks",
        "SELECT group_code, tier_3_benchmark, tier_2_benchmark, tier_1_benchmark",
        "FROM `project.ref.mep_rules`",
        "WHERE group_code IN ('ES', 'SS', 'ZC', 'CL', 'GC')",
        "  AND effective_to IS NULL",
        "ORDER BY group_code;",
        "-- Expected:",
        "-- CL:  180 / 120 / 60",
        "-- ES:   45 /  30 / 15",
        "-- GC:   90 /  60 / 30",
        "-- SS:   30 /  20 / 10",
        "-- ZC:  150 / 100 / 50",
        "",
        "-- 4. Verify tier thresholds",
        "SELECT tier_id, min_raw_msgs, max_raw_msgs, benchmark_multiplier, is_excluded",
        "FROM `project.ref.messaging_tiers`",
        "ORDER BY min_raw_msgs;",
        "",
        "-- 5. Verify message weights — RTH front month should have weight=1 for modifications",
        "SELECT session_type, month_type, msg_type, weight_factor",
        "FROM `project.ref.mep_message_weights`",
        "WHERE session_type = 'RTH' AND month_type = 'FRONT'",
        "ORDER BY msg_type;",
        "-- Expected: G=1, F=3, CA=3, FAK=3, MINQTY=3, D=0",
        "",
        "-- 6. Verify no duplicate active rows per product group",
        "SELECT group_code, COUNT(*) AS active_rows",
        "FROM `project.ref.mep_rules`",
        "WHERE effective_to IS NULL",
        "GROUP BY group_code",
        "HAVING COUNT(*) > 1;",
        "-- Expected: 0 rows (no duplicates)",
        "",
        "-- 7. Mass quote benchmark count",
        "SELECT COUNT(*) FROM `project.ref.mep_mass_quote_rules`",
        "WHERE effective_to IS NULL;",
        f"-- Expected: {len(benchmarks['mass_quote_benchmarks']['product_groups'])} mass quote product groups",
    ]
    return "\n".join(lines)


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    with open(BENCHMARKS_FILE) as f:
        benchmarks = json.load(f)
    with open(RULES_FILE) as f:
        rules = json.load(f)

    outputs = {
        "insert_mep_rules.sql":           generate_mep_rules_sql(benchmarks),
        "insert_mep_messaging_tiers.sql": generate_tiers_sql(benchmarks),
        "insert_mep_message_weights.sql": generate_weights_sql(rules),
        "validate_bq_inserts.sql":        generate_validation_report(benchmarks, rules),
    }

    for filename, content in outputs.items():
        path = OUT_DIR / filename
        path.write_text(content)
        print(f"  Written: {path.name}  ({len(content.splitlines())} lines)")

    print(f"\nAll outputs written to {OUT_DIR}")


if __name__ == "__main__":
    main()
