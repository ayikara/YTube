"""
mep_rule_logic.py
MEP rules engine — logic layer.

ALL constants and thresholds in this file are loaded from mep_rules_v11_8.json
at startup. The JSON is the business-readable source of truth.
This file contains ONLY conditional logic — no hardcoded business values.

Generated from: mep_rules_v11_8.json (MEP v11.8, 2026-05-01)
Generator:      generate_rule_logic.py
Last updated:   2026-06-27

Change process:
  - Parameter changes (thresholds, weights): update JSON only, no code change needed
  - Logic changes (new rule type, new exemption): update this file + tests

Usage:
    from mep_rule_logic import MEPRuleEngine
    engine = MEPRuleEngine.from_json("mep_rules_v11_8.json")
    results = engine.run(daily_scores, ...)
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ── Config loader ─────────────────────────────────────────────────────────────

def load_rules(json_path: str | Path) -> dict:
    with open(json_path) as f:
        return json.load(f)


# ── Data containers ───────────────────────────────────────────────────────────

@dataclass
class SessionConfig:
    rth_start_ct: str
    rth_end_ct: str
    timezone: str


@dataclass
class WeightKey:
    session_type: str     # RTH | ETH
    month_type: str       # FRONT | BACK | ALL
    instrument_type: str  # OUTRIGHT | SPREAD | ALL
    msg_type: str         # G | F | CA | FAK | MINQTY | D


@dataclass
class WeightEntry:
    weight_factor: float
    weight_is_per_order_cancelled: bool
    raw_count_is_per_order_cancelled: bool


@dataclass
class TierEntry:
    tier_id: str
    min_raw_msgs: int
    max_raw_msgs: Optional[int]
    benchmark_multiplier: Optional[float]
    is_excluded: bool


@dataclass
class EMTParams:
    raw_message_threshold: int
    volume_ratio_threshold: float


@dataclass
class EMTMPSParams:
    modifications_per_second_threshold: int
    surcharge_per_breach: int


@dataclass
class DailyScore:
    trade_date: str
    gfid: str
    product_group: str
    raw_msg_count_total: int
    messaging_score_total: float
    volume_contracts_total: int
    has_second_level_breach: bool
    modifications_per_second_max: Optional[float] = None


@dataclass
class ComplianceResult:
    trade_date: str
    gfid: str
    product_group: str
    is_excluded: bool = False
    tier_id: Optional[str] = None
    benchmark_multiplier: Optional[float] = None
    effective_benchmark: Optional[float] = None
    volume_ratio: Optional[float] = None
    is_daily_breach: bool = False
    is_6x_breach: bool = False
    is_second_level_breach: bool = False
    is_market_maker_exempt: bool = False
    emt_gfid_breach: bool = False
    emt_session_breach: bool = False
    emt_mps_breach: bool = False
    status: str = "PASS"
    monthly_ratio: Optional[float] = None


# ── Core rule engine ──────────────────────────────────────────────────────────

class MEPRuleEngine:
    """
    Loads all rule parameters from JSON at construction time.
    Contains only conditional logic — no hardcoded business values.

    Each rule method is a pure function: fixed inputs → deterministic output.
    All methods are independently unit-testable by constructing the engine
    with fixture JSON data.
    """

    def __init__(self, rules: dict):
        self._rules = rules
        self._session   = self._parse_session(rules)
        self._weights   = self._parse_weights(rules)
        self._tiers     = self._parse_tiers(rules)
        self._emt_gen   = self._parse_emt_general(rules)
        self._emt_sofr  = self._parse_emt_sofr(rules)
        self._emt_mps   = self._parse_emt_mps(rules)
        self._excl_thresh = rules["exclusions"]["raw_message_exclusion_threshold"]
        self._6x_mult     = rules["exemptions_and_waivers"]["six_x_breach_threshold_multiplier"]
        self._auto_waivers_per_month = rules["exemptions_and_waivers"]["auto_waiver_per_month_per_pg"]
        self._mm_products = set(rules["market_maker_exemptions"]["exempt_products"])

    @classmethod
    def from_json(cls, path: str | Path) -> "MEPRuleEngine":
        return cls(load_rules(path))

    # ── Parsers ───────────────────────────────────────────────────────────────

    def _parse_session(self, rules: dict) -> SessionConfig:
        s = rules["session_definition"]["rth"]
        return SessionConfig(
            rth_start_ct=s["start_time_ct"],
            rth_end_ct=s["end_time_ct"],
            timezone=s["timezone"],
        )

    def _parse_weights(self, rules: dict) -> dict[tuple, WeightEntry]:
        result = {}
        for w in rules["message_weights"]["weights"]:
            key = (w["session_type"], w["month_type"], w["instrument_type"], w["msg_type"])
            result[key] = WeightEntry(
                weight_factor=w["weight_factor"],
                weight_is_per_order_cancelled=w.get("weight_is_per_order_cancelled", False),
                raw_count_is_per_order_cancelled=w.get("raw_count_is_per_order_cancelled", False),
            )
        return result

    def _parse_tiers(self, rules: dict) -> list[TierEntry]:
        return [
            TierEntry(
                tier_id=t["tier_id"],
                min_raw_msgs=t["min_raw_msgs"],
                max_raw_msgs=t["max_raw_msgs"],
                benchmark_multiplier=t["benchmark_multiplier"],
                is_excluded=t["is_excluded"],
            )
            for t in rules["messaging_tiers"]["tiers"]
        ]

    def _parse_emt_general(self, rules: dict) -> EMTParams:
        e = rules["emt_rules"]["gfid_emt_general"]
        return EMTParams(e["raw_message_threshold"], e["volume_ratio_threshold"])

    def _parse_emt_sofr(self, rules: dict) -> EMTParams:
        e = rules["emt_rules"]["gfid_emt_sofr"]
        return EMTParams(e["raw_message_threshold"], e["volume_ratio_threshold"])

    def _parse_emt_mps(self, rules: dict) -> EMTMPSParams:
        e = rules["emt_rules"]["gfid_emt_mps_sofr"]
        return EMTMPSParams(
            modifications_per_second_threshold=e["threshold"],
            surcharge_per_breach=e["surcharge_per_breach"],
        )

    # ── Rule 1: Exclusion ─────────────────────────────────────────────────────

    def is_excluded(self, row: DailyScore) -> bool:
        """
        Firms at or below the raw message exclusion threshold are
        not subject to MEP scoring for that product group on that date.
        Threshold loaded from JSON: exclusions.raw_message_exclusion_threshold
        """
        return row.raw_msg_count_total <= self._excl_thresh

    # ── Rule 2: Tier assignment ───────────────────────────────────────────────

    def assign_tier(self, row: DailyScore) -> TierEntry:
        """
        Returns the tier whose [min, max] range contains the row's raw
        message count. Tiers are sorted ascending; first match wins.
        Raises if no tier covers the count (config error).
        """
        for tier in sorted(self._tiers, key=lambda t: t.min_raw_msgs):
            if tier.max_raw_msgs is None or row.raw_msg_count_total <= tier.max_raw_msgs:
                return tier
        raise ValueError(
            f"No tier matched raw_msg_count={row.raw_msg_count_total} "
            f"for GFID={row.gfid} PG={row.product_group}"
        )

    # ── Rule 3: Volume ratio ──────────────────────────────────────────────────

    def calculate_volume_ratio(self, row: DailyScore) -> Optional[float]:
        """
        Volume Ratio = messaging_score_total / volume_contracts_total.
        Returns None when volume is zero — no-trade days are not breaches.
        """
        if row.volume_contracts_total == 0:
            return None
        return row.messaging_score_total / row.volume_contracts_total

    # ── Rule 4: Daily breach ──────────────────────────────────────────────────

    def is_daily_breach(
        self,
        volume_ratio: Optional[float],
        effective_benchmark: float,
        has_second_level_breach: bool,
    ) -> bool:
        """
        A firm is non-compliant on a trade date if:
          (a) its volume ratio exceeds the effective benchmark, OR
          (b) any single second exceeded the benchmark (second-level products only).
        """
        if has_second_level_breach:
            return True
        if volume_ratio is None:
            return False
        return volume_ratio > effective_benchmark

    # ── Rule 5: 6× breach detection ──────────────────────────────────────────

    def is_6x_breach(
        self,
        volume_ratio: Optional[float],
        effective_benchmark: float,
    ) -> bool:
        """
        A 6× breach blocks ALL automatic waivers (monthly aggregate and
        one-per-month daily waiver). Multiplier loaded from JSON:
        exemptions_and_waivers.six_x_breach_threshold_multiplier
        """
        if volume_ratio is None:
            return False
        return volume_ratio > (self._6x_mult * effective_benchmark)

    # ── Rule 6: EMT checks ────────────────────────────────────────────────────

    def check_emt_gfid(
        self,
        row: DailyScore,
        volume_ratio: Optional[float],
    ) -> bool:
        """
        GFID-level EMT. Product group SS uses tighter SOFR-specific thresholds.
        Both raw message count AND volume ratio must exceed thresholds simultaneously.
        """
        if row.product_group == "SS":
            params = self._emt_sofr
        else:
            params = self._emt_gen

        if row.raw_msg_count_total <= params.raw_message_threshold:
            return False
        if volume_ratio is None or volume_ratio <= params.volume_ratio_threshold:
            return False
        return True

    def check_emt_mps(self, row: DailyScore) -> bool:
        """
        Modifications-per-second EMT — only applies to SS product group.
        Any single second exceeding the MPS threshold is a breach.
        Threshold loaded from JSON: emt_rules.gfid_emt_mps_sofr.threshold
        """
        if row.product_group != "SS":
            return False
        if row.modifications_per_second_max is None:
            return False
        return row.modifications_per_second_max > self._emt_mps.modifications_per_second_threshold

    # ── Rule 7: Market maker exemption ───────────────────────────────────────

    def is_market_maker_exempt(self, gfid: str, market_maker_gfids: set[str]) -> bool:
        """
        Market maker exemption: exempt from standard benchmark but still
        subject to EMT. Exempt GFID set is maintained by compliance team.
        """
        return gfid in market_maker_gfids

    # ── Rule 8: Exemption waterfall ───────────────────────────────────────────

    def apply_exemption_waterfall(
        self,
        is_breach: bool,
        is_6x: bool,
        is_mm_exempt: bool,
        effective_benchmark: float,
        volume_ratio: Optional[float],
        monthly_ratio: Optional[float],
        auto_waivers_used: int,
    ) -> str:
        """
        Evaluates exemptions in strict priority order. First matching rule wins.

        Waterfall (ordered):
          1. No breach          → PASS
          2. Market maker exempt → AUTO_WAIVED  (exempt from standard benchmark)
          3. 6× breach          → SURCHARGE_APPLIED  (no waivers possible)
          4. Monthly ratio ≤ benchmark → PASS_ON_MONTHLY
          5. Auto-waiver available → AUTO_WAIVED
          6. Month not yet closed → POTENTIAL
          7. All exhausted       → SURCHARGE_APPLIED

        auto_waivers_per_month loaded from JSON:
          exemptions_and_waivers.auto_waiver_per_month_per_pg
        """
        if not is_breach:
            return "PASS"

        if is_mm_exempt:
            return "AUTO_WAIVED"

        if is_6x:
            return "SURCHARGE_APPLIED"

        if monthly_ratio is not None and monthly_ratio <= effective_benchmark:
            return "PASS_ON_MONTHLY"

        if auto_waivers_used < self._auto_waivers_per_month:
            return "AUTO_WAIVED"

        if monthly_ratio is None:
            return "POTENTIAL"

        return "SURCHARGE_APPLIED"

    # ── Orchestrator ──────────────────────────────────────────────────────────

    def run(
        self,
        daily_scores: list[DailyScore],
        benchmark_by_pg: dict[str, float],       # {product_group: tier_3_benchmark}
        market_maker_gfids: set[str],
        auto_waivers_used: dict[tuple, int],      # {(gfid, pg): count used this month}
        monthly_ratios: dict[tuple, float],       # {(gfid, pg): monthly ratio, None if open}
    ) -> list[ComplianceResult]:
        """
        Orchestrates all rule functions for the daily batch run.
        This method sequences calls and passes outputs between rules.
        It contains NO business logic — only wiring.
        """
        results = []

        for row in daily_scores:
            result = ComplianceResult(
                trade_date=row.trade_date,
                gfid=row.gfid,
                product_group=row.product_group,
            )

            # 1. Exclusion check — short-circuit
            if self.is_excluded(row):
                result.is_excluded = True
                result.status = "PASS"
                results.append(result)
                continue

            # 2. Tier and effective benchmark
            tier = self.assign_tier(row)
            base_benchmark = benchmark_by_pg.get(row.product_group, 0)
            effective_bm   = base_benchmark * (tier.benchmark_multiplier or 1.0)

            result.tier_id             = tier.tier_id
            result.benchmark_multiplier = tier.benchmark_multiplier
            result.effective_benchmark  = effective_bm

            # 3. Volume ratio
            ratio = self.calculate_volume_ratio(row)
            result.volume_ratio = ratio

            # 4. Daily breach
            breach = self.is_daily_breach(ratio, effective_bm, row.has_second_level_breach)
            result.is_daily_breach       = breach
            result.is_second_level_breach = row.has_second_level_breach

            # 5. 6× breach
            result.is_6x_breach = self.is_6x_breach(ratio, effective_bm)

            # 6. Market maker exemption
            result.is_market_maker_exempt = self.is_market_maker_exempt(
                row.gfid, market_maker_gfids
            )

            # 7. EMT checks (independent of standard MEP waterfall)
            result.emt_gfid_breach = self.check_emt_gfid(row, ratio)
            result.emt_mps_breach  = self.check_emt_mps(row)

            # 8. Exemption waterfall → final status
            key = (row.gfid, row.product_group)
            result.status = self.apply_exemption_waterfall(
                is_breach=breach,
                is_6x=result.is_6x_breach,
                is_mm_exempt=result.is_market_maker_exempt,
                effective_benchmark=effective_bm,
                volume_ratio=ratio,
                monthly_ratio=monthly_ratios.get(key),
                auto_waivers_used=auto_waivers_used.get(key, 0),
            )
            result.monthly_ratio = monthly_ratios.get(key)
            results.append(result)

        return results
