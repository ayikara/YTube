-- ============================================================
-- ref.messaging_tiers  — Raw daily message count tiers
-- Generated: 2026-06-27 %:28 UTC
-- NOTE: Tiers are program-level, not quarter-specific.
-- Only update if MEP spec changes tier boundaries.
-- ============================================================

INSERT INTO `project.ref.messaging_tiers` (
  tier_id, min_raw_msgs, max_raw_msgs, benchmark_multiplier,
  is_excluded, label, effective_from, effective_to, notes, loaded_at
)
VALUES
  ('EXCLUDED', 0, 50000, NULL, TRUE, '<=50k', '2024-10-01', NULL, 'Firms at or below this threshold are excluded from MEP scoring entirely', CURRENT_TIMESTAMP()),
  ('TIER_3', 50001, 100000, 3.0, FALSE, '>50k', '2024-10-01', NULL, '3x product group benchmark applies', CURRENT_TIMESTAMP()),
  ('TIER_2', 100001, 150000, 2.0, FALSE, '>100k', '2024-10-01', NULL, '2x product group benchmark applies', CURRENT_TIMESTAMP()),
  ('TIER_1', 150001, NULL, 1.0, FALSE, '>150k', '2024-10-01', NULL, 'Base product group benchmark applies. max_raw_msgs null = no ceiling', CURRENT_TIMESTAMP());