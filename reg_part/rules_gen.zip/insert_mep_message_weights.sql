-- ============================================================
-- ref.mep_message_weights  — Per-message weighting factors
-- Generated: 2026-06-27 %:28 UTC
-- Source:    MEP v11.8
-- NOTE: Only update if MEP spec changes weighting factors.
-- ============================================================

INSERT INTO `project.ref.mep_message_weights` (
  session_type, month_type, instrument_type, msg_type, msg_description,
  ilink_tag, weight_factor, weight_is_per_order_cancelled,
  raw_count_is_per_order_cancelled, effective_from, effective_to,
  notes, loaded_at
)
VALUES
  ('RTH', 'FRONT', 'OUTRIGHT', 'D', 'New Order', '35-MsgType=D', 0, FALSE, FALSE, '2024-10-01', NULL, 'New orders always excluded from score', CURRENT_TIMESTAMP()),
  ('RTH', 'FRONT', 'OUTRIGHT', 'G', 'Order Modification', '35-MsgType=G', 1, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'FRONT', 'OUTRIGHT', 'F', 'Order Cancellation', '35-MsgType=F', 3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'FRONT', 'OUTRIGHT', 'CA', 'Order Mass Action Request', '35-MsgType=CA', 3, TRUE, TRUE, '2024-10-01', NULL, 'Weight factor applied per individual order cancelled, not per CA message. Same applies to raw message count for tier determination.', CURRENT_TIMESTAMP()),
  ('RTH', 'FRONT', 'OUTRIGHT', 'FAK', 'Fill and Kill elimination', 'Tag 59=3 (Fill and Kill)', 3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'FRONT', 'OUTRIGHT', 'MINQTY', 'MinQty elimination', 'Tag 110-MinQty', 3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'BACK', 'OUTRIGHT', 'D', 'New Order', '35-MsgType=D', 0, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'BACK', 'OUTRIGHT', 'G', 'Order Modification', '35-MsgType=G', 0.1, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'BACK', 'OUTRIGHT', 'F', 'Order Cancellation', '35-MsgType=F', 0.3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'BACK', 'OUTRIGHT', 'CA', 'Order Mass Action Request', '35-MsgType=CA', 0.3, TRUE, TRUE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'BACK', 'OUTRIGHT', 'FAK', 'Fill and Kill elimination', 'Tag 59=3', 0.3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'BACK', 'OUTRIGHT', 'MINQTY', 'MinQty elimination', 'Tag 110-MinQty', 0.3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'ALL', 'SPREAD', 'D', 'New Order', '35-MsgType=D', 0, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'ALL', 'SPREAD', 'G', 'Order Modification', '35-MsgType=G', 0.1, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'ALL', 'SPREAD', 'F', 'Order Cancellation', '35-MsgType=F', 0.3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'ALL', 'SPREAD', 'CA', 'Order Mass Action Request', '35-MsgType=CA', 0.3, TRUE, TRUE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'ALL', 'SPREAD', 'FAK', 'Fill and Kill elimination', 'Tag 59=3', 0.3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('RTH', 'ALL', 'SPREAD', 'MINQTY', 'MinQty elimination', 'Tag 110-MinQty', 0.3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('ETH', 'ALL', 'ALL', 'D', 'New Order', '35-MsgType=D', 0, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('ETH', 'ALL', 'ALL', 'G', 'Order Modification', '35-MsgType=G', 0.1, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('ETH', 'ALL', 'ALL', 'F', 'Order Cancellation', '35-MsgType=F', 0.3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('ETH', 'ALL', 'ALL', 'CA', 'Order Mass Action Request', '35-MsgType=CA', 0.3, TRUE, TRUE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('ETH', 'ALL', 'ALL', 'FAK', 'Fill and Kill elimination', 'Tag 59=3', 0.3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP()),
  ('ETH', 'ALL', 'ALL', 'MINQTY', 'MinQty elimination', 'Tag 110-MinQty', 0.3, FALSE, FALSE, '2024-10-01', NULL, '', CURRENT_TIMESTAMP());