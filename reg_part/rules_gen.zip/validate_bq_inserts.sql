-- ============================================================
-- VALIDATION QUERIES — Run after INSERT to verify data
-- Generated: 2026-06-27 %:28 UTC
-- ============================================================

-- 1. Count product groups loaded for Q3 2026
SELECT COUNT(*) AS product_group_count
FROM `project.ref.mep_rules`
WHERE effective_from = '2026-07-01';
-- Expected: 324 product groups

-- 2. Verify SS-SOFR has second_level_eval = TRUE
SELECT group_code, second_level_eval
FROM `project.ref.mep_rules`
WHERE group_code = 'SS' AND effective_to IS NULL;
-- Expected: second_level_eval = TRUE

-- 3. Spot check key benchmarks
SELECT group_code, tier_3_benchmark, tier_2_benchmark, tier_1_benchmark
FROM `project.ref.mep_rules`
WHERE group_code IN ('ES', 'SS', 'ZC', 'CL', 'GC')
  AND effective_to IS NULL
ORDER BY group_code;
-- Expected:
-- CL:  180 / 120 / 60
-- ES:   45 /  30 / 15
-- GC:   90 /  60 / 30
-- SS:   30 /  20 / 10
-- ZC:  150 / 100 / 50

-- 4. Verify tier thresholds
SELECT tier_id, min_raw_msgs, max_raw_msgs, benchmark_multiplier, is_excluded
FROM `project.ref.messaging_tiers`
ORDER BY min_raw_msgs;

-- 5. Verify message weights — RTH front month should have weight=1 for modifications
SELECT session_type, month_type, msg_type, weight_factor
FROM `project.ref.mep_message_weights`
WHERE session_type = 'RTH' AND month_type = 'FRONT'
ORDER BY msg_type;
-- Expected: G=1, F=3, CA=3, FAK=3, MINQTY=3, D=0

-- 6. Verify no duplicate active rows per product group
SELECT group_code, COUNT(*) AS active_rows
FROM `project.ref.mep_rules`
WHERE effective_to IS NULL
GROUP BY group_code
HAVING COUNT(*) > 1;
-- Expected: 0 rows (no duplicates)

-- 7. Mass quote benchmark count
SELECT COUNT(*) FROM `project.ref.mep_mass_quote_rules`
WHERE effective_to IS NULL;
-- Expected: 10 mass quote product groups