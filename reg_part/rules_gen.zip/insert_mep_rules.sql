-- ============================================================
-- ref.mep_rules  — MEP product group benchmark ratios
-- Generated: 2026-06-27 %:28 UTC
-- Source:    Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks
-- Quarter:   Q3 2026
-- REVIEW STATUS: PENDING_REVIEW
-- ============================================================

-- Expire previous Q2 benchmarks before inserting Q3
-- IMPORTANT: Review and adjust the effective_to date for prior quarter rows
UPDATE `project.ref.mep_rules`
   SET effective_to = '2026-06-30'
 WHERE effective_to IS NULL
   AND effective_from < '2026-07-01';

-- Insert Q3 2026 benchmarks
INSERT INTO `project.ref.mep_rules` (
  group_code, exchange, description, asset_class, instrument_type,
  tier_3_benchmark, tier_2_benchmark, tier_1_benchmark,
  second_level_eval, special_rules, effective_from, effective_to,
  source_document, source_quarter, loaded_at
)
VALUES
  ('ZC', 'CBOT', 'Corn Futures & Spreads', 'COMMODITY', 'FUTURES', 150, 100, 50, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ZS', 'CBOT', 'Soybean Futures & Spreads', 'COMMODITY', 'FUTURES', 165, 110, 55, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ZW', 'CBOT', 'Chicago SRW Wheat Futures & Spreads', 'COMMODITY', 'FUTURES', 150, 100, 50, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('KE', 'CBOT', 'KC HRW Wheat Futures & Spreads', 'COMMODITY', 'FUTURES', 150, 100, 50, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('OC', 'CBOT', 'Corn Options', 'COMMODITY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('SQ', 'CBOT', 'Soybean Options', 'COMMODITY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('OW', 'CBOT', 'Chicago SRW Wheat Options', 'COMMODITY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('GF', 'CME', 'Feeder Cattle Futures & Spreads', 'LIVESTOCK', 'FUTURES', 180, 120, 60, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('LE', 'CME', 'Live Cattle Futures & Spreads', 'LIVESTOCK', 'FUTURES', 60, 40, 20, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('HE', 'CME', 'Lean Hog Futures & Spreads', 'LIVESTOCK', 'FUTURES', 75, 50, 25, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('F0', 'CME', 'Feeder Cattle Options', 'LIVESTOCK', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('L0', 'CME', 'Live Cattle Options', 'LIVESTOCK', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('0H', 'CME', 'Lean Hog Options', 'LIVESTOCK', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ES', 'CME', 'E-mini S&P 500 Futures & Spreads', 'EQUITY', 'FUTURES', 45, 30, 15, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('MS', 'CME', 'Micro E-mini S&P 500 Futures & Spreads', 'EQUITY', 'FUTURES', 75, 50, 25, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ME', 'CME', 'E-mini S&P MidCap 400 Futures & Spreads', 'EQUITY', 'FUTURES', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('N1', 'CME', 'Nikkei 225 (Yen) Futures & Spreads', 'EQUITY', 'FUTURES', 270, 180, 90, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('NK', 'CME', 'Nikkei 225 (Dollar) Futures & Spreads', 'EQUITY', 'FUTURES', 360, 240, 120, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('NQ', 'CME', 'E-mini & Micro E-mini NASDAQ-100 Futures & Spreads', 'EQUITY', 'FUTURES', 180, 120, 60, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('RY', 'CME', 'E-mini & Micro E-mini Russell 2000 Index Futures & Spreads', 'EQUITY', 'FUTURES', 210, 140, 70, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('YM', 'CBOT', 'E-mini & Micro E-mini Dow ($5) Futures & Spreads', 'EQUITY', 'FUTURES', 210, 140, 70, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('EW', 'CME', 'E-Mini S&P 500 Outright, Weekly & Monthly Options', 'EQUITY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('QZ', 'CME', 'E-Mini NASDAQ 100 Outright Options', 'EQUITY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('NW', 'CME', 'E-Mini NASDAQ 100 Weekly & Monthly Options', 'EQUITY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('C9', 'CBOT', 'E-Mini Dow ($5) Outright Options', 'EQUITY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('OL', 'CBOT', 'E-Mini Dow ($5) Weekly & Monthly Options', 'EQUITY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('6A', 'CME', 'Australian Dollar Futures & Spreads', 'FX', 'FUTURES', 105, 70, 35, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('6B', 'CME', 'British Pound Futures & Spreads', 'FX', 'FUTURES', 105, 70, 35, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('6C', 'CME', 'Canadian Dollar Futures & Spreads', 'FX', 'FUTURES', 90, 60, 30, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('6E', 'CME', 'Euro FX Futures & Spreads', 'FX', 'FUTURES', 120, 80, 40, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('6J', 'CME', 'Japanese Yen Futures & Spreads', 'FX', 'FUTURES', 240, 120, 60, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('6S', 'CME', 'Swiss Franc Futures & Spreads', 'FX', 'FUTURES', 240, 120, 60, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('XA', 'CME', 'Australian Dollar Options (European Style)', 'FX', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('YB', 'CME', 'British Pound Options (European Style)', 'FX', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('CD', 'CME', 'Canadian Dollar Options (European Style)', 'FX', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('XE', 'CME', 'Euro FX Options (European Style)', 'FX', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('QJ', 'CME', 'Japanese Yen Options (European Style)', 'FX', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('YS', 'CME', 'Swiss Franc Options (European Style)', 'FX', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('SS', 'CME', 'Three-Month SOFR Futures & Spreads', 'RATES', 'FUTURES', 30, 20, 10, TRUE, JSON '["EMT_GFID_SOFR", "EMT_MPS_SOFR"]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ZQ', 'CBOT', '30 Day Federal Funds Futures & Spreads', 'RATES', 'FUTURES', 45, 30, 15, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ZT', 'CBOT', '2-Year U.S. Treasury Note Futures & Spreads', 'RATES', 'FUTURES', 45, 30, 15, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ZF', 'CBOT', '5-Year U.S. Treasury Note Futures & Spreads', 'RATES', 'FUTURES', 45, 30, 15, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ZN', 'CBOT', '10-Year U.S. Treasury Note Futures & Spreads', 'RATES', 'FUTURES', 45, 30, 15, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ZB', 'CBOT', '30-Year U.S. Treasury Bond Futures & Spreads', 'RATES', 'FUTURES', 45, 30, 15, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('Z1', 'CBOT', '10-Year U.S. Ultra Treasury Note Futures & Spreads', 'RATES', 'FUTURES', 60, 40, 20, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ZU', 'CBOT', '30-Year U.S. Ultra Treasury Bond Futures & Spreads', 'RATES', 'FUTURES', 75, 50, 25, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('JE', 'CME', 'Three-Month SOFR Options', 'RATES', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('J1_J2_J3_J4_J5_J6_J9_JT', 'CME', 'Three-Month SOFR MidCurve Options', 'RATES', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('N2', 'CBOT', '2-Year U.S. Treasury Note Options', 'RATES', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('0N', 'CBOT', '5-Year U.S. Treasury Note Options', 'RATES', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('TE', 'CBOT', '10-Year U.S. Treasury Note Options', 'RATES', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('UZ', 'CBOT', '30-Year U.S. Treasury Bond Options', 'RATES', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('UB', 'CBOT', '30-Year U.S. Ultra Treasury Bond Options', 'RATES', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('CL', 'NYMEX', 'Light Sweet Crude Oil (WTI), Heating Oil, RBOB, RBOB Heating Oil Spreads, Crack Spreads', 'ENERGY', 'FUTURES', 180, 120, 60, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('NG', 'NYMEX', 'Natural Gas Futures & Spreads', 'ENERGY', 'FUTURES', 90, 60, 30, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('OP', 'NYMEX', 'Brent Crude Oil Last Day Financial Futures & Spreads', 'ENERGY', 'FUTURES', 240, 160, 80, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('GC', 'COMEX', 'Gold Futures & Spreads', 'METALS', 'FUTURES', 90, 60, 30, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('SI', 'COMEX', 'Silver Futures & Spreads', 'METALS', 'FUTURES', 120, 80, 40, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('HG', 'COMEX', 'Copper Futures & Spreads', 'METALS', 'FUTURES', 195, 130, 65, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('LO', 'NYMEX', 'Crude Oil Options', 'ENERGY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('OH', 'NYMEX', 'NY Harbor ULSD Options', 'ENERGY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('OB', 'NYMEX', 'RBOB Gasoline Options', 'ENERGY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('OT', 'NYMEX', 'Brent Crude Oil Options', 'ENERGY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('ON', 'NYMEX', 'Natural Gas Options', 'ENERGY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('LG', 'NYMEX', 'Natural Gas Euro Options', 'ENERGY', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('OG', 'COMEX', 'Gold Options', 'METALS', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('SO', 'COMEX', 'Silver Options', 'METALS', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP()),
  ('1U', 'COMEX', 'Copper Options', 'METALS', 'OPTIONS', 300, 200, 100, FALSE, JSON '[]', '2026-07-01', NULL, 'Globex Futures & Options Messaging Efficiency Program Q3 2026 Daily Raw Messaging Tier Product Group Benchmarks', 'Q3 2026', CURRENT_TIMESTAMP());

-- Mass quote benchmarks
INSERT INTO `project.ref.mep_mass_quote_rules` (
  group_code, exchange, description, benchmark_ratio,
  effective_from, effective_to, source_quarter, loaded_at
)
VALUES
  ('EW', 'CME', 'E-Mini S&P 500 Options', 6000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP()),
  ('1V', 'CME', 'E-Mini S&P 500 Options Strategies', 15000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP()),
  ('NW', 'CME', 'E-Mini NASDAQ Options Outs', 30000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP()),
  ('EN', 'CME', 'Micro E-mini S&P 500 Options Strategies', 40000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP()),
  ('EO', 'CME', 'Micro E-mini S&P 500 Options Outs', 30000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP()),
  ('2V', 'CME', 'E-mini NASDAQ 100 Options Strategies', 50000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP()),
  ('NE', 'CME', 'Micro E-mini Nasdaq-100 Index Options Outs', 30000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP()),
  ('NF', 'CME', 'Micro E-mini Nasdaq-100 Options Strategies', 40000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP()),
  ('R4', 'CME', 'E-mini Russell 2000 Options Outs/Weekly/EOM', 30000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP()),
  ('R5', 'CME', 'E-mini Russell 2000 Options Strategies', 40000, '2026-07-01', NULL, 'Q3 2026', CURRENT_TIMESTAMP());