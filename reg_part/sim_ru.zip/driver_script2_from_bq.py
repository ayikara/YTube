"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  MEP Driver Script 2 — Parameters from BigQuery tables                      ║
║                                                                              ║
║  Use when:  BigQuery tables exist (post SQL insert from Script 1 lifecycle). ║
║             This is the production runtime path.                             ║
║                                                                              ║
║  Reads:     ref.mep_rules            (product group benchmarks)              ║
║             ref.messaging_tiers      (tier thresholds & multipliers)         ║
║             ref.mep_message_weights  (weighting factors)                     ║
║             ref.mep_rules_config     (EMT, exclusion, exemption params)      ║
║                                                                              ║
║  Simulated: BigQuery reads are replaced by in-memory DataFrames that         ║
║             mirror the exact schema of the BQ tables. In production,        ║
║             swap _simulate_bq_*() functions for real BQ client calls.       ║
║                                                                              ║
║  Runs:      MEP rule engine against identical simulated daily_scores data    ║
║  Outputs:   Console report + mep_results_from_bq.csv                        ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage:
    python3 driver_script2_from_bq.py
    python3 driver_script2_from_bq.py --trade-date 2026-07-15
    python3 driver_script2_from_bq.py --project my-gcp-project --dataset ref
"""

import csv
import sys
import json
import argparse
import textwrap
from pathlib import Path
from datetime import datetime, date

# Local modules
from mep_rule_logic import (
    MEPRuleEngine, DailyScore, ComplianceResult,
    TierEntry, WeightEntry, EMTParams, EMTMPSParams,
    SessionConfig,
)
from mep_simulated_data import (
    SIMULATED_SCORES, MARKET_MAKER_GFIDS,
    AUTO_WAIVERS_USED, MONTHLY_RATIOS, EXPECTED_RESULTS,
)

HERE = Path(__file__).parent
OUTPUT_CSV = HERE / "mep_results_from_bq.csv"


# ─────────────────────────────────────────────────────────────────────────────
# 1.  SIMULATED BQ TABLE READS
#     Each function returns a list[dict] — same shape as BQ query rows.
#     In production: replace body with google.cloud.bigquery client call.
# ─────────────────────────────────────────────────────────────────────────────

def _simulate_bq_query(label: str, rows: list[dict]) -> list[dict]:
    """Stub that logs as if a real BQ query ran."""
    print(f"  [BQ query] {label}")
    print(f"             → {len(rows)} rows returned")
    return rows


def _simulate_bq_mep_rules(trade_date: str) -> list[dict]:
    """
    Simulates:
        SELECT group_code, tier_1_benchmark, tier_2_benchmark, tier_3_benchmark,
               second_level_eval, JSON_VALUE(special_rules) AS special_rules
        FROM `project.ref.mep_rules`
        WHERE effective_from <= @trade_date
          AND (effective_to IS NULL OR effective_to >= @trade_date)

    Returns the base benchmark ratio per product group (tier_1 = highest volume tier).
    """
    # These values mirror insert_mep_rules.sql output for Q3 2026
    rows = [
        # Equity futures
        {"group_code":"ES","tier_1_benchmark":15,"tier_2_benchmark":30,"tier_3_benchmark":45,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"MS","tier_1_benchmark":25,"tier_2_benchmark":50,"tier_3_benchmark":75,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"NQ","tier_1_benchmark":60,"tier_2_benchmark":120,"tier_3_benchmark":180,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"YM","tier_1_benchmark":70,"tier_2_benchmark":140,"tier_3_benchmark":210,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"RY","tier_1_benchmark":70,"tier_2_benchmark":140,"tier_3_benchmark":210,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"ME","tier_1_benchmark":100,"tier_2_benchmark":200,"tier_3_benchmark":300,"second_level_eval":False,"special_rules":"[]"},
        # Rates futures
        {"group_code":"SS","tier_1_benchmark":10,"tier_2_benchmark":20,"tier_3_benchmark":30,"second_level_eval":True,"special_rules":json.dumps(["EMT_GFID_SOFR","EMT_MPS_SOFR"])},
        {"group_code":"ZQ","tier_1_benchmark":15,"tier_2_benchmark":30,"tier_3_benchmark":45,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"ZT","tier_1_benchmark":15,"tier_2_benchmark":30,"tier_3_benchmark":45,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"ZF","tier_1_benchmark":15,"tier_2_benchmark":30,"tier_3_benchmark":45,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"ZN","tier_1_benchmark":15,"tier_2_benchmark":30,"tier_3_benchmark":45,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"ZB","tier_1_benchmark":15,"tier_2_benchmark":30,"tier_3_benchmark":45,"second_level_eval":False,"special_rules":"[]"},
        # Energy & Metals
        {"group_code":"CL","tier_1_benchmark":60,"tier_2_benchmark":120,"tier_3_benchmark":180,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"NG","tier_1_benchmark":30,"tier_2_benchmark":60,"tier_3_benchmark":90,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"GC","tier_1_benchmark":30,"tier_2_benchmark":60,"tier_3_benchmark":90,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"SI","tier_1_benchmark":40,"tier_2_benchmark":80,"tier_3_benchmark":120,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"HG","tier_1_benchmark":65,"tier_2_benchmark":130,"tier_3_benchmark":195,"second_level_eval":False,"special_rules":"[]"},
        # FX futures
        {"group_code":"6E","tier_1_benchmark":40,"tier_2_benchmark":80,"tier_3_benchmark":120,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"6J","tier_1_benchmark":60,"tier_2_benchmark":120,"tier_3_benchmark":240,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"6B","tier_1_benchmark":35,"tier_2_benchmark":70,"tier_3_benchmark":105,"second_level_eval":False,"special_rules":"[]"},
        # Commodity futures
        {"group_code":"ZC","tier_1_benchmark":50,"tier_2_benchmark":100,"tier_3_benchmark":150,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"ZS","tier_1_benchmark":55,"tier_2_benchmark":110,"tier_3_benchmark":165,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"ZW","tier_1_benchmark":50,"tier_2_benchmark":100,"tier_3_benchmark":150,"second_level_eval":False,"special_rules":"[]"},
        # Livestock
        {"group_code":"LE","tier_1_benchmark":20,"tier_2_benchmark":40,"tier_3_benchmark":60,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"HE","tier_1_benchmark":25,"tier_2_benchmark":50,"tier_3_benchmark":75,"second_level_eval":False,"special_rules":"[]"},
        {"group_code":"GF","tier_1_benchmark":60,"tier_2_benchmark":120,"tier_3_benchmark":180,"second_level_eval":False,"special_rules":"[]"},
    ]
    return _simulate_bq_query(
        f"ref.mep_rules  WHERE effective_from<='{trade_date}' AND (effective_to IS NULL OR effective_to>='{trade_date}')",
        rows,
    )


def _simulate_bq_messaging_tiers(trade_date: str) -> list[dict]:
    """
    Simulates:
        SELECT tier_id, min_raw_msgs, max_raw_msgs,
               benchmark_multiplier, is_excluded
        FROM `project.ref.messaging_tiers`
        WHERE effective_from <= @trade_date
          AND (effective_to IS NULL OR effective_to >= @trade_date)
        ORDER BY min_raw_msgs
    """
    rows = [
        {"tier_id":"EXCLUDED","min_raw_msgs":0,       "max_raw_msgs":50000,  "benchmark_multiplier":None,"is_excluded":True},
        {"tier_id":"TIER_3",  "min_raw_msgs":50001,   "max_raw_msgs":100000, "benchmark_multiplier":3.0, "is_excluded":False},
        {"tier_id":"TIER_2",  "min_raw_msgs":100001,  "max_raw_msgs":150000, "benchmark_multiplier":2.0, "is_excluded":False},
        {"tier_id":"TIER_1",  "min_raw_msgs":150001,  "max_raw_msgs":None,   "benchmark_multiplier":1.0, "is_excluded":False},
    ]
    return _simulate_bq_query(
        f"ref.messaging_tiers  WHERE effective_from<='{trade_date}' ORDER BY min_raw_msgs",
        rows,
    )


def _simulate_bq_message_weights(trade_date: str) -> list[dict]:
    """
    Simulates:
        SELECT session_type, month_type, instrument_type, msg_type,
               weight_factor, weight_is_per_order_cancelled,
               raw_count_is_per_order_cancelled
        FROM `project.ref.mep_message_weights`
        WHERE effective_from <= @trade_date
          AND (effective_to IS NULL OR effective_to >= @trade_date)
    """
    # Full 24-entry weight table matching insert_mep_message_weights.sql
    rows = [
        # RTH FRONT OUTRIGHT
        {"session_type":"RTH","month_type":"FRONT","instrument_type":"OUTRIGHT","msg_type":"D",     "weight_factor":0,  "weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"FRONT","instrument_type":"OUTRIGHT","msg_type":"G",     "weight_factor":1,  "weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"FRONT","instrument_type":"OUTRIGHT","msg_type":"F",     "weight_factor":3,  "weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"FRONT","instrument_type":"OUTRIGHT","msg_type":"CA",    "weight_factor":3,  "weight_is_per_order_cancelled":True, "raw_count_is_per_order_cancelled":True},
        {"session_type":"RTH","month_type":"FRONT","instrument_type":"OUTRIGHT","msg_type":"FAK",   "weight_factor":3,  "weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"FRONT","instrument_type":"OUTRIGHT","msg_type":"MINQTY","weight_factor":3,  "weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        # RTH BACK OUTRIGHT
        {"session_type":"RTH","month_type":"BACK", "instrument_type":"OUTRIGHT","msg_type":"D",     "weight_factor":0,  "weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"BACK", "instrument_type":"OUTRIGHT","msg_type":"G",     "weight_factor":0.1,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"BACK", "instrument_type":"OUTRIGHT","msg_type":"F",     "weight_factor":0.3,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"BACK", "instrument_type":"OUTRIGHT","msg_type":"CA",    "weight_factor":0.3,"weight_is_per_order_cancelled":True, "raw_count_is_per_order_cancelled":True},
        {"session_type":"RTH","month_type":"BACK", "instrument_type":"OUTRIGHT","msg_type":"FAK",   "weight_factor":0.3,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"BACK", "instrument_type":"OUTRIGHT","msg_type":"MINQTY","weight_factor":0.3,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        # RTH ALL SPREAD
        {"session_type":"RTH","month_type":"ALL",  "instrument_type":"SPREAD",  "msg_type":"D",     "weight_factor":0,  "weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"ALL",  "instrument_type":"SPREAD",  "msg_type":"G",     "weight_factor":0.1,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"ALL",  "instrument_type":"SPREAD",  "msg_type":"F",     "weight_factor":0.3,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"ALL",  "instrument_type":"SPREAD",  "msg_type":"CA",    "weight_factor":0.3,"weight_is_per_order_cancelled":True, "raw_count_is_per_order_cancelled":True},
        {"session_type":"RTH","month_type":"ALL",  "instrument_type":"SPREAD",  "msg_type":"FAK",   "weight_factor":0.3,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"RTH","month_type":"ALL",  "instrument_type":"SPREAD",  "msg_type":"MINQTY","weight_factor":0.3,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        # ETH ALL ALL
        {"session_type":"ETH","month_type":"ALL",  "instrument_type":"ALL",     "msg_type":"D",     "weight_factor":0,  "weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"ETH","month_type":"ALL",  "instrument_type":"ALL",     "msg_type":"G",     "weight_factor":0.1,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"ETH","month_type":"ALL",  "instrument_type":"ALL",     "msg_type":"F",     "weight_factor":0.3,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"ETH","month_type":"ALL",  "instrument_type":"ALL",     "msg_type":"CA",    "weight_factor":0.3,"weight_is_per_order_cancelled":True, "raw_count_is_per_order_cancelled":True},
        {"session_type":"ETH","month_type":"ALL",  "instrument_type":"ALL",     "msg_type":"FAK",   "weight_factor":0.3,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
        {"session_type":"ETH","month_type":"ALL",  "instrument_type":"ALL",     "msg_type":"MINQTY","weight_factor":0.3,"weight_is_per_order_cancelled":False,"raw_count_is_per_order_cancelled":False},
    ]
    return _simulate_bq_query(
        f"ref.mep_message_weights  WHERE effective_from<='{trade_date}'",
        rows,
    )


def _simulate_bq_config_params(trade_date: str) -> dict:
    """
    Simulates a scalar config table that stores EMT thresholds, exclusion
    threshold, exemption rules, and session boundaries.
    Mirrors the non-benchmark fields of mep_rules_v11_8.json as BQ rows.

    In production this would be:
        SELECT param_key, param_value
        FROM `project.ref.mep_config_params`
        WHERE effective_from <= @trade_date
          AND (effective_to IS NULL OR effective_to >= @trade_date)
    then pivoted to a dict.
    """
    rows = [
        {"param_key":"exclusion_threshold",           "param_value":"50000"},
        {"param_key":"six_x_breach_multiplier",       "param_value":"6"},
        {"param_key":"auto_waivers_per_month",        "param_value":"1"},
        {"param_key":"rth_start_ct",                  "param_value":"07:00:00"},
        {"param_key":"rth_end_ct",                    "param_value":"16:00:00"},
        {"param_key":"rth_timezone",                  "param_value":"America/Chicago"},
        {"param_key":"spread_volume_multiplier",      "param_value":"3"},
        {"param_key":"emt_ilink_raw_threshold",       "param_value":"1000000"},
        {"param_key":"emt_ilink_ratio_threshold",     "param_value":"500"},
        {"param_key":"emt_gfid_general_raw_threshold","param_value":"10000000"},
        {"param_key":"emt_gfid_general_ratio_threshold","param_value":"500"},
        {"param_key":"emt_gfid_sofr_raw_threshold",   "param_value":"5000000"},
        {"param_key":"emt_gfid_sofr_ratio_threshold", "param_value":"50"},
        {"param_key":"emt_mps_sofr_threshold",        "param_value":"2000"},
        {"param_key":"emt_mps_sofr_surcharge",        "param_value":"5000"},
    ]
    _simulate_bq_query(
        f"ref.mep_config_params  WHERE effective_from<='{trade_date}'",
        rows,
    )
    return {r["param_key"]: r["param_value"] for r in rows}


# ─────────────────────────────────────────────────────────────────────────────
# 2.  ASSEMBLE ENGINE FROM BQ TABLE ROWS
#     Converts raw BQ row dicts into the typed objects MEPRuleEngine expects.
#     This is what the production loader does — BQ rows → engine objects.
# ─────────────────────────────────────────────────────────────────────────────

def build_engine_from_bq_rows(
    tier_rows: list[dict],
    weight_rows: list[dict],
    config: dict,
) -> MEPRuleEngine:
    """
    Constructs a synthetic 'rules' dict from BQ row data that matches
    the shape MEPRuleEngine.__init__ expects.
    This is the production adapter pattern:
        BQ row dicts  →  typed Python objects  →  MEPRuleEngine
    """

    def p(key, cast=str):
        return cast(config[key])

    # Build the rules dict that MEPRuleEngine parses
    rules = {
        "_metadata": {"source": "BigQuery tables", "trade_date": "runtime"},
        "session_definition": {
            "rth": {
                "start_time_ct": p("rth_start_ct"),
                "end_time_ct":   p("rth_end_ct"),
                "timezone":      p("rth_timezone"),
                "days": ["Monday","Tuesday","Wednesday","Thursday","Friday"],
            }
        },
        "message_weights": {
            "effective_from": "runtime",
            "effective_to":   None,
            "weights": [
                {
                    "session_type":    w["session_type"],
                    "month_type":      w["month_type"],
                    "instrument_type": w["instrument_type"],
                    "msg_type":        w["msg_type"],
                    "msg_description": w["msg_type"],
                    "ilink_tag":       w["msg_type"],
                    "weight_factor":   float(w["weight_factor"]),
                    "weight_is_per_order_cancelled":   w["weight_is_per_order_cancelled"],
                    "raw_count_is_per_order_cancelled":w["raw_count_is_per_order_cancelled"],
                }
                for w in weight_rows
            ],
        },
        "messaging_tiers": {
            "_description": "From ref.messaging_tiers",
            "effective_from": "runtime",
            "effective_to":   None,
            "tiers": [
                {
                    "tier_id":               t["tier_id"],
                    "min_raw_msgs":          int(t["min_raw_msgs"]),
                    "max_raw_msgs":          int(t["max_raw_msgs"]) if t["max_raw_msgs"] is not None else None,
                    "benchmark_multiplier":  float(t["benchmark_multiplier"]) if t["benchmark_multiplier"] is not None else None,
                    "is_excluded":           t["is_excluded"],
                    "label":                 t["tier_id"],
                    "notes":                 "",
                }
                for t in tier_rows
            ],
        },
        "exclusions": {
            "raw_message_exclusion_threshold": p("exclusion_threshold", int),
            "excluded_message_types_from_score": ["D"],
            "mass_quotes_excluded_from_standard_mep": True,
        },
        "exemptions_and_waivers": {
            "six_x_breach_threshold_multiplier": p("six_x_breach_multiplier", int),
            "auto_waiver_per_month_per_pg":       p("auto_waivers_per_month", int),
        },
        "emt_rules": {
            "gfid_emt_general": {
                "raw_message_threshold":   p("emt_gfid_general_raw_threshold", int),
                "volume_ratio_threshold":  p("emt_gfid_general_ratio_threshold", float),
            },
            "gfid_emt_sofr": {
                "product_group":           "SS",
                "raw_message_threshold":   p("emt_gfid_sofr_raw_threshold", int),
                "volume_ratio_threshold":  p("emt_gfid_sofr_ratio_threshold", float),
            },
            "gfid_emt_mps_sofr": {
                "product_group":                      "SS",
                "threshold":                          p("emt_mps_sofr_threshold", int),
                "surcharge_per_breach":               p("emt_mps_sofr_surcharge", int),
                "modifications_per_second_threshold": p("emt_mps_sofr_threshold", int),
            },
        },
        "market_maker_exemptions": {
            "exempt_products": ["SOFR futures","30 Day Federal Fund futures","E-mini S&P 400 futures"],
        },
    }

    return MEPRuleEngine(rules)


# ─────────────────────────────────────────────────────────────────────────────
# 3.  LOAD PARAMETERS — orchestrates all BQ reads
# ─────────────────────────────────────────────────────────────────────────────

def load_parameters_from_bq(
    trade_date: str,
    project: str,
    dataset: str,
) -> tuple[MEPRuleEngine, dict[str, float]]:

    print(f"\n{'─'*60}")
    print(f"STEP 1: Loading parameters from BigQuery")
    print(f"        Project: {project}   Dataset: {dataset}")
    print(f"        Trade date filter: {trade_date}")
    print(f"{'─'*60}")
    print(f"  (Simulated BQ reads — swap _simulate_bq_*() for real client calls)\n")

    tier_rows   = _simulate_bq_messaging_tiers(trade_date)
    weight_rows = _simulate_bq_message_weights(trade_date)
    pg_rows     = _simulate_bq_mep_rules(trade_date)
    config      = _simulate_bq_config_params(trade_date)

    engine = build_engine_from_bq_rows(tier_rows, weight_rows, config)

    print(f"\n  Engine initialised from BQ rows:")
    print(f"    Message weight entries : {len(engine._weights)}")
    print(f"    Messaging tiers        : {len(engine._tiers)}")
    print(f"    Exclusion threshold    : {engine._excl_thresh:,}")
    print(f"    6× breach multiplier   : {engine._6x_mult}×")
    print(f"    Auto-waivers/month     : {engine._auto_waivers_per_month}")
    print(f"    EMT general ratio      : {engine._emt_gen.volume_ratio_threshold}:1")
    print(f"    EMT SOFR ratio         : {engine._emt_sofr.volume_ratio_threshold}:1")
    print(f"    EMT MPS threshold      : {engine._emt_mps.modifications_per_second_threshold:,}/sec")

    # Build benchmark lookup from mep_rules rows
    benchmark_by_pg: dict[str, float] = {
        row["group_code"]: float(row["tier_1_benchmark"])
        for row in pg_rows
    }
    print(f"\n    Product groups from BQ : {len(benchmark_by_pg)}")
    print(f"    Sample benchmarks:")
    for code in ["ES", "SS", "ZN", "CL", "GC"]:
        val = benchmark_by_pg.get(code, "—")
        print(f"      {code:6s} tier-1 benchmark = {val}")

    return engine, benchmark_by_pg


# ─────────────────────────────────────────────────────────────────────────────
# 4.  RUN ENGINE  (identical to Script 1)
# ─────────────────────────────────────────────────────────────────────────────

def run_engine(
    engine: MEPRuleEngine,
    scores: list[DailyScore],
    benchmark_by_pg: dict[str, float],
) -> list[ComplianceResult]:
    print(f"\n{'─'*60}")
    print(f"STEP 2: Running MEP rule engine")
    print(f"{'─'*60}")
    print(f"  Input rows : {len(scores)} simulated daily_scores records")
    print(f"  Trade date : {scores[0].trade_date}")

    results = engine.run(
        daily_scores=scores,
        benchmark_by_pg=benchmark_by_pg,
        market_maker_gfids=MARKET_MAKER_GFIDS,
        auto_waivers_used=AUTO_WAIVERS_USED,
        monthly_ratios=MONTHLY_RATIOS,
    )
    print(f"  Output rows: {len(results)} compliance results")
    return results


# ─────────────────────────────────────────────────────────────────────────────
# 5.  RESULTS REPORT  (identical to Script 1)
# ─────────────────────────────────────────────────────────────────────────────

STATUS_COLOUR = {
    "PASS":             "\033[92m",
    "AUTO_WAIVED":      "\033[94m",
    "PASS_ON_MONTHLY":  "\033[96m",
    "POTENTIAL":        "\033[93m",
    "SURCHARGE_APPLIED":"\033[91m",
}
RESET = "\033[0m"

def _colour(status: str) -> str:
    return STATUS_COLOUR.get(status, "") + status + RESET


def print_results(results: list[ComplianceResult], source_label: str):
    print(f"\n{'─'*60}")
    print(f"STEP 3: Compliance results  [{source_label}]")
    print(f"{'─'*60}")

    print(f"\n  {'GFID':<6} {'PG':<5} {'Tier':<8} {'Ratio':>8} {'Eff.BM':>8} "
          f"{'Breach':>7} {'6×':>5} {'Slvl':>5} {'EMT-G':>6} {'MPS':>5} "
          f"{'MM':>4}  Status")
    print(f"  {'─'*6} {'─'*5} {'─'*8} {'─'*8} {'─'*8} "
          f"{'─'*7} {'─'*5} {'─'*5} {'─'*6} {'─'*5} "
          f"{'─'*4}  {'─'*18}")

    for r in results:
        ratio_str = f"{r.volume_ratio:.1f}" if r.volume_ratio is not None else "  N/A"
        bm_str    = f"{r.effective_benchmark:.1f}" if r.effective_benchmark else "  N/A"
        tier_str  = r.tier_id or "EXCL"

        flags = {
            "Breach": "✓" if r.is_daily_breach else "·",
            "6x":     "✓" if r.is_6x_breach else "·",
            "Slvl":   "✓" if r.is_second_level_breach else "·",
            "EMT-G":  "✓" if r.emt_gfid_breach else "·",
            "MPS":    "✓" if r.emt_mps_breach else "·",
            "MM":     "✓" if r.is_market_maker_exempt else "·",
        }

        print(f"  {r.gfid:<6} {r.product_group:<5} {tier_str:<8} "
              f"{ratio_str:>8} {bm_str:>8} "
              f"{flags['Breach']:>7} {flags['6x']:>5} {flags['Slvl']:>5} "
              f"{flags['EMT-G']:>6} {flags['MPS']:>5} {flags['MM']:>4}  "
              f"{_colour(r.status)}")

    from collections import Counter
    counts = Counter(r.status for r in results)
    print(f"\n  Summary:")
    for status, count in sorted(counts.items()):
        print(f"    {_colour(status):<30} {count:>3} firm-day{'s' if count>1 else ''}")


# ─────────────────────────────────────────────────────────────────────────────
# 6.  CROSS-SCRIPT RESULT COMPARISON
# ─────────────────────────────────────────────────────────────────────────────

def compare_with_json_results(results: list[ComplianceResult]):
    """
    Loads the CSV written by Script 1 and compares status values row-by-row.
    This is the key integration check: both scripts must produce identical
    results for the same simulated data.
    """
    json_csv = HERE / "mep_results_from_json.csv"
    print(f"\n{'─'*60}")
    print("STEP 4a: Cross-script comparison with Script 1 output")
    print(f"{'─'*60}")

    if not json_csv.exists():
        print(f"  ⚠  {json_csv.name} not found — run Script 1 first to generate it.")
        return

    with open(json_csv) as f:
        json_results = {
            (r["gfid"], r["product_group"]): r
            for r in csv.DictReader(f)
        }

    all_match = True
    for r in results:
        key = (r.gfid, r.product_group)
        j = json_results.get(key)
        if j is None:
            print(f"  ⚠  {r.gfid}/{r.product_group}: not found in Script 1 output")
            all_match = False
            continue
        if r.status != j["status"]:
            print(f"  ✗  {r.gfid}/{r.product_group}: BQ={r.status!r}  JSON={j['status']!r}  MISMATCH")
            all_match = False
        else:
            print(f"  ✓  {r.gfid}/{r.product_group}: {_colour(r.status):<30} matches Script 1")

    print(f"\n  {'✓ ALL RESULTS MATCH Script 1' if all_match else '✗ MISMATCHES FOUND — investigate parameter loading'}")


def validate_expected(results: list[ComplianceResult]) -> bool:
    print(f"\n{'─'*60}")
    print("STEP 4b: Validation against expected results")
    print(f"{'─'*60}")
    result_map = {(r.gfid, r.product_group): r for r in results}
    all_pass = True
    for (gfid, pg), expected in EXPECTED_RESULTS.items():
        actual = result_map.get((gfid, pg))
        if actual is None:
            print(f"  ✗  MISSING  {gfid}/{pg}")
            all_pass = False
            continue
        row_pass = True
        for field, exp_val in expected.items():
            act_val = getattr(actual, field, "FIELD_NOT_FOUND")
            if act_val != exp_val:
                print(f"  ✗  {gfid}/{pg}.{field}: expected={exp_val!r} actual={act_val!r}")
                row_pass = False
                all_pass = False
        if row_pass:
            exp_status = expected.get("status", "")
            print(f"  ✓  {gfid:<6}/{pg:<5}  {_colour(actual.status):<30}"
                  + (f"  (expected {exp_status})" if exp_status else ""))
    print(f"\n  {'✓ ALL VALIDATIONS PASSED' if all_pass else '✗ SOME VALIDATIONS FAILED'}")
    return all_pass


# ─────────────────────────────────────────────────────────────────────────────
# 7.  CSV EXPORT
# ─────────────────────────────────────────────────────────────────────────────

def export_csv(results: list[ComplianceResult], path: Path):
    fields = [
        "trade_date","gfid","product_group",
        "is_excluded","tier_id","benchmark_multiplier","effective_benchmark",
        "volume_ratio","is_daily_breach","is_6x_breach",
        "is_second_level_breach","is_market_maker_exempt",
        "emt_gfid_breach","emt_mps_breach","monthly_ratio","status",
    ]
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in results:
            writer.writerow({field: getattr(r, field, "") for field in fields})
    print(f"\n{'─'*60}")
    print(f"STEP 5: CSV export")
    print(f"{'─'*60}")
    print(f"  Written: {path}  ({len(results)} rows)")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(
        description="MEP Driver Script 2 — run rule engine with parameters from BigQuery tables",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
        Examples:
          python3 driver_script2_from_bq.py
          python3 driver_script2_from_bq.py --trade-date 2026-07-15
          python3 driver_script2_from_bq.py \\
              --project cme-compliance-prod \\
              --dataset ref \\
              --trade-date 2026-07-15
        """),
    )
    parser.add_argument("--trade-date", default="2026-07-15",
                        help="Trade date for effective-date BQ filter (YYYY-MM-DD)")
    parser.add_argument("--project", default="cme-compliance-dev",
                        help="GCP project for BQ client (informational in simulation mode)")
    parser.add_argument("--dataset", default="ref",
                        help="BQ dataset for rule tables (informational in simulation mode)")
    return parser.parse_args()


def main():
    args = parse_args()
    started = datetime.now()

    print(f"\n{'═'*60}")
    print(f"  MEP Rule Engine — Driver Script 2: Parameters from BigQuery")
    print(f"  Started: {started.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Mode:    SIMULATION (BQ reads are in-memory stubs)")
    print(f"{'═'*60}")
    print(f"\n  To use real BigQuery: replace _simulate_bq_*() calls in")
    print(f"  load_parameters_from_bq() with google.cloud.bigquery queries.")

    # 1. Load from BQ
    engine, benchmark_by_pg = load_parameters_from_bq(
        trade_date=args.trade_date,
        project=args.project,
        dataset=args.dataset,
    )

    # 2. Run engine on same simulated scores as Script 1
    results = run_engine(engine, SIMULATED_SCORES, benchmark_by_pg)

    # 3. Print results
    print_results(results, source_label="Parameters from BigQuery tables")

    # 4. Validate: cross-script comparison + expected results
    compare_with_json_results(results)
    validation_passed = validate_expected(results)

    # 5. Export CSV
    export_csv(results, OUTPUT_CSV)

    elapsed = (datetime.now() - started).total_seconds()
    print(f"\n{'═'*60}")
    print(f"  Completed in {elapsed:.2f}s  |  "
          f"Validation: {'PASSED' if validation_passed else 'FAILED'}")
    print(f"{'═'*60}\n")
    sys.exit(0 if validation_passed else 1)


if __name__ == "__main__":
    main()
