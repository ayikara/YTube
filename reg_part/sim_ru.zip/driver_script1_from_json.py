"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  MEP Driver Script 1 — Parameters from JSON files                           ║
║                                                                              ║
║  Use when:  BigQuery tables do NOT yet exist, or validating JSON extracts    ║
║             before loading to BQ.                                            ║
║                                                                              ║
║  Reads:     mep_benchmarks_q3_2026.json  (benchmarks, tiers)                ║
║             mep_rules_v11_8.json         (weights, EMT, logic params)        ║
║                                                                              ║
║  Runs:      MEP rule engine against simulated aggregated daily_scores data   ║
║  Outputs:   Console report + mep_results_from_json.csv                       ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage:
    python3 driver_script1_from_json.py
    python3 driver_script1_from_json.py --benchmarks path/to/benchmarks.json
                                        --rules      path/to/rules.json
"""

import json
import csv
import sys
import argparse
import textwrap
from pathlib import Path
from datetime import datetime

# Local modules — must be in same directory
from mep_rule_logic import MEPRuleEngine, DailyScore, ComplianceResult
from mep_simulated_data import (
    SIMULATED_SCORES, MARKET_MAKER_GFIDS,
    AUTO_WAIVERS_USED, MONTHLY_RATIOS, EXPECTED_RESULTS,
)

HERE = Path(__file__).parent
OUTPUT_CSV = HERE / "mep_results_from_json.csv"


# ─────────────────────────────────────────────────────────────────────────────
# 1.  PARAMETER LOADING FROM JSON
# ─────────────────────────────────────────────────────────────────────────────

def load_parameters_from_json(
    benchmarks_path: Path,
    rules_path: Path,
) -> tuple[MEPRuleEngine, dict[str, float]]:
    """
    Reads both JSON files and builds:
      - MEPRuleEngine  (weights, EMT params, exemption thresholds)
      - benchmark_by_pg  {product_group → tier_1 base benchmark}

    The messaging_tiers block is in the benchmarks file, not rules file.
    We merge it into the rules dict so MEPRuleEngine.__init__ finds it.

    Returns:
        engine          — ready-to-run rule engine
        benchmark_by_pg — dict used to look up the base benchmark per product group
    """
    print(f"\n{'─'*60}")
    print("STEP 1: Loading parameters from JSON files")
    print(f"{'─'*60}")

    # Load JSON files
    with open(benchmarks_path) as f:
        benchmarks = json.load(f)
    print(f"  ✓  Benchmarks loaded  ({benchmarks_path.name})")
    print(f"     Source:  {benchmarks['_metadata']['source_document']}")
    print(f"     Quarter: {benchmarks['_metadata']['quarter']}")
    print(f"     Status:  {benchmarks['_metadata']['status']}")

    with open(rules_path) as f:
        rules = json.load(f)
    print(f"  ✓  Rules loaded       ({rules_path.name})")
    print(f"     Source:  {rules['_metadata']['source_document']}")
    print(f"     Version: {rules['_metadata']['source_version']}")
    print(f"     Status:  {rules['_metadata']['status']}")

    # Merge messaging_tiers from benchmarks into rules dict
    # (tiers are in benchmarks file; engine expects them under rules['messaging_tiers'])
    rules["messaging_tiers"] = benchmarks["messaging_tiers"]

    # Build engine
    engine = MEPRuleEngine(rules)
    print(f"\n  Engine initialised:")
    print(f"    Message weight entries : {len(engine._weights)}")
    print(f"    Messaging tiers        : {len(engine._tiers)}")
    print(f"    Exclusion threshold    : {engine._excl_thresh:,} raw messages/day")
    print(f"    6× breach multiplier   : {engine._6x_mult}×")
    print(f"    Auto-waivers/month     : {engine._auto_waivers_per_month}")
    print(f"    EMT general ratio      : {engine._emt_gen.volume_ratio_threshold}:1  "
          f"(>{engine._emt_gen.raw_message_threshold/1e6:.0f}M msgs)")
    print(f"    EMT SOFR ratio         : {engine._emt_sofr.volume_ratio_threshold}:1  "
          f"(>{engine._emt_sofr.raw_message_threshold/1e6:.0f}M msgs)")
    print(f"    EMT MPS threshold      : {engine._emt_mps.modifications_per_second_threshold:,}/sec")

    # Flatten all product groups from benchmarks into lookup dict
    # Maps group_code → tier_1_benchmark (base ratio, multipliers applied by engine)
    benchmark_by_pg: dict[str, float] = {}
    pg_section = benchmarks["product_group_benchmarks"]
    for category_groups in pg_section.values():
        if not isinstance(category_groups, list):
            continue
        for g in category_groups:
            benchmark_by_pg[g["group_code"]] = float(g["tier_1_benchmark"])

    print(f"\n    Product groups loaded  : {len(benchmark_by_pg)}")
    print(f"    Sample benchmarks:")
    for code in ["ES", "SS", "ZN", "CL", "GC"]:
        val = benchmark_by_pg.get(code, "—")
        print(f"      {code:6s} tier-1 benchmark = {val}")

    return engine, benchmark_by_pg


# ─────────────────────────────────────────────────────────────────────────────
# 2.  RUN THE RULE ENGINE
# ─────────────────────────────────────────────────────────────────────────────

def run_engine(
    engine: MEPRuleEngine,
    scores: list[DailyScore],
    benchmark_by_pg: dict[str, float],
) -> list[ComplianceResult]:

    print(f"\n{'─'*60}")
    print(f"STEP 2: Running MEP rule engine")
    print(f"{'─'*60}")
    print(f"  Input rows : {len(scores)} simulated daily_scores records")
    print(f"  Trade date : {scores[0].trade_date}")

    results = engine.run(
        daily_scores=scores,
        benchmark_by_pg=benchmark_by_pg,
        market_maker_gfids=MARKET_MAKER_GFIDS,
        auto_waivers_used=AUTO_WAIVERS_USED,
        monthly_ratios=MONTHLY_RATIOS,
    )

    print(f"  Output rows: {len(results)} compliance results")
    return results


# ─────────────────────────────────────────────────────────────────────────────
# 3.  RESULTS REPORT
# ─────────────────────────────────────────────────────────────────────────────

STATUS_COLOUR = {
    "PASS":             "\033[92m",   # green
    "AUTO_WAIVED":      "\033[94m",   # blue
    "PASS_ON_MONTHLY":  "\033[96m",   # cyan
    "POTENTIAL":        "\033[93m",   # yellow
    "SURCHARGE_APPLIED":"\033[91m",   # red
}
RESET = "\033[0m"
BOLD  = "\033[1m"

def _colour(status: str) -> str:
    return STATUS_COLOUR.get(status, "") + status + RESET


def print_results(results: list[ComplianceResult], source_label: str):
    print(f"\n{'─'*60}")
    print(f"STEP 3: Compliance results  [{source_label}]")
    print(f"{'─'*60}")

    # Header
    print(f"\n  {'GFID':<6} {'PG':<5} {'Tier':<8} {'Ratio':>8} {'Eff.BM':>8} "
          f"{'Breach':>7} {'6×':>5} {'Slvl':>5} {'EMT-G':>6} {'MPS':>5} "
          f"{'MM':>4}  Status")
    print(f"  {'─'*6} {'─'*5} {'─'*8} {'─'*8} {'─'*8} "
          f"{'─'*7} {'─'*5} {'─'*5} {'─'*6} {'─'*5} "
          f"{'─'*4}  {'─'*18}")

    for r in results:
        ratio_str = f"{r.volume_ratio:.1f}" if r.volume_ratio is not None else "  N/A"
        bm_str    = f"{r.effective_benchmark:.1f}" if r.effective_benchmark else "  N/A"
        tier_str  = r.tier_id or "EXCL"

        flags = {
            "Breach": "✓" if r.is_daily_breach else "·",
            "6x":     "✓" if r.is_6x_breach else "·",
            "Slvl":   "✓" if r.is_second_level_breach else "·",
            "EMT-G":  "✓" if r.emt_gfid_breach else "·",
            "MPS":    "✓" if r.emt_mps_breach else "·",
            "MM":     "✓" if r.is_market_maker_exempt else "·",
        }

        print(f"  {r.gfid:<6} {r.product_group:<5} {tier_str:<8} "
              f"{ratio_str:>8} {bm_str:>8} "
              f"{flags['Breach']:>7} {flags['6x']:>5} {flags['Slvl']:>5} "
              f"{flags['EMT-G']:>6} {flags['MPS']:>5} {flags['MM']:>4}  "
              f"{_colour(r.status)}")

    # Summary counts
    from collections import Counter
    counts = Counter(r.status for r in results)
    print(f"\n  Summary:")
    for status, count in sorted(counts.items()):
        print(f"    {_colour(status):<30} {count:>3} firm-day{'s' if count>1 else ''}")


# ─────────────────────────────────────────────────────────────────────────────
# 4.  VALIDATION AGAINST EXPECTED RESULTS
# ─────────────────────────────────────────────────────────────────────────────

def validate_results(results: list[ComplianceResult]) -> bool:
    print(f"\n{'─'*60}")
    print("STEP 4: Validation against expected results")
    print(f"{'─'*60}")

    result_map = {(r.gfid, r.product_group): r for r in results}
    all_pass = True

    for (gfid, pg), expected in EXPECTED_RESULTS.items():
        actual = result_map.get((gfid, pg))
        if actual is None:
            print(f"  ✗  MISSING  {gfid}/{pg} — no result returned")
            all_pass = False
            continue

        row_pass = True
        for field, exp_val in expected.items():
            act_val = getattr(actual, field, "FIELD_NOT_FOUND")
            if act_val != exp_val:
                print(f"  ✗  {gfid}/{pg}.{field}: expected={exp_val!r}, actual={act_val!r}")
                row_pass = False
                all_pass = False

        if row_pass:
            exp_status = expected.get("status", "")
            print(f"  ✓  {gfid:<6}/{pg:<5}  "
                  f"{_colour(actual.status):<30}"
                  + (f"  (expected {exp_status})" if exp_status else ""))

    print(f"\n  {'✓ ALL VALIDATIONS PASSED' if all_pass else '✗ SOME VALIDATIONS FAILED'}")
    return all_pass


# ─────────────────────────────────────────────────────────────────────────────
# 5.  CSV EXPORT
# ─────────────────────────────────────────────────────────────────────────────

def export_csv(results: list[ComplianceResult], path: Path):
    fields = [
        "trade_date", "gfid", "product_group",
        "is_excluded", "tier_id", "benchmark_multiplier", "effective_benchmark",
        "volume_ratio", "is_daily_breach", "is_6x_breach",
        "is_second_level_breach", "is_market_maker_exempt",
        "emt_gfid_breach", "emt_mps_breach",
        "monthly_ratio", "status",
    ]
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in results:
            writer.writerow({field: getattr(r, field, "") for field in fields})

    print(f"\n{'─'*60}")
    print(f"STEP 5: CSV export")
    print(f"{'─'*60}")
    print(f"  Written: {path}  ({len(results)} rows)")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(
        description="MEP Driver Script 1 — run rule engine from JSON parameter files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
        Examples:
          python3 driver_script1_from_json.py
          python3 driver_script1_from_json.py \\
              --benchmarks /path/to/mep_benchmarks_q3_2026.json \\
              --rules      /path/to/mep_rules_v11_8.json
        """),
    )
    parser.add_argument(
        "--benchmarks", type=Path,
        default=HERE / "mep_benchmarks_q3_2026.json",
        help="Path to MEP benchmarks JSON file",
    )
    parser.add_argument(
        "--rules", type=Path,
        default=HERE / "mep_rules_v11_8.json",
        help="Path to MEP rules JSON file",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    started = datetime.now()

    print(f"\n{'═'*60}")
    print(f"  MEP Rule Engine — Driver Script 1: Parameters from JSON")
    print(f"  Started: {started.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'═'*60}")

    # 1. Load parameters from JSON
    engine, benchmark_by_pg = load_parameters_from_json(
        args.benchmarks, args.rules
    )

    # 2. Run engine on simulated data
    results = run_engine(engine, SIMULATED_SCORES, benchmark_by_pg)

    # 3. Print results table
    print_results(results, source_label="Parameters from JSON")

    # 4. Validate against expected
    validation_passed = validate_results(results)

    # 5. Export CSV
    export_csv(results, OUTPUT_CSV)

    elapsed = (datetime.now() - started).total_seconds()
    print(f"\n{'═'*60}")
    print(f"  Completed in {elapsed:.2f}s  |  "
          f"Validation: {'PASSED' if validation_passed else 'FAILED'}")
    print(f"{'═'*60}\n")
    sys.exit(0 if validation_passed else 1)


if __name__ == "__main__":
    main()
