"""
mep_simulated_data.py
Shared simulated daily aggregated message data for MEP driver scripts.

Represents the output of mep_calc.daily_scores in BigQuery —
one row per (trade_date, GFID, product_group) after all SQL aggregation.

Scenarios deliberately cover every significant branch in the rule engine:
  - Excluded (≤50k messages)
  - Tier 3 (50k-100k) — passing
  - Tier 2 (100k-150k) — breach, auto-waiver available
  - Tier 1 (>150k)    — breach, monthly ratio saves it
  - Tier 1             — 6× breach, no waiver possible
  - Second-level breach (SS product group)
  - EMT GFID breach
  - EMT MPS breach (SS, >2000 mods/sec)
  - Market maker exempt GFID
  - Zero volume (no trade day)
  - Monthly waiver exhausted → SURCHARGE_APPLIED
"""

from mep_rule_logic import DailyScore

TRADE_DATE = "2026-07-15"

# GFIDs used across scenarios
GFID_EXCLUDED        = "EXC"   # always ≤50k messages — excluded entirely
GFID_PASS            = "PSS"   # comfortable pass, all tiers
GFID_TIER3_PASS      = "T3P"   # Tier 3, ratio below 3× benchmark
GFID_TIER2_BREACH    = "T2B"   # Tier 2, ratio > 2× benchmark → breach
GFID_TIER1_6X        = "SIX"   # Tier 1, ratio > 6× benchmark
GFID_MONTHLY_SAVE    = "MNS"   # Daily breach but monthly ratio passes
GFID_SECOND_LEVEL    = "SLB"   # SS product group, per-second breach
GFID_EMT_GFID        = "EMG"   # GFID EMT breach
GFID_EMT_MPS         = "EMP"   # SS EMT MPS breach (>2000 mods/sec)
GFID_MARKET_MAKER    = "MMX"   # Registered market maker — auto-waived
GFID_ZERO_VOLUME     = "ZRV"   # No trades — zero volume denominator
GFID_SURCHARGE       = "SRC"   # Breach, waiver already used, month closed

SIMULATED_SCORES: list[DailyScore] = [

    # ── Excluded: ≤50,000 raw messages ───────────────────────────────────────
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_EXCLUDED, product_group="ES",
        raw_msg_count_total=35_000,
        messaging_score_total=1_500.0,
        volume_contracts_total=50,
        has_second_level_breach=False,
        modifications_per_second_max=None,
    ),

    # ── Tier 3 (50k–100k), ratio well below 3× benchmark ────────────────────
    # ES tier_3_benchmark = 45, so effective = 45×3 = 135. Ratio = 2000/100 = 20 → PASS
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_TIER3_PASS, product_group="ES",
        raw_msg_count_total=75_000,
        messaging_score_total=2_000.0,
        volume_contracts_total=100,
        has_second_level_breach=False,
        modifications_per_second_max=None,
    ),

    # ── Tier 2 (100k–150k), breach — auto-waiver available ───────────────────
    # ES tier_2_benchmark = 30, effective = 30×2 = 60. Ratio = 8000/100 = 80 → breach
    # Auto-waiver not yet used → AUTO_WAIVED
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_TIER2_BREACH, product_group="ES",
        raw_msg_count_total=120_000,
        messaging_score_total=8_000.0,
        volume_contracts_total=100,
        has_second_level_breach=False,
        modifications_per_second_max=None,
    ),

    # ── Tier 1 (>150k), 6× breach — no waivers ───────────────────────────────
    # ES tier_1_benchmark = 15. effective = 15×1 = 15. 6× = 90. Ratio = 2000/10 = 200 → 6× breach
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_TIER1_6X, product_group="ES",
        raw_msg_count_total=200_000,
        messaging_score_total=2_000.0,
        volume_contracts_total=10,
        has_second_level_breach=False,
        modifications_per_second_max=None,
    ),

    # ── Tier 1, daily breach but monthly aggregate ratio saves it ─────────────
    # ZN tier_1_benchmark = 15. Ratio today = 1500/50 = 30 → breach. Monthly = 12 → PASS_ON_MONTHLY
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_MONTHLY_SAVE, product_group="ZN",
        raw_msg_count_total=160_000,
        messaging_score_total=1_500.0,
        volume_contracts_total=50,
        has_second_level_breach=False,
        modifications_per_second_max=None,
    ),

    # ── SS product group — per-second breach ──────────────────────────────────
    # SS tier_1_benchmark = 10. has_second_level_breach=True → always daily breach
    # Ratio = 900/100 = 9 (below benchmark) but second-level breach overrides → POTENTIAL
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_SECOND_LEVEL, product_group="SS",
        raw_msg_count_total=180_000,
        messaging_score_total=900.0,
        volume_contracts_total=100,
        has_second_level_breach=True,
        modifications_per_second_max=850.0,
    ),

    # ── EMT GFID breach — exceeds both raw count and ratio thresholds ─────────
    # General GFID EMT: >10M msgs AND >500:1 ratio. Ratio = 6_000_000/10_000 = 600 → EMT breach
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_EMT_GFID, product_group="CL",
        raw_msg_count_total=12_000_000,
        messaging_score_total=6_000_000.0,
        volume_contracts_total=10_000,
        has_second_level_breach=False,
        modifications_per_second_max=None,
    ),

    # ── SS EMT MPS breach — mods/sec > 2000 ──────────────────────────────────
    # SS GFID EMT: >5M msgs AND >50:1. Plus MPS >2000 → separate $5k surcharge
    # Ratio = 300_000/4_000 = 75 → exceeds SOFR EMT 50:1 threshold
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_EMT_MPS, product_group="SS",
        raw_msg_count_total=6_000_000,
        messaging_score_total=300_000.0,
        volume_contracts_total=4_000,
        has_second_level_breach=False,
        modifications_per_second_max=2_450.0,  # exceeds 2000 MPS threshold
    ),

    # ── Market maker exempt GFID ─────────────────────────────────────────────
    # Ratio = 2000/20 = 100 → would breach ZQ benchmark (15), but MM exempt → AUTO_WAIVED
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_MARKET_MAKER, product_group="ZQ",
        raw_msg_count_total=160_000,
        messaging_score_total=2_000.0,
        volume_contracts_total=20,
        has_second_level_breach=False,
        modifications_per_second_max=None,
    ),

    # ── Zero volume — no trades on this date ─────────────────────────────────
    # Ratio = None (division by zero guarded) → PASS (not a breach)
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_ZERO_VOLUME, product_group="GC",
        raw_msg_count_total=80_000,
        messaging_score_total=500.0,
        volume_contracts_total=0,
        has_second_level_breach=False,
        modifications_per_second_max=None,
    ),

    # ── Tier 1 breach, auto-waiver already used, month closed ─────────────────
    # GC tier_1 = 30. Ratio = 5000/80 = 62.5 → breach. Monthly = 45 > 30 → fails.
    # Waiver used = 1 (already consumed). Month closed → SURCHARGE_APPLIED
    DailyScore(
        trade_date=TRADE_DATE, gfid=GFID_SURCHARGE, product_group="GC",
        raw_msg_count_total=200_000,
        messaging_score_total=5_000.0,
        volume_contracts_total=80,
        has_second_level_breach=False,
        modifications_per_second_max=None,
    ),
]

# ── Context data (mirrors what the Python engine reads from BQ or computes) ───

# Market maker registered GFIDs
MARKET_MAKER_GFIDS: set[str] = {GFID_MARKET_MAKER}

# Auto-waivers already used this calendar month: (gfid, product_group) → count
AUTO_WAIVERS_USED: dict[tuple, int] = {
    (GFID_TIER2_BREACH, "ES"): 0,   # not yet used — available
    (GFID_SECOND_LEVEL, "SS"): 1,   # already consumed
    (GFID_SURCHARGE,    "GC"): 1,   # already consumed
}

# Monthly aggregate ratios — None means month not yet closed
# Populated at month-end by monthly waiver job
MONTHLY_RATIOS: dict[tuple, float] = {
    (GFID_MONTHLY_SAVE, "ZN"): 12.0,   # below benchmark of 15 → PASS_ON_MONTHLY
    (GFID_SURCHARGE,    "GC"): 45.0,   # above benchmark of 30 → no monthly waiver
    # All others: None (month mid-cycle, not yet closed)
}

# Expected results — used by both scripts to validate output
EXPECTED_RESULTS: dict[tuple, dict] = {
    (GFID_EXCLUDED,     "ES"): {"status": "PASS",             "is_excluded": True},
    (GFID_TIER3_PASS,   "ES"): {"status": "PASS",             "is_excluded": False},
    (GFID_TIER2_BREACH, "ES"): {"status": "AUTO_WAIVED",      "is_daily_breach": True},
    (GFID_TIER1_6X,     "ES"): {"status": "SURCHARGE_APPLIED","is_6x_breach": True},
    (GFID_MONTHLY_SAVE, "ZN"): {"status": "PASS_ON_MONTHLY",  "is_daily_breach": True},
    (GFID_SECOND_LEVEL, "SS"): {"status": "POTENTIAL",        "is_second_level_breach": True},
    (GFID_EMT_GFID,     "CL"): {"emt_gfid_breach": True},
    (GFID_EMT_MPS,      "SS"): {"emt_mps_breach": True,       "emt_gfid_breach": True},
    (GFID_MARKET_MAKER, "ZQ"): {"status": "AUTO_WAIVED",      "is_market_maker_exempt": True},
    (GFID_ZERO_VOLUME,  "GC"): {"status": "PASS",             "volume_ratio": None},
    (GFID_SURCHARGE,    "GC"): {"status": "SURCHARGE_APPLIED","is_daily_breach": True},
}
