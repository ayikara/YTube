"""
bq_config.py
Single place to configure your GCP project and BigQuery dataset.
Change these values to match your environment.
"""

# ── Change these to match your GCP environment ────────────────────────────
PROJECT_ID = "your-gcp-project-id"       # e.g. "cme-mep-dev-12345"
DATASET    = "mep_poc"                    # dataset will be created if it doesn't exist
LOCATION   = "US"                         # BigQuery dataset location

# ── Derived table names (project.dataset.table) ──────────────────────────
def table(name: str) -> str:
    """Returns fully qualified table name: project.dataset.table"""
    return f"{PROJECT_ID}.{DATASET}.{name}"

# Table names used across the POC
T_BENCHMARKS      = table("benchmarks")
T_MESSAGING_TIERS = table("messaging_tiers")
T_MESSAGE_WEIGHTS = table("message_weights")
T_ORDER_DATA      = table("order_data")
T_DAILY_SCORES    = table("daily_scores")
T_COMPLIANCE      = table("compliance_results")
