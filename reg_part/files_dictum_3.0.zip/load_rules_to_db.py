"""
Step 1: load_rules_to_db.py
Reads JSON files and sample CSV, creates BigQuery tables, and inserts data.

In production: this is generate_bq_sql.py → scheduled BQ INSERT.
In POC: we use the BigQuery Python client to create tables and load data.

This demonstrates:
  - How JSON parameters become BigQuery rows
  - How every row carries rule_id + spec_ref for traceability
  - How the BQ client creates datasets/tables programmatically
"""

import json
import csv
from pathlib import Path
from google.cloud import bigquery

import bq_config as cfg


def ensure_dataset(client: bigquery.Client):
    """Create the dataset if it doesn't exist."""
    dataset_ref = bigquery.DatasetReference(cfg.PROJECT_ID, cfg.DATASET)
    dataset = bigquery.Dataset(dataset_ref)
    dataset.location = cfg.LOCATION

    try:
        client.get_dataset(dataset_ref)
        print(f"  Dataset {cfg.PROJECT_ID}.{cfg.DATASET} already exists")
    except Exception:
        client.create_dataset(dataset, exists_ok=True)
        print(f"  Dataset {cfg.PROJECT_ID}.{cfg.DATASET} created")


def create_and_load_benchmarks(client: bigquery.Client, json_path: str):
    """Create benchmarks table and load from JSON."""

    # Define schema explicitly (mirrors the design doc)
    schema = [
        bigquery.SchemaField("benchmark_id",  "STRING"),
        bigquery.SchemaField("group_code",    "STRING"),
        bigquery.SchemaField("exchange",      "STRING"),
        bigquery.SchemaField("description",   "STRING"),
        bigquery.SchemaField("tier_1",        "FLOAT64"),
        bigquery.SchemaField("tier_2",        "FLOAT64"),
        bigquery.SchemaField("tier_3",        "FLOAT64"),
        bigquery.SchemaField("source_page",   "STRING"),
        bigquery.SchemaField("effective_from", "STRING"),
    ]

    # Create or replace table
    table = bigquery.Table(cfg.T_BENCHMARKS, schema=schema)
    client.delete_table(cfg.T_BENCHMARKS, not_found_ok=True)
    client.create_table(table)

    # Load data from JSON
    with open(json_path) as f:
        data = json.load(f)

    effective = data["_metadata"]["effective_from"]
    rows = []
    for b in data["benchmarks"]:
        rows.append({
            "benchmark_id":  b["benchmark_id"],
            "group_code":    b["group_code"],
            "exchange":      b["exchange"],
            "description":   b["description"],
            "tier_1":        b["tier_1"],
            "tier_2":        b["tier_2"],
            "tier_3":        b["tier_3"],
            "source_page":   b["source_page"],
            "effective_from": effective,
        })

    errors = client.insert_rows_json(cfg.T_BENCHMARKS, rows)
    if errors:
        print(f"  ✗ Benchmark insert errors: {errors}")
    else:
        print(f"  ✓ Benchmarks loaded: {len(rows)} product groups → {cfg.T_BENCHMARKS}")

    return len(rows)


def create_and_load_tiers(client: bigquery.Client, json_path: str):
    """Create messaging_tiers table and load from JSON."""

    schema = [
        bigquery.SchemaField("tier_id",    "STRING"),
        bigquery.SchemaField("min_msgs",   "INT64"),
        bigquery.SchemaField("max_msgs",   "INT64"),
        bigquery.SchemaField("multiplier", "FLOAT64"),
        bigquery.SchemaField("excluded",   "BOOL"),
    ]

    table = bigquery.Table(cfg.T_MESSAGING_TIERS, schema=schema)
    client.delete_table(cfg.T_MESSAGING_TIERS, not_found_ok=True)
    client.create_table(table)

    with open(json_path) as f:
        data = json.load(f)

    rows = []
    for t in data["messaging_tiers"]:
        rows.append({
            "tier_id":    t["tier_id"],
            "min_msgs":   t["min_msgs"],
            "max_msgs":   t["max_msgs"],
            "multiplier": t["multiplier"],
            "excluded":   t["excluded"],
        })

    errors = client.insert_rows_json(cfg.T_MESSAGING_TIERS, rows)
    if errors:
        print(f"  ✗ Tier insert errors: {errors}")
    else:
        print(f"  ✓ Messaging tiers loaded: {len(rows)} tiers → {cfg.T_MESSAGING_TIERS}")

    return len(rows)


def create_and_load_weights(client: bigquery.Client, json_path: str):
    """Create message_weights table and load from JSON."""

    schema = [
        bigquery.SchemaField("rule_id",    "STRING"),
        bigquery.SchemaField("session",    "STRING"),
        bigquery.SchemaField("month_type", "STRING"),
        bigquery.SchemaField("msg_type",   "STRING"),
        bigquery.SchemaField("weight",     "FLOAT64"),
        bigquery.SchemaField("spec_ref",   "STRING"),
    ]

    table = bigquery.Table(cfg.T_MESSAGE_WEIGHTS, schema=schema)
    client.delete_table(cfg.T_MESSAGE_WEIGHTS, not_found_ok=True)
    client.create_table(table)

    with open(json_path) as f:
        data = json.load(f)

    rows = []
    for w in data["message_weights"]:
        rows.append({
            "rule_id":    w["rule_id"],
            "session":    w["session"],
            "month_type": w["month_type"],
            "msg_type":   w["msg_type"],
            "weight":     w["weight"],
            "spec_ref":   w["spec_ref"],
        })

    errors = client.insert_rows_json(cfg.T_MESSAGE_WEIGHTS, rows)
    if errors:
        print(f"  ✗ Weight insert errors: {errors}")
    else:
        print(f"  ✓ Message weights loaded: {len(rows)} rules → {cfg.T_MESSAGE_WEIGHTS}")

    return len(rows)


def create_and_load_order_data(client: bigquery.Client, csv_path: str):
    """Create order_data table and load from CSV."""

    schema = [
        bigquery.SchemaField("trade_date",          "STRING"),
        bigquery.SchemaField("account",             "STRING"),
        bigquery.SchemaField("sessionid",           "STRING"),
        bigquery.SchemaField("symbol",              "STRING"),
        bigquery.SchemaField("securitydescription", "STRING"),
        bigquery.SchemaField("firm",                "STRING"),
        bigquery.SchemaField("session",             "STRING"),
        bigquery.SchemaField("orders",              "INT64"),
        bigquery.SchemaField("modifications",       "INT64"),
        bigquery.SchemaField("cancels",             "INT64"),
        bigquery.SchemaField("elimination",         "INT64"),
        bigquery.SchemaField("trade_volume",        "INT64"),
    ]

    table = bigquery.Table(cfg.T_ORDER_DATA, schema=schema)
    client.delete_table(cfg.T_ORDER_DATA, not_found_ok=True)
    client.create_table(table)

    # Read CSV and insert
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            rows.append({
                "trade_date":          row["trade_date"],
                "account":             row["account"],
                "sessionid":           row["sessionid"],
                "symbol":              row["symbol"],
                "securitydescription": row["securitydescription"],
                "firm":                row["firm"],
                "session":             row["session"],
                "orders":              int(row["orders"]),
                "modifications":       int(row["modifications"]),
                "cancels":             int(row["cancels"]),
                "elimination":         int(row["elimination"]),
                "trade_volume":        int(row["trade_volume"]),
            })

    errors = client.insert_rows_json(cfg.T_ORDER_DATA, rows)
    if errors:
        print(f"  ✗ Order data insert errors: {errors}")
    else:
        print(f"  ✓ Order data loaded: {len(rows)} rows → {cfg.T_ORDER_DATA}")

    return len(rows)


def verify_load(client: bigquery.Client):
    """Run quick verification queries against loaded tables."""
    print(f"\n  Verification queries:")

    # Check benchmark for ES
    query = f"SELECT * FROM `{cfg.T_BENCHMARKS}` WHERE group_code = 'ES'"
    row = list(client.query(query).result())[0]
    print(f"    ES benchmark: tier_1={row.tier_1}, tier_2={row.tier_2}, "
          f"tier_3={row.tier_3} (source: {row.source_page})")

    # Check RTH FRONT weights
    query = f"""
        SELECT rule_id, msg_type, weight, spec_ref
        FROM `{cfg.T_MESSAGE_WEIGHTS}`
        WHERE session = 'RTH' AND month_type = 'FRONT'
        ORDER BY msg_type
    """
    print(f"    RTH FRONT weights:")
    for row in client.query(query).result():
        print(f"      {row.rule_id:25s} {row.msg_type:15s} weight={row.weight}  ({row.spec_ref})")

    # Check row count in order_data
    query = f"SELECT COUNT(*) as cnt FROM `{cfg.T_ORDER_DATA}`"
    cnt = list(client.query(query).result())[0].cnt
    print(f"    Order data rows: {cnt}")


def run(benchmarks_json: str, rules_json: str, data_csv: str):
    """Execute Step 1: load all JSON + CSV data into BigQuery."""
    client = bigquery.Client(project=cfg.PROJECT_ID)

    ensure_dataset(client)

    print(f"\n  Loading into {cfg.PROJECT_ID}.{cfg.DATASET}:\n")

    create_and_load_benchmarks(client, benchmarks_json)
    create_and_load_tiers(client, benchmarks_json)
    create_and_load_weights(client, rules_json)
    create_and_load_order_data(client, data_csv)

    # BQ streaming inserts have a brief delay before data is queryable
    import time
    print(f"\n  Waiting 10s for BQ streaming buffer to flush...")
    time.sleep(10)

    verify_load(client)

    return True
