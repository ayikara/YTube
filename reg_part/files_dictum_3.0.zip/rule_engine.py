"""
Step 3: rule_engine.py
Python rule logic — reads daily_scores from BigQuery and applies MEP rules.

Each function implements a specific rule from the MEP spec.
The rule_id in the docstring matches mep_logic_rules.json.

This is identical logic to the SQLite POC — only the data source changed.
The rule functions themselves have zero BQ dependency (pure functions).
BQ interaction is isolated to the run() orchestrator.
"""

import json
from dataclasses import dataclass, field
from google.cloud import bigquery

import bq_config as cfg


@dataclass
class DailyScore:
    """One row from daily_scores — input to the rule engine."""
    trade_date: str
    gfid: str
    product_group: str
    raw_msg_count: int
    messaging_score: float
    volume: int


@dataclass
class ComplianceResult:
    """Output of the rule engine for one GFID × product_group."""
    gfid: str
    product_group: str
    raw_msg_count: int
    messaging_score: float
    volume: int
    is_excluded: bool = False
    tier: str = ""
    effective_benchmark: float = 0.0
    volume_ratio: float = 0.0
    is_breach: bool = False
    is_6x_breach: bool = False
    status: str = "PASS"
    notes: str = ""


# ══════════════════════════════════════════════════════════════════════════
# RULE FUNCTIONS — Pure logic, no BQ dependency
# Each function documents its rule_id from mep_logic_rules.json
# ══════════════════════════════════════════════════════════════════════════

def is_excluded(raw_msg_count: int, threshold: int) -> bool:
    """
    Rule: EXCL-50K  (Section 3, page 6)
    Firms with <= threshold raw daily messages per product group are excluded.
    """
    return raw_msg_count <= threshold


def assign_tier(raw_msg_count: int, tiers: list[dict]) -> dict:
    """
    Rule: TIER-ASSIGN  (Section 6)
    Finds the tier whose range contains the raw message count.
    """
    for tier in sorted(tiers, key=lambda t: t["min_msgs"]):
        if raw_msg_count <= tier["max_msgs"]:
            return tier
    return tiers[-1]


def calculate_ratio(messaging_score: float, volume: int) -> float | None:
    """
    Rule: RATIO-CALC  (Section 4)
    Volume Ratio = messaging_score / volume. None if volume is zero.
    """
    if volume == 0:
        return None
    return messaging_score / volume


def check_breach(ratio: float | None, effective_benchmark: float) -> bool:
    """
    Rule: BREACH-DAILY  (Section 4 + Section 11)
    Non-compliant if ratio exceeds the effective benchmark.
    """
    if ratio is None:
        return False
    return ratio > effective_benchmark


def check_6x_breach(ratio: float | None, effective_benchmark: float,
                     multiplier: int) -> bool:
    """
    Rule: EXEMPT-6X-BLOCK  (Section 11, Bullet 1 sub-clause)
    6x breach blocks ALL automatic waivers.
    """
    if ratio is None:
        return False
    return ratio > (multiplier * effective_benchmark)


def exemption_waterfall(is_breach: bool, is_6x: bool,
                         waiver_available: bool) -> str:
    """
    Rules (priority order):
      BREACH-DAILY       → no breach: PASS
      EXEMPT-6X-BLOCK    → 6x breach: SURCHARGE_APPLIED
      EXEMPT-AUTO-WAIV   → waiver available: AUTO_WAIVED
      Otherwise           → POTENTIAL
    """
    if not is_breach:
        return "PASS"
    if is_6x:
        return "SURCHARGE_APPLIED"
    if waiver_available:
        return "AUTO_WAIVED"
    return "POTENTIAL"


def check_emt(gfid: str, product_group: str, raw_msg_count: int,
              ratio: float | None, emt_params: dict) -> bool:
    """
    Rule: EMT-GFID-SOFR  (Section 16, paragraph 5)
    Both raw count AND ratio must exceed thresholds simultaneously.
    """
    if ratio is None:
        return False
    if product_group == emt_params.get("product_group", ""):
        return (raw_msg_count > emt_params["raw_threshold"]
                and ratio > emt_params["ratio_threshold"])
    return False


# ══════════════════════════════════════════════════════════════════════════
# ORCHESTRATOR — reads BQ, calls pure functions, writes BQ
# ══════════════════════════════════════════════════════════════════════════

def load_params_from_bq(client: bigquery.Client) -> tuple:
    """Load rule parameters from BigQuery tables."""

    # Tiers
    tiers = [
        {"tier_id": r.tier_id, "min_msgs": r.min_msgs,
         "max_msgs": r.max_msgs, "multiplier": r.multiplier,
         "excluded": r.excluded}
        for r in client.query(
            f"SELECT * FROM `{cfg.T_MESSAGING_TIERS}` ORDER BY min_msgs"
        ).result()
    ]

    # Benchmarks
    benchmarks = {
        r.group_code: {"tier_1": r.tier_1, "tier_2": r.tier_2, "tier_3": r.tier_3}
        for r in client.query(
            f"SELECT group_code, tier_1, tier_2, tier_3 FROM `{cfg.T_BENCHMARKS}`"
        ).result()
    }

    # Daily scores
    scores = [
        DailyScore(
            trade_date=r.trade_date, gfid=r.gfid,
            product_group=r.product_group,
            raw_msg_count=r.raw_msg_count_total,
            messaging_score=r.messaging_score_total,
            volume=r.volume_total,
        )
        for r in client.query(
            f"SELECT * FROM `{cfg.T_DAILY_SCORES}` ORDER BY gfid, product_group"
        ).result()
    ]

    return tiers, benchmarks, scores


def write_results_to_bq(client: bigquery.Client, results: list[ComplianceResult]):
    """Write compliance results back to BigQuery."""

    schema = [
        bigquery.SchemaField("gfid",                "STRING"),
        bigquery.SchemaField("product_group",       "STRING"),
        bigquery.SchemaField("raw_msg_count",       "INT64"),
        bigquery.SchemaField("messaging_score",     "FLOAT64"),
        bigquery.SchemaField("volume",              "INT64"),
        bigquery.SchemaField("tier",                "STRING"),
        bigquery.SchemaField("effective_benchmark",  "FLOAT64"),
        bigquery.SchemaField("volume_ratio",         "FLOAT64"),
        bigquery.SchemaField("is_breach",           "BOOL"),
        bigquery.SchemaField("is_6x_breach",        "BOOL"),
        bigquery.SchemaField("status",              "STRING"),
        bigquery.SchemaField("notes",               "STRING"),
    ]

    table = bigquery.Table(cfg.T_COMPLIANCE, schema=schema)
    client.delete_table(cfg.T_COMPLIANCE, not_found_ok=True)
    client.create_table(table)

    rows = [
        {
            "gfid": r.gfid, "product_group": r.product_group,
            "raw_msg_count": r.raw_msg_count,
            "messaging_score": r.messaging_score,
            "volume": r.volume, "tier": r.tier,
            "effective_benchmark": r.effective_benchmark,
            "volume_ratio": r.volume_ratio,
            "is_breach": r.is_breach, "is_6x_breach": r.is_6x_breach,
            "status": r.status, "notes": r.notes,
        }
        for r in results
    ]

    errors = client.insert_rows_json(cfg.T_COMPLIANCE, rows)
    if errors:
        print(f"  ✗ Result insert errors: {errors}")
    else:
        print(f"\n  ✓ Results written to {cfg.T_COMPLIANCE} ({len(rows)} rows)")


def run(rules_json_path: str):
    """Execute Step 3: apply rule engine to daily_scores from BigQuery."""
    client = bigquery.Client(project=cfg.PROJECT_ID)

    # Load scalar params from JSON (in production: from mep_config_params table)
    with open(rules_json_path) as f:
        rules = json.load(f)
    excl_threshold = rules["exclusion_threshold"]
    six_x_mult = rules["six_x_multiplier"]
    emt_sofr = rules["emt_gfid_sofr"]

    # Load structured params from BQ tables
    tiers, benchmarks, scores = load_params_from_bq(client)

    print(f"\n  Parameters loaded from BigQuery:")
    print(f"    Tiers: {len(tiers)}")
    print(f"    Benchmarks: {len(benchmarks)} product groups")
    print(f"    Daily scores: {len(scores)} GFID × product group rows")
    print(f"    Exclusion threshold: {excl_threshold:,} (from JSON)")

    waivers_used: dict[tuple, int] = {}
    results = []

    print(f"\n  Processing:\n")
    print(f"  {'GFID':<6} {'PG':<5} {'RawMsgs':>8} {'Score':>10} {'Vol':>6} "
          f"{'Ratio':>7} {'BM':>5} {'Tier':<8} Status")
    print(f"  {'─'*6} {'─'*5} {'─'*8} {'─'*10} {'─'*6} "
          f"{'─'*7} {'─'*5} {'─'*8} {'─'*18}")

    for s in scores:
        r = ComplianceResult(
            gfid=s.gfid, product_group=s.product_group,
            raw_msg_count=s.raw_msg_count,
            messaging_score=s.messaging_score, volume=s.volume,
        )

        # Step 1: Exclusion check (Rule: EXCL-50K)
        if is_excluded(s.raw_msg_count, excl_threshold):
            r.is_excluded = True
            r.status = "PASS"
            r.tier = "EXCLUDED"
            r.notes = f"raw_msgs={s.raw_msg_count:,} <= {excl_threshold:,}"
            results.append(r)
            _print_row(r)
            continue

        # Step 2: Tier assignment (Rule: TIER-ASSIGN)
        tier = assign_tier(s.raw_msg_count, tiers)
        r.tier = tier["tier_id"]

        bm = benchmarks.get(s.product_group)
        if bm is None:
            r.status = "PASS"
            r.notes = f"{s.product_group} not in MEP benchmarks"
            results.append(r)
            _print_row(r)
            continue

        # Effective benchmark from the matching tier column
        if tier["tier_id"] == "TIER_3":
            r.effective_benchmark = bm["tier_3"]
        elif tier["tier_id"] == "TIER_2":
            r.effective_benchmark = bm["tier_2"]
        else:
            r.effective_benchmark = bm["tier_1"]

        # Step 3: Volume ratio (Rule: RATIO-CALC)
        ratio = calculate_ratio(s.messaging_score, s.volume)
        r.volume_ratio = ratio or 0.0

        # Step 4: Breach check (Rule: BREACH-DAILY)
        r.is_breach = check_breach(ratio, r.effective_benchmark)

        # Step 5: 6x check (Rule: EXEMPT-6X-BLOCK)
        r.is_6x_breach = check_6x_breach(ratio, r.effective_benchmark, six_x_mult)

        # Step 6: Exemption waterfall
        key = (s.gfid, s.product_group)
        waiver_available = waivers_used.get(key, 0) < rules["auto_waivers_per_month"]
        r.status = exemption_waterfall(r.is_breach, r.is_6x_breach, waiver_available)

        if r.status == "AUTO_WAIVED":
            waivers_used[key] = waivers_used.get(key, 0) + 1

        r.notes = (f"ratio={r.volume_ratio:.1f} vs bm={r.effective_benchmark:.0f} "
                   f"({r.tier})")

        # Step 7: EMT check (Rule: EMT-GFID-SOFR)
        if check_emt(s.gfid, s.product_group, s.raw_msg_count, ratio, emt_sofr):
            r.notes += " | EMT BREACH"

        results.append(r)
        _print_row(r)

    # Write results back to BigQuery
    write_results_to_bq(client, results)

    return results


STATUS_COLOR = {
    "PASS": "\033[92m", "AUTO_WAIVED": "\033[94m",
    "POTENTIAL": "\033[93m", "SURCHARGE_APPLIED": "\033[91m",
}
RESET = "\033[0m"

def _print_row(r: ComplianceResult):
    color = STATUS_COLOR.get(r.status, "")
    tag = " [EXCL]" if r.is_excluded else ""
    tag += " 6×!" if r.is_6x_breach else ""
    print(f"  {r.gfid:<6} {r.product_group:<5} {r.raw_msg_count:>8,} "
          f"{r.messaging_score:>10.1f} {r.volume:>6,} "
          f"{r.volume_ratio:>7.1f} {r.effective_benchmark:>5.0f} "
          f"{r.tier:<8} {color}{r.status}{RESET}{tag}")
