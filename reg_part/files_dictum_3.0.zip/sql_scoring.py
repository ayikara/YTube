"""
Step 2: sql_scoring.py
Runs SQL on BigQuery to classify, weight, and aggregate order data
into the daily_scores table.

This is the exact same SQL logic as the SQLite POC, but running on
real BigQuery. The SQL creates a table using CREATE OR REPLACE TABLE.

This demonstrates:
  - The weight lookup JOIN works identically on BQ
  - BigQuery SQL is the scoring engine — Python just submits the query
  - The daily_scores table is the handoff point to the Python rule engine
"""

from google.cloud import bigquery

import bq_config as cfg


SCORING_SQL = f"""
CREATE OR REPLACE TABLE `{cfg.T_DAILY_SCORES}` AS

-- Step A: Score each row by joining the weight table
-- This mirrors the design doc: vw_classified_events + vw_event_scores
WITH scored AS (
    SELECT
        o.trade_date,
        o.firm                          AS gfid,
        o.symbol                        AS product_group,
        o.session                       AS session_type,

        -- Raw message count (for tier determination)
        -- All message types count toward raw total
        (o.orders + o.modifications + o.cancels + o.elimination)
            AS raw_msg_count,

        -- Weighted messaging score (for volume ratio numerator)
        -- New orders always weight 0 — they are excluded from the score
        -- Each message type is multiplied by its weight from the rules table
        (o.modifications * COALESCE(w_mod.weight, 0)
         + o.cancels     * COALESCE(w_can.weight, 0)
         + o.elimination * COALESCE(w_eli.weight, 0)
        ) AS messaging_score,

        o.trade_volume

    FROM `{cfg.T_ORDER_DATA}` o

    -- Join modification weight (msg_type = 'modifications')
    LEFT JOIN `{cfg.T_MESSAGE_WEIGHTS}` w_mod
        ON  w_mod.msg_type = 'modifications'
        AND (w_mod.session = o.session OR w_mod.session = 'ALL')
        AND (w_mod.month_type = 'FRONT' OR w_mod.month_type = 'ALL')

    -- Join cancellation weight (msg_type = 'cancels')
    LEFT JOIN `{cfg.T_MESSAGE_WEIGHTS}` w_can
        ON  w_can.msg_type = 'cancels'
        AND (w_can.session = o.session OR w_can.session = 'ALL')
        AND (w_can.month_type = 'FRONT' OR w_can.month_type = 'ALL')

    -- Join elimination weight (msg_type = 'elimination')
    LEFT JOIN `{cfg.T_MESSAGE_WEIGHTS}` w_eli
        ON  w_eli.msg_type = 'elimination'
        AND (w_eli.session = o.session OR w_eli.session = 'ALL')
        AND (w_eli.month_type = 'FRONT' OR w_eli.month_type = 'ALL')
)

-- Step B: Aggregate to GFID × product_group level
SELECT
    trade_date,
    gfid,
    product_group,

    SUM(raw_msg_count)                                                  AS raw_msg_count_total,
    SUM(CASE WHEN session_type='RTH' THEN raw_msg_count ELSE 0 END)    AS raw_msg_rth,
    SUM(CASE WHEN session_type='ETH' THEN raw_msg_count ELSE 0 END)    AS raw_msg_eth,

    SUM(messaging_score)                                                AS messaging_score_total,
    SUM(CASE WHEN session_type='RTH' THEN messaging_score ELSE 0 END)  AS messaging_score_rth,
    SUM(CASE WHEN session_type='ETH' THEN messaging_score ELSE 0 END)  AS messaging_score_eth,

    SUM(trade_volume)                                                   AS volume_total

FROM scored
GROUP BY trade_date, gfid, product_group
"""


def run():
    """Execute Step 2: create daily_scores table via BigQuery SQL."""
    client = bigquery.Client(project=cfg.PROJECT_ID)

    print(f"\n  Running scoring SQL on BigQuery...")
    print(f"  Target table: {cfg.T_DAILY_SCORES}")

    # Execute the CREATE OR REPLACE TABLE query
    job = client.query(SCORING_SQL)
    job.result()  # Wait for completion

    print(f"  ✓ SQL job completed: {job.job_id}")
    print(f"    Bytes processed: {job.total_bytes_processed:,}")

    # Read and display results
    query = f"""
        SELECT gfid, product_group,
               raw_msg_count_total, messaging_score_total, volume_total,
               raw_msg_rth, raw_msg_eth,
               messaging_score_rth, messaging_score_eth
        FROM `{cfg.T_DAILY_SCORES}`
        ORDER BY gfid, product_group
    """

    print(f"\n  daily_scores table contents:\n")
    print(f"  {'GFID':<6} {'PG':<5} {'RawMsgs':>8} {'Score':>10} {'Volume':>8}   Breakdown")
    print(f"  {'─'*6} {'─'*5} {'─'*8} {'─'*10} {'─'*8}   {'─'*40}")

    rows = list(client.query(query).result())
    for r in rows:
        print(f"  {r.gfid:<6} {r.product_group:<5} "
              f"{r.raw_msg_count_total:>8,} {r.messaging_score_total:>10.1f} "
              f"{r.volume_total:>8,}   "
              f"RTH: raw={r.raw_msg_rth:,} score={r.messaging_score_rth:.1f}  "
              f"ETH: raw={r.raw_msg_eth:,} score={r.messaging_score_eth:.1f}")

    return rows
