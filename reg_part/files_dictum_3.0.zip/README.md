# MEP Proof of Concept — Google BigQuery

## Prerequisites

1. **GCP project** with BigQuery enabled
2. **Authentication**: either run in Cloud Workbench (auto-authenticated) or:
   ```bash
   gcloud auth application-default login
   ```
3. **Python package**:
   ```bash
   pip install google-cloud-bigquery
   ```
4. **Configure**: edit `bq_config.py` and set `PROJECT_ID` to your GCP project ID

## How to run

```bash
cd mep_poc_bq
# Edit bq_config.py first!
python3 run_poc.py
```

## What it creates

Six tables in `your-project.mep_poc`:

| Table | Contents |
|---|---|
| `benchmarks` | Product group benchmark ratios (from JSON, sourced from PDF) |
| `messaging_tiers` | Tier thresholds and multipliers (from JSON) |
| `message_weights` | Weighting factors by session × month × msg type (from JSON) |
| `order_data` | Sample aggregated order data (from CSV) |
| `daily_scores` | SQL-computed weighted scores aggregated to GFID × product group |
| `compliance_results` | Final pass/fail status per GFID × product group |

## Pipeline flow

```
mep_benchmarks.json ──┐
mep_rules.json ───────┤──→ [Step 1] BigQuery tables
sample_data.csv ──────┘         │
                                ↓
                        [Step 2] SQL scoring query
                        (CREATE OR REPLACE TABLE daily_scores)
                                │
                                ↓
                        [Step 3] Python rule engine
                        (reads daily_scores + tiers + benchmarks from BQ)
                                │
                                ↓
                        [Step 4] compliance_results table in BQ
```

## Files

| File | What it does |
|---|---|
| `bq_config.py` | **Edit this first** — sets PROJECT_ID and dataset name |
| `run_poc.py` | Main entry point — runs all steps |
| `load_rules_to_db.py` | Step 1: creates BQ tables, loads JSON + CSV |
| `sql_scoring.py` | Step 2: runs scoring SQL (CREATE OR REPLACE TABLE) |
| `rule_engine.py` | Step 3: Python rules, reads/writes BQ |
| `mep_benchmarks.json` | Extracted benchmark ratios |
| `mep_rules.json` | Extracted rule parameters |
| `mep_logic_rules.json` | Rule catalog (PDF → Python function mapping) |
| `sample_data.csv` | Sample aggregated order data |

## Differences from SQLite POC

| Aspect | SQLite POC | BigQuery POC |
|---|---|---|
| Database | SQLite file (mep_poc.db) | BigQuery dataset |
| Auth | None needed | gcloud auth or Workbench |
| SQL dialect | SQLite | BigQuery Standard SQL |
| Table creation | `CREATE TABLE IF NOT EXISTS` | `client.create_table()` |
| Data load | `INSERT` row-by-row | `insert_rows_json()` streaming |
| Scoring query | Same logic | Same logic, backtick table refs |
| Rule engine | Identical pure functions | Identical pure functions |
| Results | CSV file | BQ table + console |

The rule functions in `rule_engine.py` are **identical** between both POCs.
Only the I/O layer (read from SQLite vs read from BQ) changes.
