#!/usr/bin/env python3
"""
run_poc.py — MEP Proof of Concept on Google BigQuery
Runs the full pipeline end-to-end against real BigQuery.

Prerequisites:
    1. pip install google-cloud-bigquery
    2. Authenticate: gcloud auth application-default login
       (or run in Cloud Workbench where auth is automatic)
    3. Edit bq_config.py to set your PROJECT_ID

Usage:
    python3 run_poc.py

Pipeline:
    Step 0: Show rule catalog (mep_logic_rules.json)
    Step 1: JSON files  →  BigQuery tables        (load_rules_to_db.py)
    Step 2: SQL scoring →  daily_scores table      (sql_scoring.py)
    Step 3: Rule engine →  compliance_results table (rule_engine.py)
    Step 4: Verification — hand-check one example
    Step 5: Summary + query results from BQ
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime
from collections import Counter

HERE = Path(__file__).parent
os.chdir(HERE)

import bq_config as cfg
import load_rules_to_db
import sql_scoring
import rule_engine


# ── File paths ────────────────────────────────────────────────────────────
BENCHMARKS_JSON = HERE / "mep_benchmarks.json"
RULES_JSON      = HERE / "mep_rules.json"
LOGIC_CATALOG   = HERE / "mep_logic_rules.json"
DATA_CSV        = HERE / "sample_data.csv"


def banner(step, title):
    print(f"\n{'═'*65}")
    print(f"  Step {step}: {title}")
    print(f"{'═'*65}")


def step_0_show_catalog():
    """Show the rule catalog — maps PDF sections to Python functions."""
    banner("0", "Rule catalog (mep_logic_rules.json)")
    print(f"\n  This catalog maps every MEP rule to its Python function.")
    print(f"  When the spec changes, look up affected rules here.\n")

    with open(LOGIC_CATALOG) as f:
        catalog = json.load(f)

    print(f"  {'rule_id':<20} {'change_type':<15} {'function':<30} {'spec_section'}")
    print(f"  {'─'*20} {'─'*15} {'─'*30} {'─'*25}")
    for r in catalog["rules"]:
        print(f"  {r['rule_id']:<20} {r['change_type']:<15} "
              f"{r['function']:<30} {r['spec_section']}")


def step_1_load():
    """Load JSON + CSV → BigQuery tables."""
    banner("1", "Load JSON rules + CSV data → BigQuery")
    print(f"\n  Project:  {cfg.PROJECT_ID}")
    print(f"  Dataset:  {cfg.DATASET}")
    print(f"  Location: {cfg.LOCATION}")

    load_rules_to_db.run(
        str(BENCHMARKS_JSON), str(RULES_JSON), str(DATA_CSV)
    )


def step_2_score():
    """Run SQL scoring on BigQuery."""
    banner("2", "SQL scoring → daily_scores (BigQuery)")
    print(f"\n  Executing CREATE OR REPLACE TABLE on BigQuery.")
    print(f"  Joins order_data × message_weights to compute weighted scores,")
    print(f"  then aggregates to GFID × product_group level.")

    sql_scoring.run()


def step_3_rules(results_holder):
    """Run Python rule engine reading from BigQuery."""
    banner("3", "Python rule engine (reads from BigQuery)")
    print(f"\n  Loading parameters from BQ tables: {cfg.T_MESSAGING_TIERS},")
    print(f"  {cfg.T_BENCHMARKS}, {cfg.T_DAILY_SCORES}")
    print(f"\n  Applying rules:")
    print(f"    1. EXCL-50K  →  2. TIER-ASSIGN  →  3. RATIO-CALC")
    print(f"    4. BREACH-DAILY  →  5. EXEMPT-6X-BLOCK  →  6. Waterfall")

    results = rule_engine.run(str(RULES_JSON))
    results_holder.extend(results)


def step_4_verify(results):
    """Hand-check one example end-to-end."""
    banner("4", "Verification — hand-check firm BBB / ZN")

    r = next((x for x in results if x.gfid == "BBB" and x.product_group == "ZN"), None)
    if r is None:
        print("  BBB/ZN not found in results")
        return

    from google.cloud import bigquery as bq
    client = bq.Client(project=cfg.PROJECT_ID)

    # Pull source data from BQ
    query = f"""
        SELECT session, modifications, cancels, elimination, trade_volume
        FROM `{cfg.T_ORDER_DATA}`
        WHERE firm = 'BBB' AND symbol = 'ZN'
        ORDER BY session DESC
    """
    rows = {r.session: r for r in client.query(query).result()}
    rth = rows.get("RTH")
    eth = rows.get("ETH")

    if not rth or not eth:
        print("  Could not retrieve BBB/ZN source data from BQ")
        return

    print(f"\n  Source data (from {cfg.T_ORDER_DATA}):")
    print(f"    RTH: mods={rth.modifications}, cancels={rth.cancels}, "
          f"elims={rth.elimination}, vol={rth.trade_volume}")
    print(f"    ETH: mods={eth.modifications}, cancels={eth.cancels}, "
          f"elims={eth.elimination}, vol={eth.trade_volume}")

    print(f"\n  Weights (from {cfg.T_MESSAGE_WEIGHTS}):")
    print(f"    RTH FRONT: mod=1.0, cancel=3.0, elim=3.0")
    print(f"    ETH ALL:   mod=0.1, cancel=0.3, elim=0.3")

    rth_score = rth.modifications * 1.0 + rth.cancels * 3.0 + rth.elimination * 3.0
    eth_score = eth.modifications * 0.1 + eth.cancels * 0.3 + eth.elimination * 0.3
    total_score = rth_score + eth_score
    total_vol = rth.trade_volume + eth.trade_volume

    print(f"\n  Hand calculation:")
    print(f"    RTH score = {rth.modifications}×1.0 + {rth.cancels}×3.0 "
          f"+ {rth.elimination}×3.0 = {rth_score:.1f}")
    print(f"    ETH score = {eth.modifications}×0.1 + {eth.cancels}×0.3 "
          f"+ {eth.elimination}×0.3 = {eth_score:.1f}")
    print(f"    Total = {total_score:.1f},  Volume = {total_vol}")
    print(f"    Ratio = {total_score:.1f} / {total_vol} = {total_score/total_vol:.1f}")

    print(f"\n  Rule engine output:")
    print(f"    score={r.messaging_score:.1f}, vol={r.volume}, "
          f"ratio={r.volume_ratio:.1f}")
    print(f"    benchmark={r.effective_benchmark:.0f}, status={r.status}")

    match = abs(r.messaging_score - total_score) < 0.01
    print(f"\n  ✓ Score matches: {match}")

    print(f"\n  Rule trace:")
    print(f"    EXCL-50K:     raw={r.raw_msg_count:,} > 50,000 → not excluded")
    print(f"    TIER-ASSIGN:  raw={r.raw_msg_count:,} → {r.tier}")
    print(f"    RATIO-CALC:   {r.messaging_score:.1f}/{r.volume} = {r.volume_ratio:.1f}")
    print(f"    BREACH-DAILY: {r.volume_ratio:.1f} > {r.effective_benchmark:.0f} → "
          f"{'YES' if r.is_breach else 'NO'}")
    if r.is_breach:
        print(f"    EXEMPT-6X:    {r.volume_ratio:.1f} > "
              f"{6*r.effective_benchmark:.0f} → {'YES' if r.is_6x_breach else 'NO'}")
        print(f"    Waterfall:    → {r.status}")


def step_5_summary(results):
    """Query compliance_results from BQ and summarize."""
    banner("5", "Summary — compliance_results in BigQuery")

    from google.cloud import bigquery as bq
    client = bq.Client(project=cfg.PROJECT_ID)

    import time
    print(f"\n  Waiting 5s for BQ streaming buffer...")
    time.sleep(5)

    query = f"""
        SELECT gfid, product_group, tier, volume_ratio,
               effective_benchmark, status, notes
        FROM `{cfg.T_COMPLIANCE}`
        ORDER BY gfid, product_group
    """
    print(f"\n  Query: SELECT * FROM `{cfg.T_COMPLIANCE}`\n")

    for row in client.query(query).result():
        print(f"    {row.gfid}/{row.product_group}: {row.status}  "
              f"(ratio={row.volume_ratio:.1f} vs bm={row.effective_benchmark:.0f}, "
              f"tier={row.tier})")

    counts = Counter(r.status for r in results)
    print(f"\n  Status summary:")
    for status, count in sorted(counts.items()):
        print(f"    {status}: {count}")

    print(f"\n  BigQuery tables created in {cfg.PROJECT_ID}.{cfg.DATASET}:")
    print(f"    {cfg.T_BENCHMARKS}")
    print(f"    {cfg.T_MESSAGING_TIERS}")
    print(f"    {cfg.T_MESSAGE_WEIGHTS}")
    print(f"    {cfg.T_ORDER_DATA}")
    print(f"    {cfg.T_DAILY_SCORES}")
    print(f"    {cfg.T_COMPLIANCE}")


def main():
    started = datetime.now()

    print(f"\n{'━'*65}")
    print(f"  MEP Proof of Concept — Google BigQuery")
    print(f"  Project: {cfg.PROJECT_ID}")
    print(f"  Dataset: {cfg.DATASET}")
    print(f"  Started: {started.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'━'*65}")

    # Preflight check
    if cfg.PROJECT_ID == "your-gcp-project-id":
        print(f"\n  ✗ ERROR: Edit bq_config.py and set PROJECT_ID to your GCP project.")
        print(f"    Then re-run: python3 run_poc.py\n")
        sys.exit(1)

    try:
        from google.cloud import bigquery
    except ImportError:
        print(f"\n  ✗ ERROR: google-cloud-bigquery not installed.")
        print(f"    Run: pip install google-cloud-bigquery\n")
        sys.exit(1)

    step_0_show_catalog()
    step_1_load()
    step_2_score()

    results = []
    step_3_rules(results)
    step_4_verify(results)
    step_5_summary(results)

    elapsed = (datetime.now() - started).total_seconds()
    print(f"\n{'━'*65}")
    print(f"  POC completed in {elapsed:.1f}s")
    print(f"  6 tables created in {cfg.PROJECT_ID}.{cfg.DATASET}")
    print(f"{'━'*65}\n")


if __name__ == "__main__":
    main()
