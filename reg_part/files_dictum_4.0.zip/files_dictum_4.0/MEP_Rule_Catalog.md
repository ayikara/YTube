# CME Messaging Efficiency Program — Rule Catalog

**Source documents:**
- MEP Specification v11.8 (May 2026) — `2024-revised-mep.pdf`
- Q3 2026 Benchmarks — `upcoming-mep-benchmarks.pdf`

**Purpose:** Systematic categorization of every rule in the MEP program, organized for product specification, software development, rule evolution tracking, and communication across business, compliance, and technology teams.

**Convention:** Each rule is assigned a unique `rule_id` for traceability. Sub-parameters within a rule are listed as child rows. The "Source" column references the specific section and page of the source PDF.

---

## 1. Scope Rules

*Define what is measured, at what entity level, during what hours, and which products are included.*

| rule_id | Rule | Sub-parameters | Source |
|---------|------|----------------|--------|
| SCOPE-ENTITY | The program measures volume ratios at the CME Globex firm (GFID) level. A GFID is the 3-character alpha-numeric value in positions 4–6 of iLink tag 49-SenderCompID. | Tag 49-SenderCompID (outbound), Tag 56-TargetCompID (inbound) | Section 1, p3 |
| SCOPE-GRANULAR | CME Group may at its discretion apply the program at more granular levels: account, Operator ID (Tag 50), or iLink Session ID, when a high-messaging participant is not set up with its own execution firm number. | Account, Tag 50, iLink Session ID | Section 8, p8 |
| SCOPE-HOURS | Message scoring and volume ratio are calculated for all messaging and volume during combined Regular Trading Hours (RTH) and Extended Trading Hours (ETH). | RTH: 07:00–16:00 Central Time; ETH: any time not included in RTH | Section 3, p6; FAQ Q5–Q6, p16 |
| SCOPE-PRODUCTS | The program applies to selected product groups that exhibit inefficient messaging traffic. Product groups are established and announced each quarter. | Specific product groups listed in the quarterly benchmark PDF | Section 5, p7 |
| SCOPE-OPTIONS | Options product groups not part of a mass quote are scored in the same manner as futures product groups. | — | Section 7, p7 |
| SCOPE-HOLIDAYS | The program is not applied on certain dates before/on/after U.S. recognized holidays where CME Globex trading is abbreviated. | Refer to MEP Holiday Calendar for specific dates | Section 11, p10; FAQ Q8, p17 |

---

## 2. Scoring Rules

*Define how raw message counts and weighted messaging scores are computed.*

### 2.1 Raw Message Count

| rule_id | Rule | Source |
|---------|------|--------|
| SCORE-RAW-COUNT | Raw message count = Orders + Modifications + Cancellations + Eliminations, ETH and RTH combined. | Section 3, p6 |

### 2.2 Message Weighting — RTH Lead/Front Month Outright

| rule_id | Message Type | iLink Tag | Weight | Source |
|---------|-------------|-----------|--------|--------|
| SCORE-RTH-FRONT-D | New Order | Tag 35-MsgType=D | 0 | Section 3, p4 (Table 1) |
| SCORE-RTH-FRONT-G | Order Modification | Tag 35-MsgType=G | 1 | Section 3, p4 (Table 1) |
| SCORE-RTH-FRONT-F | Order Cancellation | Tag 35-MsgType=F | 3 | Section 3, p4 (Table 1) |
| SCORE-RTH-FRONT-CA | Order Mass Action Request | Tag 35-MsgType=CA | 3 × number of orders cancelled | Section 3, p4 (Table 1) |
| SCORE-RTH-FRONT-FAK | Fill and Kill elimination | Tag 59 = 3 (Fill and Kill) | 3 | Section 3, p4 (Table 1) |
| SCORE-RTH-FRONT-MQ | MinQty elimination | Tag 110-MinQty | 3 | Section 3, p4 (Table 1) |

### 2.3 Message Weighting — RTH Back Month or Spreads

| rule_id | Message Type | Weight | Source |
|---------|-------------|--------|--------|
| SCORE-RTH-BACK-D | New Order | 0 | Section 3, p5 (Table 2) |
| SCORE-RTH-BACK-G | Order Modification | 0.1 | Section 3, p5 (Table 2) |
| SCORE-RTH-BACK-F | Order Cancellation | 0.3 | Section 3, p5 (Table 2) |
| SCORE-RTH-BACK-CA | Order Mass Action Request | 0.3 × number of orders cancelled | Section 3, p5 (Table 2) |
| SCORE-RTH-BACK-FAK | Fill and Kill elimination | 0.3 | Section 3, p5 (Table 2) |
| SCORE-RTH-BACK-MQ | MinQty elimination | 0.3 | Section 3, p5 (Table 2) |

### 2.4 Message Weighting — ETH (Front Month, Back Month, or Spreads)

| rule_id | Message Type | Weight | Source |
|---------|-------------|--------|--------|
| SCORE-ETH-ALL-D | New Order | 0 | Section 3, p5 (Table 3) |
| SCORE-ETH-ALL-G | Order Modification | 0.1 | Section 3, p5 (Table 3) |
| SCORE-ETH-ALL-F | Order Cancellation | 0.3 | Section 3, p5 (Table 3) |
| SCORE-ETH-ALL-CA | Order Mass Action Request | 0.3 × number of orders cancelled | Section 3, p5 (Table 3) |
| SCORE-ETH-ALL-FAK | Fill and Kill elimination | 0.3 | Section 3, p5 (Table 3) |
| SCORE-ETH-ALL-MQ | MinQty elimination | 0.3 | Section 3, p5 (Table 3) |

### 2.5 Score Formulas

| rule_id | Formula | Source |
|---------|---------|--------|
| SCORE-FORMULA-ETH | Messaging score ETH = (# modifications × 0.1) + (# cancellations × 0.3) + (# FAK/FOK eliminations × 0.3) | Section 3, p6 |
| SCORE-FORMULA-RTH | Messaging score RTH = (# modifications × 1) + (# cancellations × 3) + (# FAK/FOK eliminations × 3) | Section 3, p6 |

### 2.6 Classification Dimensions

| rule_id | Dimension | How Resolved | Source |
|---------|-----------|-------------|--------|
| SCORE-DIM-SESSION | Time of day (RTH vs ETH) | RTH = 07:00–16:00 CT; ETH = all other times | Section 3, p6 |
| SCORE-DIM-MONTH | Front or back/deferred month | Boolean flag (Y/N) from CME Reference Data API | Section 3, p6; FAQ Q7, p16 |
| SCORE-DIM-SPREAD | Outright or spread | Outright = single contract month not part of a defined spread; Spread = messaging across multiple contract months and/or products | Section 3, p6 |

### 2.7 Volume Calculation

| rule_id | Rule | Sub-parameters | Source |
|---------|------|----------------|--------|
| SCORE-VOL-SPREAD | Spread volume is multiplied by a factor of 3×. Example: trade of 100 on Spread A:B counts as Spread=100 + Leg A=100 + Leg B=100 = 300 total. | — | Section 3, p6 |

### 2.8 Score Exclusions

| rule_id | Exclusion | Source |
|---------|-----------|--------|
| SCORE-EXCL-NEW-ORDERS | New orders are excluded from the messaging score calculation. | Section 3, p6 |
| SCORE-EXCL-50K | CME Globex firms submitting 50,000 or fewer daily messages during combined RTH and ETH per product group are excluded. | Section 3, p6 |

---

## 3. Threshold Rules

*Define the tiered benchmarks and how they map to raw message volumes.*

### 3.1 Messaging Tiers

| rule_id | Raw Daily Messages (ETH+RTH) | Effective Benchmark | Source |
|---------|------------------------------|---------------------|--------|
| TIER-EXCLUDED | ≤ 50,000 | Not applicable (excluded) | Section 6, p7 |
| TIER-3 | 50,001 – 100,000 | 3× product group benchmark | Section 6, p7 |
| TIER-2 | 100,001 – 150,000 | 2× product group benchmark | Section 6, p7 |
| TIER-1 | > 150,000 | 1× product group benchmark (base) | Section 6, p7 |

### 3.2 Product Group Benchmarks

| rule_id | Rule | Source |
|---------|------|--------|
| THRESH-PG-BENCHMARKS | Product group benchmarks are determined each quarter based on the business needs of the market and observed performance. Benchmarks are announced each quarter unless business circumstances require more frequent changes. | Section 5, p7 |
| THRESH-PG-VALUES | The specific benchmark ratios per product group per tier are published in the quarterly benchmark document. Refer to the Q3 2026 benchmark PDF for current values covering: Commodity Futures (4 groups), Commodity Options (3 groups), Livestock Futures (3 groups), Livestock Options (3 groups), Equity Futures (8 groups), Equity Options (5 groups), FX Futures (6 groups), FX Options (6 groups), Interest Rate Futures (8 groups), Interest Rate Options (8 groups), Energy & Metals Futures (6 groups), Energy & Metals Options (9 groups). | Benchmark PDF, pages 1–5 |
| THRESH-MQ-VALUES | Mass Quote product group benchmarks are published separately for 10 equity options product groups. | Benchmark PDF, pages 6–7 |

---

## 4. Compliance Determination Rules

*Define how the volume ratio is computed and how breach/non-compliance is determined.*

| rule_id | Rule | Sub-parameters | Source |
|---------|------|----------------|--------|
| COMPLY-RATIO | Volume Ratio = Total Globex firm messaging score / Total Globex firm volume. Calculated during combined ETH and RTH trading. | — | Section 4, p6 |
| COMPLY-BREACH | A GFID is non-compliant on a trade date if its volume ratio in a product group exceeds the tier-adjusted benchmark for that product group. | — | Section 4, p6; Section 10, p9 |
| COMPLY-SURCHARGE | If a GFID's volume ratio exceeds the benchmark and all exemptions are exhausted or not applicable, CME Group levies a surcharge of $1,000 per product group per day. | $1,000/product group/day | Section 10, p9 |

---

## 5. Exemption and Waiver Rules

*Define the conditions under which surcharges are waived or exempted. These rules form a priority hierarchy.*

| rule_id | Rule | Conditions & constraints | Source |
|---------|------|------------------------|--------|
| EXEMPT-HOLIDAY | The program is not applied on dates designated in the MEP Holiday Calendar (certain dates before/on/after U.S. recognized holidays where CME Globex trading is abbreviated). | Refer to MEP Holiday Calendar. Does NOT apply to EMT, mass quoting, or Treasury Futures Roll. | Section 11, p10; FAQ Q8, p17 |
| EXEMPT-AUTO-WAIVER | One automatic daily surcharge waiver per product group per calendar month. Applied at the end of each calendar month. No action required from the firm. | Does NOT apply when the daily ratio > 6× the tier-adjusted benchmark on the day the violation occurred. | Section 11, p10 |
| EXEMPT-MONTHLY | All daily surcharges for a GFID in a product group for a calendar month are automatically waived if the monthly aggregate ratio ≤ the applicable benchmark. | Does NOT apply when any daily ratio > 6× benchmark. Monthly tier determined by average daily raw message count across MEP-active days. Monthly ratio = (∑ ETH+RTH monthly messaging score) / (∑ ETH+RTH monthly volume). Only counts days when MEP is enforced and firm submitted raw messages. | Section 11, p10–11 |
| EXEMPT-MONTHLY-ETH | ETH monthly volume ratio = ((# modifications × 0.1) + (# cancellations × 0.3) + (# FAK/FOK × 0.3)) for calendar month / ETH volume for calendar month. | Part of EXEMPT-MONTHLY calculation | Section 11, p10 |
| EXEMPT-MONTHLY-RTH | RTH monthly volume ratio = ((# modifications × 1) + (# cancellations × 3) + (# FAK/FOK × 3)) for calendar month / RTH volume for calendar month. | Part of EXEMPT-MONTHLY calculation | Section 11, p11 |
| EXEMPT-6X-BLOCK | Waivers (both EXEMPT-AUTO-WAIVER and EXEMPT-MONTHLY) do NOT apply to surcharges where the daily product group volume ratio is greater than 6× the listed product group benchmark at the applicable tier level on the day the violation occurred. | 6× multiplier applied to the tier-adjusted benchmark, not the base benchmark | Section 11, p10; Section 2, p3; FAQ Q13, p17 |
| EXEMPT-MARKET-MAKER | Market participants designated by CME Group as Registered Market Makers in SOFR futures, 30 Day Federal Fund futures, and E-mini S&P 400 futures, or enrolled in other Exchange programs designed to promote liquidity, may be exempt from standard product group benchmarks. Still held to EMT parameters. | Firms must verify status with an Exchange representative and request written confirmation. | Section 11, p11 |

---

## 6. Aggregation Rules

*Define when and how multiple GFIDs can be combined for MEP evaluation.*

| rule_id | Rule | Conditions & constraints | Source |
|---------|------|------------------------|--------|
| AGG-REQUEST | Customers may request, or CME Group at its discretion may choose, to aggregate messaging and volume of multiple GFIDs where a customer executes business under more than one GFID. | — | Section 2, p3 |
| AGG-EFFECTIVE-DATE | Aggregation begins as of the first of the month following the decision to move forward. | — | Section 2, p3 |
| AGG-FAIL-6X | Aggregation will not be calculated and surcharges will apply at individual GFID level when the daily product group volume ratio is greater than 6× the listed product group benchmark at the applicable tier level on the day the incident occurred. | Reverts to individual GFID scoring | Section 2, p3 |
| AGG-EXCLUSIONS | Firm-requested aggregation does NOT apply to: Mass Quote Program, EMT iLink Session, and Globex Firm ID Programs. | — | Section 2, p4 |
| AGG-DISCRETIONARY | CME Group reserves the right at its discretion to aggregate GFIDs for purposes of determining whether a product group benchmark has been exceeded where a single entity sends messages via more than one execution firm number. | — | Section 8, p8 |
| AGG-DISCRETIONARY-SOFR | CME Group also reserves the right to aggregate GFIDs for purposes of determining whether the SS-SOFR Futures EMT GFID benchmark (as part of EMT MPS) has been exceeded. | — | Section 2, p4; Section 8, p8; Section 16, p14 |

---

## 7. Parallel Track: Excessive Messaging Threshold (EMT)

*EMT is a parallel program to the standard MEP. It shares the same input data and some scoring formulas but operates independently: different thresholds, no holiday calendar, no exemptions/waivers from the standard MEP, and its own escalation path.*

### 7.1 EMT Scope

| rule_id | Rule | Source |
|---------|------|--------|
| EMT-SCOPE-HOURS | Both raw message count and messaging scores are in effect during ALL trade dates and hours in which the CME Globex platform is open. | Section 15, p12; Section 16, p13 |
| EMT-SCOPE-HOLIDAYS | EMT does NOT recognize the MEP holiday calendar. On MEP holidays, EMT still calculates. | Section 15, p12; Section 16, p13; FAQ Q8, p17 |
| EMT-SCOPE-PRODUCTS | Unless otherwise stated, all futures and options product groups available on CME Globex are included in the EMT. CME Group may add or remove product groups at its discretion. | Section 15, p12; Section 16, p13 |
| EMT-SCOPE-NO-EXEMPTIONS | Unless otherwise stated, all exclusions, exemptions, exceptions, and aggregation from the standard MEP do NOT apply to the EMT. | Section 15, p12; Section 16, p13 |

### 7.2 EMT Scoring

| rule_id | Formula | Source |
|---------|---------|--------|
| EMT-SCORE-RAW | Raw Message Count = Orders + Modifications + Cancellations + Eliminations | Section 15, p12; Section 16, p13 |
| EMT-SCORE-WEIGHTED | Messaging Score = (# modifications) + (# cancellations × 3) + (# FAK/FOK eliminations × 3) | Section 15, p12; Section 16, p13 |
| EMT-SCORE-RATIO | Volume Ratio = Product Group Messaging Score / Product Group Volume (calculated at iLink Session ID or GFID level depending on EMT track) | Section 15, p12; Section 16, p13 |

### 7.3 EMT iLink Session ID Track

| rule_id | Parameter | Value | Source |
|---------|-----------|-------|--------|
| EMT-ILINK-LEVEL | Measurement level | iLink Session ID | Section 15, p12 |
| EMT-ILINK-RAW-THRESH | Raw message count threshold | > 1 million per trade date | Section 15, p12 |
| EMT-ILINK-RATIO-THRESH | Volume ratio threshold | > 500:1 per individual product group | Section 15, p12 |
| EMT-ILINK-TRIGGER | Trigger condition | Both raw count AND ratio must be exceeded simultaneously | Section 15, p12 |
| EMT-ILINK-SURCHARGE | Surcharge | $10,000 per occurrence | Section 15, p12 |
| EMT-ILINK-PORT | Port closure | iLink session port closure + $1,000 port closure fee | Section 15, p12 |
| EMT-ILINK-REOPEN | Reopening condition | GCC determination that detrimental behavior has been corrected | Section 15, p13 |
| EMT-ILINK-EXPLANATION | Required response | Written explanation of system failure + mitigating steps | Section 15, p13 |
| EMT-ILINK-REFERRAL | Subsequent violations | Trigger referral to market regulation | Section 15, p13 |

### 7.4 EMT GFID Track — General

| rule_id | Parameter | Value | Source |
|---------|-----------|-------|--------|
| EMT-GFID-LEVEL | Measurement level | CME Globex Firm ID | Section 16, p13 |
| EMT-GFID-RAW-THRESH | Raw message count threshold | > 10 million per trade date | Section 16, p13–14 |
| EMT-GFID-RATIO-THRESH | Volume ratio threshold | > 500:1 per individual product group | Section 16, p13–14 |
| EMT-GFID-TRIGGER | Trigger condition | Both raw count AND ratio must be exceeded simultaneously | Section 16, p13–14 |
| EMT-GFID-EXCL-SS | Product exclusion | Does NOT include product group SS (Three-Month SOFR Futures & Spreads) — SS has its own parameters | Section 16, p14 |
| EMT-GFID-SURCHARGE | Surcharge | $10,000 per occurrence | Section 16, p14 |
| EMT-GFID-PORT | Port closure | iLink session port closure + $1,000 port closure fee | Section 16, p14 |
| EMT-GFID-REOPEN | Reopening condition | GCC determination that detrimental behavior has been corrected | Section 16, p14 |
| EMT-GFID-REFERRAL | Subsequent violations | Trigger referral to market regulation | Section 16, p14 |

### 7.5 EMT GFID Track — SS-SOFR (Effective January 5, 2026)

| rule_id | Parameter | Value | Source |
|---------|-----------|-------|--------|
| EMT-SOFR-PRODUCT | Applicable product group | SS — Three-Month SOFR Futures & Spreads | Section 16, p14 |
| EMT-SOFR-EFFECTIVE | Effective date | Trade date Monday, January 5, 2026 | Section 16, p14 |
| EMT-SOFR-RAW-THRESH | Raw message count threshold | > 5 million (previously 10 million) | Section 16, p14 |
| EMT-SOFR-RATIO-THRESH | Volume ratio threshold | > 50:1 (previously 500:1) | Section 16, p14 |
| EMT-SOFR-SURCHARGE | Surcharge | $10,000 per occurrence | Section 16, p14 |
| EMT-SOFR-PORT | Port closure | iLink session port closure + $1,000 port closure fee | Section 16, p14 |
| EMT-SOFR-SESSION-UNCHANGED | iLink Session level EMT for SS | Remains unchanged (uses general iLink session thresholds) | Section 16, p14 |

### 7.6 EMT MPS — Modifications Per Second (Effective April 1, 2026)

| rule_id | Parameter | Value | Source |
|---------|-----------|-------|--------|
| EMT-MPS-PRODUCT | Applicable product group | SS — SOFR futures | Section 16, p14 |
| EMT-MPS-EFFECTIVE | Effective date | Trade date Wednesday, April 1, 2026 (revised Tuesday, March 31) | Section 16, p14 |
| EMT-MPS-METRIC | What is tracked | Customer order modifications per second, by GFID | Section 16, p14 |
| EMT-MPS-THRESHOLD | Threshold | > 2,000 modifications per second | Section 16, p14 |
| EMT-MPS-SURCHARGE | Surcharge | $5,000 per breach (each breach is eligible) | Section 16, p14 |
| EMT-MPS-AGG | Aggregation | CME Group reserves the right to aggregate GFIDs for determining whether the MPS threshold has been exceeded where a single entity uses more than one GFID | Section 16, p14 |

---

## 8. Mass Quote MEP (Separate Program)

*The Mass Quote MEP is a separate program from the standard MEP with its own measurement methodology, period, and product scope.*

| rule_id | Rule | Sub-parameters | Source |
|---------|------|----------------|--------|
| MQ-SCOPE | Extended to selected equity options product groups for market participants submitting mass quotes, starting trade date October 1, 2024. | Only product groups listed under CME Globex Mass Quote MEP Benchmarks | Section 7, p7–8 |
| MQ-LEVEL | Measured and applied at the CME Globex Firm ID level. | Same 3-char GFID as standard MEP | Section 7, p7 |
| MQ-HOURS | During all trade dates and RTHs in which the CME Globex trading platform is open. Does not adhere to the MEP Holiday Calendar. | RTH only for measurement | Section 7, p8 |
| MQ-RATIO | Mass Quote Entries Volume Ratio = total number of entries / total volume in a particular or aggregated product group during RTH. Entries = sum of quotes within MsgType 35=i. | — | Section 7, p8; Appendix B, p22 |
| MQ-PERIOD | Pass/fail is measured on RTH monthly data. At the end of a calendar month, if a firm's RTH ratio exceeds the designated benchmark, a surcharge is applied for each daily breach. | Monthly measurement, daily surcharge | Section 7, p8 |
| MQ-SURCHARGE | $1,000 per daily breach of the designated mass quote product group benchmark within a breaching month. | — | Section 7, p8 |
| MQ-NOTIFICATION | CME Group sends designated Executing Firm MEP Contacts an email on a T+1 basis for any instance where the GFID exceeded the mass quote benchmark. | Falls back to Clearing MEP Contact and/or Front Office Admin if no executing firm contact on record | Section 7, p8 |
| MQ-NO-STANDARD-EXEMPTIONS | Unless otherwise stated, all exclusions, exemptions, exceptions, and aggregation from the standard MEP do NOT apply to mass quoting. | — | Section 7, p8 |
| MQ-BENCHMARKS | Specific mass quote product group benchmarks are listed in the quarterly benchmark document. 10 equity options product groups: EW, 1V, NW, EN, EO, 2V, NE, NF, R4, R5. | Refer to Benchmark PDF, pages 6–7 | Benchmark PDF, p6–7 |
| MQ-RFW | Mass Quote Program RFWs are not available in the FADB and must be submitted via email to messagingprogramwaivercommittee@cmegroup.com. | — | Section 12, p11 |

---

## 9. Treasury Futures Roll

| rule_id | Rule | Source |
|---------|------|--------|
| TREAS-ROLL-REMOVAL | Effective November 13 (2025), the MEP volume/order entry ratio for Treasury futures roll markets in 5-Year and 10-Year Treasury Note futures was removed. | Section 14, p12 |
| TREAS-ROLL-ONGOING | Participants are encouraged to continue responsible messaging during the roll period. The exchange continues to evaluate adjustments for 2026. | Section 14, p12 |
| TREAS-ROLL-HOLIDAY | Treasury Futures Roll does not recognize the MEP holiday calendar. | FAQ Q8, p17 |

---

## 10. Partner Exchanges

| rule_id | Rule | Source |
|---------|------|--------|
| PARTNER-RESPONSIBILITY | Each partner exchange, in coordination with CME Group, is responsible for determining appropriate messaging practices for its CME Globex-listed products. | Section 17, p15 |
| PARTNER-BENCHMARKS | Program product group benchmarks for partner exchanges are governed by the rules of the partner exchange listing the product group. CME Group may publish and administer the program on their behalf. | Section 17, p15 |
| PARTNER-EMT | The iLink session EMT is applicable to partner exchanges. Uses the same EMT-ILINK thresholds (1M raw messages, >500:1 ratio). | Section 17, p15 |
| PARTNER-ESCALATION | Partner exchange EMT escalation follows a warning-based progression: first warning, second warning stating port closure will result on third instance within rolling 12 months, then port closure + $1,000 fee. | Section 17, p15 |

---

## 11. Administrative Rules

*Define reporting, notification, billing, and waiver request processes.*

### 11.1 Reporting & Notification

| rule_id | Rule | Source |
|---------|------|--------|
| ADMIN-REPORT-FADB | Results are available in the Firm Administrator Dashboard (FADB), segregated by product group with status for each. | Section 9, p9 |
| ADMIN-STATUS-VALUES | Reported status values: AUTO_WAIVED, Pass_on_Aggregation, Pass_on_Monthly, Potential, Surcharge_Applied | Section 9, p9 |
| ADMIN-REPORT-DIMENSIONS | FADB data is divided by: CME Globex firm, iLink Session ID, Account number, Operator ID (Tag 50), EMT | Section 9, p9 |
| ADMIN-EMAIL-T1 | Daily email notifications available on a T+1 basis, distributed to registered administrators of the clearing firm and registered recipients of the CME Globex firm. | Section 9, p9 |
| ADMIN-MQ-NOT-IN-FADB | Mass Quote Program statistics are currently not available in the FADB. | Section 9, p9 |
| ADMIN-TREAS-NOT-IN-FADB | Treasury Futures Roll Program statistics are currently not available in the FADB. | FAQ Q23, p19 |

### 11.2 Surcharges & Billing

| rule_id | Rule | Source |
|---------|------|--------|
| ADMIN-SURCHARGE-STANDARD | $1,000 per product group per day for standard MEP breaches. | Section 10, p9 |
| ADMIN-SURCHARGE-LABEL | Surcharges appear in FADB as Surcharge_Applied with incident number. On billing statement as MPS (Messaging Program Surcharge). | Section 10, p9–10 |
| ADMIN-BILLING-TIMING | Surcharges billed at the end of the second calendar month following the date the volume ratio was exceeded. | Section 12, p11 |
| ADMIN-BILLING-UNPAID | If non-clearing firm's surcharges remain unpaid, they may be billed to the current clearing firm of record for the related GFID. | Section 10, p10 |
| ADMIN-CLEARING-PASSTHROUGH | Clearing firms may alter surcharges billed to customers provided they do not misrepresent the amount charged by CME Group. | Section 10, p10 |

### 11.3 Request for Waiver (RFW)

| rule_id | Rule | Source |
|---------|------|--------|
| ADMIN-RFW-WHO | A clearing firm or approved CME Globex firm administrative manager may submit an RFW. | Section 12, p11 |
| ADMIN-RFW-HOW | Submitted via email or the Firm Administrator Dashboard. | Section 12, p11; FAQ Q31, p20 |
| ADMIN-RFW-WINDOW | Must be submitted between the 1st and 10th business day of the month following the surcharge month. RFWs not required until previous month's monthly ratio has been calculated. If exceptions are not waived by monthly ratio, 10 business days from last calendar day of month. | Section 12, p11 |
| ADMIN-RFW-MQ | Mass Quote RFWs not available in FADB; must be submitted via email to messagingprogramwaivercommittee@cmegroup.com. | Section 12, p11 |

### 11.4 GCC Authority

| rule_id | Rule | Source |
|---------|------|--------|
| ADMIN-GCC | Pursuant to Rule 579.A., the Global Command Center has authority to take any action deemed appropriate to preserve market integrity, including restricting customer access to CME Globex. | Section 8, p8–9 |

---

## 12. Rule Change Indicators

*Identifies which rules have built-in change mechanisms documented in the spec itself.*

| rule_id affected | Change mechanism | Source |
|-----------------|-----------------|--------|
| THRESH-PG-BENCHMARKS | Benchmarks established and announced each quarter, or more frequently if business circumstances require. Changes communicated via CME Globex Notices and/or GCC Targeted communication. | Section 5, p7 |
| SCOPE-PRODUCTS | CME Group may add or remove product groups at its discretion. | Section 5, p7 |
| EMT-SCOPE-PRODUCTS | CME Group reserves the right to add or remove EMT product groups at its discretion. | Section 15, p12; Section 16, p13 |
| MQ-SCOPE | CME Group reserves the right to add or remove mass quote product groups and will announce via CME Globex Notice and/or GCC Targeted Message. | Section 7, p8 |
| All EMT parameters | EMT parameters have been revised multiple times (see Appendix C revision history). Changes are announced via the program document updates. | Appendix C, p23–26 |

---

## Appendix: Rule Count Summary

| Category | Rule count | Notes |
|----------|-----------|-------|
| 1. Scope | 6 | What is measured and when |
| 2. Scoring | 22 | Weights (18), formulas (2), exclusions (2) |
| 3. Thresholds | 6 | 4 tiers + 2 benchmark references |
| 4. Compliance | 3 | Ratio, breach, surcharge |
| 5. Exemptions | 7 | Holiday, auto-waiver, monthly, 6× block, market maker |
| 6. Aggregation | 6 | Request, timing, failure, exclusions, discretionary |
| 7. EMT (parallel) | 25 | Scope (4), scoring (3), iLink (7), GFID general (6), SOFR (5), MPS (6) — note some have sub-params within |
| 8. Mass Quote | 10 | Separate program |
| 9. Treasury Roll | 3 | Removal + ongoing |
| 10. Partner | 4 | Responsibility, benchmarks, EMT, escalation |
| 11. Administrative | 14 | Reporting (6), billing (4), RFW (4) |
| 12. Change indicators | 5 | Built-in change mechanisms |
| **Total** | **111** | |
