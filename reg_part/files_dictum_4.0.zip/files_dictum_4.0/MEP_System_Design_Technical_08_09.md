# CME Messaging Efficiency Program — System Design Document (Technical)

**Version:** 1.0
**Audience:** Technology architects, engineers, QA, technical compliance analysts
**Companion document:** MEP System Design — Business Overview (Word)
**Source of truth:** MEP Specification v11.8 + Q3 2026 Benchmarks + `mep_rule_catalog.json` (132 rule_ids)

---

## 0. How to read this document

This document describes *how the system is built and why*, structured around six primary objectives and eight regulatory additions surfaced during design review. It does not contain application code — that is a later deliverable. Every design decision traces to a rule_id in `mep_rule_catalog.json`, which in turn traces to a section and page of the source PDFs.

The **architectural spine** of the entire system is *temporal reproducibility*: the ability to reproduce any past result exactly as it was originally computed. This single requirement shapes the data model, the rule resolution logic, the storage strategy, and the testing approach. It is introduced first (Section 2) because everything else depends on it.

---

## 1. Objectives and Requirements Traceability

| # | Objective | Primary sections | Regulatory driver |
|---|-----------|------------------|-------------------|
| 1 | Validate rules completely & faithfully captured from PDF | §3 Rule Validation & Attestation | Faithful capture of legal source |
| 1B | Identify edge cases | §3.4 Edge Case Register | Defensibility |
| 2 | Validate all methods (unit + functional tests) | §8 Testing Strategy | Engine correctness |
| 3 | Manual test cases for business stakeholders | §8.4 Business-English Test Cases | Stakeholder sign-off |
| 4 | Maintain system as rules amend / new rules / branching | §4 Rule Model, §5 Variant Model, §9 Change Management | Rule evolution |
| 5 | Simple design communicable to business & technical leaders | This doc + business Word doc | Governance |
| A | Backdated reproduce-as-was runs | §2 Temporal Architecture | Audit reconstruction |
| B | Immutable results + restatement | §2.4 Result Versioning | Regulatory record-keeping |

### Regulatory additions (from design review)

| # | Addition | Section |
|---|----------|---------|
| R1 | Dispute & inquiry handling — prove non-compliance | §6 Explainability & Proof |
| R2 | Waiver / RFW lifecycle (separate workflow) | §7.1 RFW Workflow |
| R3 | Data completeness & late-arriving data → rerun | §2.5 Reprocessing & Restatement |
| R4 | Reconciliation / controls module | §10 Controls & Reconciliation |
| R5 | Notification generation (system-generated, manually verified) | §7.2 Notification Generation |
| R6 | Access control & segregation of duties (manual override) | §11 Access Control |
| R7 | Failure & reprocessing semantics; mid-month rule change | §2.5, §9.4 |
| R8 | Attestation & change-approval via software change control | §3.3, §9 |

---

## 2. Temporal Architecture (the spine)

### 2.1 The core requirement

> Re-running trade date `D` must reproduce the *exact* result originally produced for `D`, using the rules, parameters, reference data, and code that were in effect on `D`.

This is **reproduce-as-was** (valid-time reconstruction). The retroactive-correction variant ("re-run `D` under today's corrected rules") is explicitly deferred to a later release, but the design does not preclude it.

### 2.2 Everything is effective-dated

To reconstruct the world as of date `D`, every input must answer the question *"what was your value on `D`?"*. Four independent axes must be resolved together:

| Axis | What varies | Resolution mechanism |
|------|-------------|---------------------|
| **Rule logic** | The code implementing a rule | Code version pinned per run (git SHA / release tag) |
| **Rule parameters** | Benchmark ratios, tiers, weights, thresholds | Effective-dated rows in BigQuery (`effective_from`, `effective_to`) |
| **Reference data** | Front-month flags, trading calendar, product taxonomy, GFID aggregation groups | Effective-dated / as-of-date snapshots |
| **Order data** | The messages and volumes themselves | Immutable per trade date, keyed by `trade_date` + `data_version` |

The resolver for a run with as-of date `D` selects, for every axis, the row/version where `effective_from <= D AND (effective_to IS NULL OR effective_to > D)`.

### 2.3 The Run Manifest — the reproducibility contract

Every execution produces and stores a **Run Manifest** that pins every version used. This is the single artifact that makes a run reproducible and auditable.

```
RunManifest {
  run_id:              UUID (unique per execution)
  run_type:            SCHEDULED_T1 | BACKDATED | RESTATEMENT | DISPUTE_PROOF
  trade_date:          the business date being processed
  as_of_date:          the date whose rules/params/refdata apply (= trade_date for reproduce-as-was)
  code_version:        git SHA / release tag of the engine
  rule_param_version:  snapshot id of ref parameter tables resolved at as_of_date
  refdata_version:     snapshot id of reference data resolved at as_of_date
  order_data_version:  version of order data consumed for trade_date
  rule_catalog_version: version of mep_rule_catalog.json in force
  executed_by:         service account / user
  executed_at:         wall-clock timestamp
  supersedes_run_id:   (nullable) the run this restates, if any
  status:              RUNNING | COMPLETE | FAILED | SUPERSEDED
}
```

A scheduled T+1 run sets `as_of_date = trade_date`. A backdated audit run for 2025-11-20 sets `trade_date = 2025-11-20`, `as_of_date = 2025-11-20`, and pins the code version that was live on 2025-11-20. Because all four axes resolve to the same historical state, the result is bit-for-bit reproducible.

### 2.4 Result versioning (immutability)

Results are **append-only**. A trade date can have multiple result sets, each tied to a `run_id`. Nothing is ever overwritten.

```
compliance_result {
  run_id:           FK to RunManifest
  trade_date:       ...
  gfid:             ...
  product_group:    ...
  ...all computed fields...
  is_current:       BOOLEAN  -- exactly one current result per (trade_date, gfid, product_group)
  restatement_reason: (nullable)
}
```

When a restatement run supersedes a prior run, the new rows are marked `is_current = TRUE` and the prior rows flip to `is_current = FALSE` (but are retained). The `supersedes_run_id` chain preserves full lineage. A query for "what did we tell the participant originally" and "what is the corrected number" are both answerable.

### 2.5 Reprocessing & restatement (R3, R7)

Triggers for a restatement run:
- **Late/corrected order data** (R3): the feed is refreshed after a result was published → new `order_data_version` → restatement run consuming it.
- **Bug fix in engine** → new `code_version` → restatement run (explicitly a decision-time change, so tracked as restatement, not silent).
- **Mid-month rule change** (R7): avoided by policy, but if it happens, the effective-dated parameter tables mean days before the change resolve to the old value and days after to the new — no special handling needed for *daily* results. The *monthly* aggregation (EXEMPT-MONTHLY) must decide how to treat a month split by a rule change; this is an explicit control point (§9.4).

Every restatement produces a new immutable result set with a reason. The original is retained.

---

## 3. Rule Validation & Attestation (Objective 1, 1B, R8)

### 3.1 The human-attestation model

Automated extraction of clauses from legal prose is itself error-prone, so **a human is the validation authority**. Tooling exists to make review *complete and fast*, not to replace the human. The goal: prove every clause in the PDF maps to at least one rule_id, and no rule_id invents a clause absent from the PDF.

### 3.2 Clause-level coverage with a "binned" bucket

The PDF is segmented into **clauses** (sentence or bullet granularity). Each clause is assigned one of:

| Disposition | Meaning |
|-------------|---------|
| `MAPPED` | Clause maps to one or more rule_ids |
| `BINNED_REDUNDANT` | Clause repeats a rule stated elsewhere (cross-reference only) |
| `BINNED_FLUFF` | Narrative/marketing/contextual prose with no operative rule ("CME expects responsible messaging…") |
| `BINNED_PROCESS` | Operational prose handled by a separate system (e.g., billing mechanics) |
| `UNMAPPED` | **Gap** — clause has an operative rule not yet in the JSON. Must be resolved before sign-off. |

Coverage is complete when zero clauses are `UNMAPPED`. The binned buckets are explicit and reviewable — a stakeholder can audit *why* a clause was considered non-operative.

### 3.3 The attestation artifact & workflow (R8)

A **Coverage Matrix** is produced: every clause (with its section/page and verbatim text) beside its disposition and mapped rule_ids. This is the reviewable artifact.

Workflow (managed under software change control):
1. **Extract** — PDF segmented into clauses; each given a stable `clause_id` (section-page-sequence).
2. **Map** — each clause dispositioned; `MAPPED` clauses linked to rule_ids.
3. **Review** — business/compliance reviews the Coverage Matrix. Stakeholders may supply missing clauses or challenge dispositions (Objective 3).
4. **Resolve gaps** — `UNMAPPED` clauses become new rule_ids or a documented binning decision.
5. **Attest** — business and technical sign-off recorded (who, when, catalog version). This is the gate.
6. **Baseline** — the attested `mep_rule_catalog.json` version becomes the baseline; changes require re-attestation of the delta only (§9).

### 3.4 Edge Case Register (Objective 1B)

Edge cases are catalogued as first-class items, each with a rule_id reference, expected behaviour, and a test. Initial register derived from the rules:

| Edge case | Rules involved | Expected behaviour |
|-----------|---------------|--------------------|
| Zero volume, non-zero score | COMPLY-RATIO | Ratio undefined → not a breach (no division by zero) |
| Exactly at 50,000 messages | SCORE-EXCL-50K | ≤ 50,000 excluded (boundary inclusive) |
| Exactly at tier boundary (100,000) | TIER-2/TIER-3 | Boundary assignment must be deterministic and documented |
| Ratio exactly = benchmark | COMPLY-BREACH | Not a breach (strictly greater-than) |
| Ratio exactly = 6× benchmark | EXEMPT-6X-BLOCK | Not blocked (strictly greater-than) |
| Mass Action (CA) cancelling N orders | SCORE-*-CA | Counts as N for both raw count and score |
| Spread trade | SCORE-VOL-SPREAD | Volume ×3 (spread + 2 legs) |
| Month split by rule change | EXEMPT-MONTHLY | Explicit policy decision (§9.4) |
| Firm in multiple GFIDs, aggregation active mid-month | AGG-EFFECTIVE-DATE | Aggregation from 1st of following month only |
| MEP holiday but EMT active | SCOPE-HOLIDAYS, EMT-SCOPE-HOLIDAYS | Standard MEP skipped, EMT runs |
| Market maker exempt but EMT breach | EXEMPT-MARKET-MAKER | Exempt from benchmark, still subject to EMT |
| Second-level product, single breaching second | (per-second eval) | Whole day non-compliant |

The register is maintained alongside the catalog; each new rule amendment reviews whether it introduces edge cases.

---

## 4. Rule Model

### 4.1 Two kinds of rules — the fundamental split

Every rule is either a **parameter** or **logic**. This split, established in the catalog, governs where a rule lives and how it changes.

| | Parameter rule | Logic rule |
|---|---------------|-----------|
| Example | Benchmark = 15:1; 6× multiplier; 50,000 threshold | Exemption waterfall order; ratio formula; breach comparison |
| Lives in | Effective-dated BigQuery tables | Versioned Python functions |
| Changes via | Data update (no deploy) | Code change + tests + deploy |
| Who can change | Compliance (with approval) | Engineering (with approval) |
| Traceability | `rule_id` + `effective_from` on the row | `rule_id` in function docstring + git history |

### 4.2 Rule resolution at run time

For a run with as-of date `D`, the engine resolves each rule:
- **Parameter rules:** SQL/lookup with `effective_from <= D < effective_to`.
- **Logic rules:** fixed by the pinned `code_version` in the Run Manifest.

This is why the Run Manifest pins *both* the parameter snapshot and the code version — the two halves of every rule.

---

## 5. Variant / Branching Model (Objective 4)

This section addresses your examples A–H directly. The design goal is **isolation of change**: a new variant is added without disturbing existing variants. Zero code change is not the goal; *contained* code change is.

### 5.1 The dimensional resolution scheme

Rather than hard-coded `if partner_exchange then … elif mass_quote then …` branches, rules resolve along **dimensions**. A rule lookup is a key of dimension values:

```
(program, product_type, product_group, session, month_type, participant_class, as_of_date)
      ↓
resolve to the applicable parameter row or logic handler
```

| Dimension | Values (extensible) | Your example |
|-----------|--------------------|--------------|
| `program` | STANDARD_MEP, EMT_ILINK, EMT_GFID, EMT_SOFR, EMT_MPS, MASS_QUOTE, TREASURY_ROLL, PARTNER | A, E, G |
| `product_type` | FUTURES, OPTIONS | F (Futures/Options differ) |
| `product_group` | ES, SS, ZN, … | H (per-group customization) |
| `session` | RTH, ETH | scoring |
| `month_type` | FRONT, BACK, SPREAD | scoring |
| `participant_class` | STANDARD, MARKET_MAKER, PARTNER_MEMBER | D (MM exemptions) |
| `as_of_date` | temporal | versioning |

### 5.2 How each of your examples is accommodated

| Your example | Mechanism | Change isolation |
|--------------|-----------|------------------|
| **A. MEP vs EMT (many flavours)** | `program` dimension; EMT is a parallel program with its own handler set, sharing nothing with standard MEP resolution | New EMT flavour = new `program` value + its handler; standard MEP untouched |
| **B. Monthly exceptions** | Separate monthly aggregation pass keyed by (gfid, product_group, month); EXEMPT-MONTHLY resolved as its own logic handler | Changing monthly logic touches one handler |
| **C. Hierarchy of rule application** | The exemption waterfall is an ordered, data-driven priority list, not nested conditionals | Reorder/insert a step by changing the ordered list + one handler |
| **D. Market participant exemptions** | `participant_class` dimension + effective-dated MM registration table | New exempt class = new dimension value + registration data |
| **E. Treasury rolls** | `program = TREASURY_ROLL` with its own effective-dated on/off rule | Already isolated; TREAS-ROLL-REMOVAL was a data change |
| **F. Partner exchange different weights** | `program = PARTNER` + partner-specific weight table keyed by exchange | New partner = new weight rows (+ handler only if formula differs) |
| **G. Futures vs Options differ** | `product_type` dimension on parameter lookups | Divergent option logic = new handler bound to product_type=OPTIONS |
| **H. 6× uniform today → per-product-group future** | See §5.3 — the flagship example | Parameter table gains a product_group key; default row preserves current behaviour |

### 5.3 Flagship example: making the 6× multiplier customizable (H)

**Today** (EXEMPT-6X-BLOCK): a single global multiplier of 6 applies to all products.

**Future requirement:** different multipliers per product group.

**Design that makes this a contained change:**

Today the parameter is stored not as a constant but as a single-row table with a wildcard product_group:

```
override_multiplier {
  product_group:  '*'   (wildcard = applies to all)
  multiplier:     6
  effective_from: 2024-10-01
  effective_to:   NULL
  rule_id:        EXEMPT-6X-BLOCK
}
```

The resolver already does *most-specific-match*: look for an exact `product_group` row; fall back to `'*'`. Today only the wildcard exists, so everything gets 6.

**When the requirement lands:** insert product-group-specific rows with a new `effective_from`. No code change — the resolver already handles specificity. The wildcard row remains as the default for unlisted groups.

```
override_multiplier {product_group:'ES', multiplier:8, effective_from:'2026-10-01', ...}
override_multiplier {product_group:'*',  multiplier:6, effective_from:'2024-10-01', ...}
```

This is the design principle in miniature: **anticipate the axis of future variation and store even constants as most-specific-match lookups.** The logic never assumed uniformity, so relaxing uniformity is a data change.

### 5.4 When a new rule genuinely needs new code

Per your confirmation, some changes need code — the goal is isolation. A new logic *kind* (e.g., a partner exchange with a fundamentally different scoring formula) is added as:
1. A new handler function (new rule_id, new tests).
2. A binding: which dimension values route to it.
3. No edit to existing handlers.

The dimensional router means existing rules never branch to accommodate the newcomer — the router does.

---

## 6. Explainability & Proof (R1 — dispute handling)

### 6.1 Requirement

An internal regulatory analyst must be able to run a **Dispute Proof** for a single (gfid, product_group, trade_date) that *proves* why the firm was (non-)compliant, using the exact versions from that day's Run Manifest. The analyst communicates this to the external participant.

### 6.2 The Proof artifact

A `run_type = DISPUTE_PROOF` execution re-runs a single firm-day under the *original* Run Manifest (same code, params, refdata, order data versions) and emits a step-by-step derivation:

```
DISPUTE PROOF — GFID=ABC, Product=ES, Trade Date=2025-11-20
Reproduced under Run Manifest run_id=... (original T+1 run)

INPUTS (order data version v3, as originally consumed)
  RTH: modifications=12,000  cancels=8,000  eliminations=2,000  volume=500
  ETH: modifications=5,000   cancels=4,000  eliminations=1,500  volume=200

STEP 1 — Raw message count [SCORE-RAW-COUNT, §3 p6]
  20,000 + ... = 44,500 (RTH) + ... = ...  → total 84,500

STEP 2 — Exclusion check [SCORE-EXCL-50K, §3 p6]
  84,500 > 50,000 → NOT excluded

STEP 3 — Tier [TIER-3, §6 p7]
  84,500 ∈ (50,000, 100,000] → TIER_3 → multiplier 3×

STEP 4 — Weighted score [SCORE-FORMULA-RTH/ETH, §3 p6]
  RTH: 12,000×1 + 8,000×3 + 2,000×3 = 42,000
  ETH: 5,000×0.1 + 4,000×0.3 + 1,500×0.3 = 2,150
  Total messaging score = 44,150

STEP 5 — Volume ratio [COMPLY-RATIO, §4 p6]
  44,150 / 700 = 63.07

STEP 6 — Effective benchmark [THRESH, Benchmark PDF p2; TIER-3 3×]
  ES base (Tier-3 column) = 45 → effective = 45

STEP 7 — Breach [COMPLY-BREACH, §4 p6]
  63.07 > 45 → BREACH

STEP 8 — 6× check [EXEMPT-6X-BLOCK, §11 p10]
  63.07 > 270 (6×45)? NO → waivers still available

STEP 9 — Waterfall → status
  ... → SURCHARGE_APPLIED / AUTO_WAIVED / ...

CONCLUSION: <status>, surcharge $1,000 [COMPLY-SURCHARGE, §10 p9]
Every number above is reproducible from the pinned versions in this manifest.
```

Each step cites its rule_id and PDF section/page. Because it runs under the original manifest, the proof *is* the original computation, not an approximation.

---

## 7. Workflow Components

### 7.1 RFW / Waiver Lifecycle (R2 — separate workflow)

The waiver request is **stateful workflow**, distinct from the stateless rule engine. It is a separate module with its own state machine:

```
SUBMITTED → UNDER_REVIEW → { GRANTED | DENIED } → APPLIED_TO_BILLING
                              ↓
                          APPEALED → UNDER_REVIEW (loop)
```

- Tied to an `incident_number` (from a surcharge result row).
- Governed by ADMIN-RFW-* rules (window: 1st–10th business day of month after surcharge month).
- Outcome feeds billing (a GRANTED waiver suppresses the surcharge line).
- The engine is *not* aware of RFW state — it computes compliance; the RFW workflow adjusts the financial outcome. Clean separation.

### 7.2 Notification Generation (R5)

The system **generates** notification content (T+1 emails, FADB status entries); a regulator **manually verifies** before release.

- Notifications are generated from result rows + the Dispute Proof derivation, so each notification carries its explanation.
- Status values per ADMIN-STATUS-VALUES: AUTO_WAIVED, Pass_on_Aggregation, Pass_on_Monthly, Potential, Surcharge_Applied.
- Generated → `PENDING_VERIFICATION` → (regulator reviews) → `APPROVED_FOR_SEND` → sent. No auto-send without human gate.
- Distinct content per audience: FADB dashboard entry, executing-firm email, clearing-firm fallback (ADMIN-EMAIL-T1, MQ-NOTIFICATION).

---

## 8. Testing Strategy (Objectives 2, 3)

Four layers, each with a distinct owner and purpose.

### 8.1 Unit tests (engineering)

Each logic rule is a pure function → tested in isolation with boundary cases from the Edge Case Register (§3.4). No infrastructure. Every rule_id with `change_type` LOGIC has ≥1 unit test asserting its boundary behaviour. Coverage target: every logic rule_id and every edge case has a test.

### 8.2 Functional tests (engineering + QA)

End-to-end pipeline on synthetic data: JSON → parameter tables → scoring → engine → results. Asserts the *whole chain* produces expected statuses for crafted firm-days. Includes the parallel EMT track and the mass quote pipeline as separate functional suites.

### 8.3 Reproducibility / regression harness (engineering)

The temporal-architecture test: run trade date `D`, snapshot the result, later re-run `D` under the same manifest, assert bit-identical output. This is the test that protects backdated audit runs. Run in CI on every change to the engine.

### 8.4 Business-English manual test cases (business users — Objective 3)

Written in plain Given/When/Then with real dollar amounts and firm scenarios, runnable by business users against a lower environment, verifiable against actual data by those users. Example:

```
TEST: Firm breaches ES benchmark but qualifies for monthly waiver

GIVEN a firm ABC trading E-mini S&P 500 (ES)
  AND on 15 July it sent 84,500 messages (Tier 3, 3× benchmark = 45)
  AND its daily volume ratio was 63 (above 45 → a breach)
  AND its ratio was below 270 (6× benchmark, so waivers still apply)
  AND for the whole month of July its combined ratio was 40 (below 45)

WHEN the monthly waiver process runs at month end

THEN the daily breach on 15 July is waived
  AND the status shown to the firm is "Pass_on_Monthly"
  AND no $1,000 surcharge is billed

WHY (rules applied): SCORE-EXCL-50K, TIER-3, COMPLY-BREACH,
     EXEMPT-6X-BLOCK (not triggered), EXEMPT-MONTHLY (triggered)
```

Each business test names the rules it exercises, so a failure points straight to a rule_id. A full suite covers: exclusion, each tier, breach, 6× block, auto-waiver, monthly waiver, market-maker exemption, aggregation, EMT breach, mass quote, holiday behaviour.

---

## 9. Change Management (Objective 4, R8)

### 9.1 Amendment types and their paths

| Amendment | Path | Re-attestation | Deploy? |
|-----------|------|----------------|---------|
| New quarterly benchmark | New effective-dated rows in parameter table | Delta only | No |
| Threshold value change (e.g., SOFR 50:1) | New effective-dated row | Delta only | No |
| New product group added to scope | New rows + reference data | Delta only | No |
| New parameter dimension (6× per-group) | New rows under existing resolver | Delta only | No |
| New logic rule (new handler) | New function + tests + router binding | New rule_id attested | Yes |
| Rule deletion | `effective_to` set; handler retained for replay | Delta | No (data) |

### 9.2 The delta re-attestation principle

An amendment re-attests only the *changed* clauses, not the whole catalog. The Coverage Matrix diff shows exactly which clauses/rule_ids changed; business + tech sign off on the delta. This keeps quarterly benchmark updates lightweight while preserving the full-attestation guarantee.

### 9.3 Effective-dating preserves reproducibility

Because amendments are new effective-dated rows (never overwrites), a backdated run for a pre-amendment date resolves to the pre-amendment values automatically. Change management and temporal reproducibility are the same mechanism viewed from two angles.

### 9.4 Mid-month rule change control point (R7)

Policy avoids mid-month changes. If unavoidable:
- Daily results: no issue — each day resolves to its correct value via effective dates.
- Monthly aggregation (EXEMPT-MONTHLY): explicit decision required — does the month use the pre- or post-change benchmark, or split? This is a documented control-point decision recorded on the Run Manifest, not a silent default.

---

## 10. Controls & Reconciliation (R4)

A dedicated module, independent of the engine, that answers "how do we know production is right?"

| Control | What it checks |
|---------|----------------|
| **Independent recomputation** | A second, minimal implementation recomputes a sample of firm-days; mismatch = alert. Guards against engine bugs. |
| **Control totals** | Row counts, sum of scores/volumes per product group reconcile against source data totals. Guards against data loss in the pipeline. |
| **Movement exceptions** | Day-over-day and vs-prior-run deltas flagged when a firm's status or ratio moves beyond a threshold. Guards against silent regressions and surfaces restatements. |
| **Coverage assertion** | Every in-scope GFID × product group with activity has a result row. Guards against dropped firms. |
| **Manifest completeness** | Every result row ties to a valid Run Manifest with all versions pinned. Guards reproducibility. |
| **Attestation gate** | No run uses a rule catalog version that isn't attested. Guards rule integrity. |

Controls run after every batch and emit an exceptions report reviewed before results are published/notified.

---

## 11. Access Control & Segregation of Duties (R6)

Segregation is required for a regulatory system; the design enforces distinct roles, with **manual override** available (per your note) under recorded authorization.

| Role | Can | Cannot |
|------|-----|--------|
| Rule Author (Compliance) | Draft parameter changes, propose clause mappings | Attest own change; deploy code |
| Rule Attester (Business + Tech) | Sign off on Coverage Matrix delta | Author the change they attest |
| Engineer | Author logic handlers, deploy | Attest business rules; edit prod parameters directly |
| Operator | Trigger runs, backdated/dispute runs | Change rules or results |
| Waiver Reviewer | Grant/deny RFW | Alter compliance computation |
| Regulator/Analyst | Verify notifications, run Dispute Proofs, view all | Change rules or results |

Manual override (e.g., emergency parameter change) is permitted but always recorded: who, when, why, and it forces a re-attestation and a controls re-run. No override bypasses the audit trail.

---

## 12. Component & Data-Flow Summary

```
Source PDFs
   │ (extract + clause segmentation)
   ▼
Coverage Matrix ──attest──► mep_rule_catalog.json (baselined, versioned)
   │
   │ (generate_bq_sql from parameter rules)
   ▼
Parameter tables (effective-dated)   Reference data (effective-dated)   Order data (versioned)
   └───────────────┬────────────────────────────┬──────────────────────────┘
                   ▼                             ▼
             Rule Resolver  ◄── Run Manifest (pins all versions + code) ──►  Code (pinned version)
                   │
                   ▼
          SQL scoring (BigQuery)  →  daily_scores
                   │
                   ▼
          Python rule engine (dimensional router → handlers)
                   │
                   ▼
          compliance_result (append-only, is_current)
                   ├──► Controls & Reconciliation (independent recompute, totals, exceptions)
                   ├──► Notification Generation (→ regulator verification → send)
                   ├──► Dispute Proof (single firm-day, cited derivation)
                   └──► RFW Workflow (separate state machine → billing)
```

---

## 13. What this design delivers against each objective

| Objective | Delivered by |
|-----------|--------------|
| 1 — Faithful, complete capture | Clause-level Coverage Matrix + human attestation + binned buckets (§3) |
| 1B — Edge cases | Edge Case Register, maintained with the catalog (§3.4) |
| 2 — Method validation | 4-layer testing incl. reproducibility harness (§8) |
| 3 — Manual business tests | Business-English Given/When/Then suite (§8.4) |
| 4 — Maintain / amend / branch | Dimensional variant model + delta re-attestation (§5, §9) |
| 5 — Communicable design | This doc + business Word companion; two-kinds-of-rules framing |
| A — Backdated reproduce-as-was | Run Manifest + effective-dating on all four axes (§2) |
| B — Immutable results + restatement | Append-only results, is_current, supersedes chain (§2.4–2.5) |
| R1 — Dispute proof | Cited step-by-step derivation under original manifest (§6) |
| R2 — RFW workflow | Separate state machine, feeds billing (§7.1) |
| R3 — Late data rerun | Restatement runs on new data version (§2.5) |
| R4 — Controls | Independent recompute + reconciliation module (§10) |
| R5 — Notifications | Generated + human-verified, carry explanations (§7.2) |
| R6 — Segregation of duties | Role model with recorded manual override (§11) |
| R7 — Failure/mid-month | Idempotent runs; documented monthly control point (§2.5, §9.4) |
| R8 — Attestation & change control | Attestation workflow + delta re-attestation (§3.3, §9) |
