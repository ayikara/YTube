from __future__ import annotations

import logging
from pathlib import Path

from google.cloud import storage

from src.exceptions import GCSWriteError

logger = logging.getLogger(__name__)


class GCSClient:
    def __init__(self) -> None:
        self.client = storage.Client()

    def upload_file(self, bucket_name: str, source_path: str, destination_blob_name: str) -> None:
        try:
            bucket = self.client.bucket(bucket_name)
            blob = bucket.blob(destination_blob_name)
            blob.upload_from_filename(source_path)
            logger.info("Uploaded file to gs://%s/%s", bucket_name, destination_blob_name)
        except Exception as exc:
            raise GCSWriteError(
                f"Failed to upload {source_path} to gs://{bucket_name}/{destination_blob_name}: {exc}"
            ) from exc

    def upload_directory_file(self, bucket_name: str, local_file: Path, prefix: str) -> None:
        self.upload_file(bucket_name, str(local_file), f"{prefix.rstrip('/')}/{local_file.name}")
