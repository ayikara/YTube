class ConfigurationError(Exception):
    """Raised when application configuration is invalid."""


class DataValidationError(Exception):
    """Raised when dataframe validation fails."""


class BigQueryExecutionError(Exception):
    """Raised when a BigQuery operation fails."""


class GCSWriteError(Exception):
    """Raised when a GCS write or upload fails."""
