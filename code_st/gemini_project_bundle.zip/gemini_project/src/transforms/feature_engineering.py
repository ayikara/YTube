from __future__ import annotations

import numpy as np
import pandas as pd


def add_amount_bucket(dataframe: pd.DataFrame) -> pd.DataFrame:
    engineered = dataframe.copy()
    engineered["amount_bucket"] = np.select(
        [
            engineered["amount"] < 100,
            engineered["amount"].between(100, 500, inclusive="left"),
            engineered["amount"] >= 500,
        ],
        ["low", "medium", "high"],
        default="unknown",
    )
    return engineered
