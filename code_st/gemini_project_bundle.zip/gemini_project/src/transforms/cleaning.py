from __future__ import annotations

import pandas as pd


def clean_dataframe(dataframe: pd.DataFrame, fillna_defaults: dict[str, object], drop_duplicates: bool = True) -> pd.DataFrame:
    cleaned = dataframe.copy()
    if drop_duplicates:
        cleaned = cleaned.drop_duplicates()
    if fillna_defaults:
        cleaned = cleaned.fillna(fillna_defaults)
    return cleaned
