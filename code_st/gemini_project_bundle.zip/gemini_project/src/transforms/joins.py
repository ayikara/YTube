from __future__ import annotations

import pandas as pd


def safe_join(left: pd.DataFrame, right: pd.DataFrame, on: list[str], how: str = "left", validate: str = "m:1") -> pd.DataFrame:
    return left.merge(right, on=on, how=how, validate=validate)
