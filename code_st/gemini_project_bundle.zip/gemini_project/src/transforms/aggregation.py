from __future__ import annotations

import pandas as pd


def aggregate_amount_by_customer(dataframe: pd.DataFrame) -> pd.DataFrame:
    return (
        dataframe.groupby("customer_id", as_index=False)
        .agg(total_amount=("amount", "sum"), order_count=("amount", "size"))
    )
