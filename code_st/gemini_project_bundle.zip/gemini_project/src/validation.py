from __future__ import annotations

import pandas as pd

from src.exceptions import DataValidationError


def validate_required_columns(dataframe: pd.DataFrame, required_columns: list[str]) -> None:
    missing = [column for column in required_columns if column not in dataframe.columns]
    if missing:
        raise DataValidationError(f"Missing required columns: {missing}")


def validate_non_negative_columns(dataframe: pd.DataFrame, columns: list[str]) -> None:
    for column in columns:
        if column in dataframe.columns and (dataframe[column] < 0).any():
            raise DataValidationError(f"Column contains negative values: {column}")


def validate_unique_keys(dataframe: pd.DataFrame, keys: list[str]) -> None:
    if keys and dataframe.duplicated(subset=keys).any():
        raise DataValidationError(f"Duplicate values found for keys: {keys}")


def run_validations(dataframe: pd.DataFrame, required_columns: list[str], non_negative_columns: list[str], unique_keys: list[str]) -> None:
    validate_required_columns(dataframe, required_columns)
    validate_non_negative_columns(dataframe, non_negative_columns)
    validate_unique_keys(dataframe, unique_keys)
