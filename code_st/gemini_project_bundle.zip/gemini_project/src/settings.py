from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field

from src.exceptions import ConfigurationError


class ProjectConfig(BaseModel):
    name: str
    environment: str = "dev"
    log_level: str = "INFO"
    run_local: bool = True


class BigQueryConfig(BaseModel):
    project_id: str | None = None
    location: str = "US"
    source_sql: str
    query_params: dict[str, Any] = Field(default_factory=dict)
    destination_table: str | None = None
    write_disposition: str = "WRITE_TRUNCATE"


class GCSConfig(BaseModel):
    enabled: bool = True
    bucket: str
    intermediate_prefix: str
    plots_prefix: str
    exports_prefix: str


class IOConfig(BaseModel):
    local_output_dir: str = "output"
    local_plot_dir: str = "output/plots"
    local_export_dir: str = "output/exports"
    local_table_dir: str = "output/tables"


class TransformationConfig(BaseModel):
    drop_duplicates: bool = True
    fillna_defaults: dict[str, Any] = Field(default_factory=dict)
    filters: dict[str, Any] = Field(default_factory=dict)
    feature_flags: dict[str, bool] = Field(default_factory=dict)
    column_mappings: dict[str, str] = Field(default_factory=dict)


class ValidationConfig(BaseModel):
    required_columns: list[str] = Field(default_factory=list)
    unique_keys: list[str] = Field(default_factory=list)
    non_negative_columns: list[str] = Field(default_factory=list)
    max_null_fraction: float = 1.0


class VisualizationConfig(BaseModel):
    enabled: bool = True
    save_formats: list[str] = Field(default_factory=lambda: ["png"])


class AppConfig(BaseModel):
    project: ProjectConfig
    bigquery: BigQueryConfig
    gcs: GCSConfig
    io: IOConfig
    transformations: TransformationConfig
    validation: ValidationConfig
    visualization: VisualizationConfig


def load_config(config_path: str | Path) -> AppConfig:
    path = Path(config_path)
    if not path.exists():
        raise ConfigurationError(f"Config file not found: {path}")

    with path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)

    try:
        return AppConfig.model_validate(raw)
    except Exception as exc:  # pydantic provides context
        raise ConfigurationError(f"Invalid configuration: {exc}") from exc
