"""Production-ready BigQuery to pandas transformation package."""
