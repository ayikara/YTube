from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

from src.bq_client import BigQueryClient
from src.gcs_client import GCSClient
from src.io_utils import ensure_directory
from src.settings import AppConfig
from src.transforms.aggregation import aggregate_amount_by_customer
from src.transforms.cleaning import clean_dataframe
from src.transforms.feature_engineering import add_amount_bucket
from src.validation import run_validations
from src.visualization import save_distribution_plot

logger = logging.getLogger(__name__)


class TransformationPipeline:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.bq_client = BigQueryClient(
            project_id=config.bigquery.project_id,
            location=config.bigquery.location,
        )
        self.gcs_client = GCSClient() if config.gcs.enabled else None

    def run(self) -> pd.DataFrame:
        dataframe = self.bq_client.run_sql_file_to_dataframe(
            sql_path=self.config.bigquery.source_sql,
            query_params=self.config.bigquery.query_params,
        )

        logger.info("Initial dataframe shape=%s", dataframe.shape)
        run_validations(
            dataframe,
            required_columns=self.config.validation.required_columns,
            non_negative_columns=self.config.validation.non_negative_columns,
            unique_keys=self.config.validation.unique_keys,
        )

        dataframe = clean_dataframe(
            dataframe,
            fillna_defaults=self.config.transformations.fillna_defaults,
            drop_duplicates=self.config.transformations.drop_duplicates,
        )

        if self.config.transformations.feature_flags.get("enable_amount_bucket", False):
            dataframe = add_amount_bucket(dataframe)

        aggregated = aggregate_amount_by_customer(dataframe)
        logger.info("Aggregated dataframe shape=%s", aggregated.shape)

        self._write_local_outputs(aggregated)
        self._write_optional_cloud_outputs(aggregated)
        self._write_optional_bigquery_output(aggregated)
        return aggregated

    def _write_local_outputs(self, dataframe: pd.DataFrame) -> None:
        export_dir = ensure_directory(self.config.io.local_export_dir)
        plot_dir = ensure_directory(self.config.io.local_plot_dir)

        export_path = export_dir / "aggregated.parquet"
        dataframe.to_parquet(export_path, index=False)
        logger.info("Wrote local parquet export path=%s", export_path)

        if self.config.visualization.enabled and "total_amount" in dataframe.columns:
            plot_path = save_distribution_plot(dataframe, "total_amount", str(plot_dir))
            logger.info("Saved plot path=%s", plot_path)

    def _write_optional_cloud_outputs(self, dataframe: pd.DataFrame) -> None:
        if not self.gcs_client:
            return

        local_parquet = Path(self.config.io.local_export_dir) / "aggregated.parquet"
        self.gcs_client.upload_directory_file(
            bucket_name=self.config.gcs.bucket,
            local_file=local_parquet,
            prefix=self.config.gcs.exports_prefix,
        )

        plot_path = Path(self.config.io.local_plot_dir) / "total_amount_distribution.png"
        if plot_path.exists():
            self.gcs_client.upload_directory_file(
                bucket_name=self.config.gcs.bucket,
                local_file=plot_path,
                prefix=self.config.gcs.plots_prefix,
            )

    def _write_optional_bigquery_output(self, dataframe: pd.DataFrame) -> None:
        if self.config.bigquery.destination_table:
            self.bq_client.write_dataframe(
                dataframe,
                destination_table=self.config.bigquery.destination_table,
                write_disposition=self.config.bigquery.write_disposition,
            )
