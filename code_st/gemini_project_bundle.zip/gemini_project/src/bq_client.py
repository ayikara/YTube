from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd
from google.cloud import bigquery

from src.exceptions import BigQueryExecutionError

logger = logging.getLogger(__name__)


class BigQueryClient:
    def __init__(self, project_id: str | None = None, location: str = "US") -> None:
        self.client = bigquery.Client(project=project_id, location=location)

    def run_sql_file_to_dataframe(self, sql_path: str, query_params: dict | None = None) -> pd.DataFrame:
        try:
            sql = Path(sql_path).read_text(encoding="utf-8")
            logger.info("Executing BigQuery SQL file: %s", sql_path)
            job_config = bigquery.QueryJobConfig(query_parameters=[])
            query_job = self.client.query(sql, job_config=job_config)
            dataframe = query_job.result().to_dataframe(create_bqstorage_client=True)
            logger.info("Retrieved dataframe with shape=%s", dataframe.shape)
            return dataframe
        except Exception as exc:
            raise BigQueryExecutionError(f"Failed to execute query from {sql_path}: {exc}") from exc

    def write_dataframe(self, dataframe: pd.DataFrame, destination_table: str, write_disposition: str) -> None:
        try:
            job_config = bigquery.LoadJobConfig(write_disposition=write_disposition)
            job = self.client.load_table_from_dataframe(dataframe, destination_table, job_config=job_config)
            job.result()
            logger.info("Wrote dataframe to BigQuery table=%s rows=%s", destination_table, len(dataframe))
        except Exception as exc:
            raise BigQueryExecutionError(f"Failed to write dataframe to {destination_table}: {exc}") from exc
