from __future__ import annotations

import argparse
import logging
import sys

from src.logger import configure_logging
from src.pipeline import TransformationPipeline
from src.settings import load_config

logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the BigQuery to pandas transformation pipeline.")
    parser.add_argument("--config", required=True, help="Path to YAML config file.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config)
    configure_logging(log_level=config.project.log_level)

    logger.info("Starting transformation pipeline")
    pipeline = TransformationPipeline(config)
    result = pipeline.run()
    logger.info("Pipeline completed successfully rows=%s cols=%s", result.shape[0], result.shape[1])
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        logger.exception("Pipeline failed")
        sys.exit(1)
