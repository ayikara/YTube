from src.transforms.cleaning import clean_dataframe


def test_clean_dataframe_removes_duplicates_and_fills_nulls(sample_dataframe):
    duplicated = sample_dataframe.copy()
    duplicated.loc[3] = duplicated.loc[0]
    duplicated.loc[1, "category"] = None

    result = clean_dataframe(duplicated, fillna_defaults={"category": "unknown"}, drop_duplicates=True)

    assert len(result) == 3
    assert "unknown" in result["category"].tolist()
