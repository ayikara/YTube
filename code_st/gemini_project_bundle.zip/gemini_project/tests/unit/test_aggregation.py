from src.transforms.aggregation import aggregate_amount_by_customer


def test_aggregate_amount_by_customer(sample_dataframe):
    result = aggregate_amount_by_customer(sample_dataframe)
    totals = dict(zip(result["customer_id"], result["total_amount"]))
    assert totals[1] == 250.0
    assert totals[2] == 700.0
