import pandas as pd
import pytest

from src.exceptions import DataValidationError
from src.validation import validate_required_columns


def test_validate_required_columns_passes(sample_dataframe):
    validate_required_columns(sample_dataframe, ["customer_id", "amount"])


def test_validate_required_columns_fails(sample_dataframe):
    with pytest.raises(DataValidationError):
        validate_required_columns(sample_dataframe[["customer_id"]], ["customer_id", "amount"])
