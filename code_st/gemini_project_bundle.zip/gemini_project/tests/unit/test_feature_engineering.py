from src.transforms.feature_engineering import add_amount_bucket


def test_add_amount_bucket(sample_dataframe):
    result = add_amount_bucket(sample_dataframe)
    assert result["amount_bucket"].tolist() == ["low", "medium", "high"]
