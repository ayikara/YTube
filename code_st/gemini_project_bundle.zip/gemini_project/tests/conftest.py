from __future__ import annotations

import pandas as pd
import pytest


@pytest.fixture
def sample_dataframe() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "customer_id": [1, 1, 2],
            "amount": [50.0, 200.0, 700.0],
            "category": ["a", "a", "b"],
        }
    )
