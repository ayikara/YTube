from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.pipeline import TransformationPipeline
from src.settings import load_config


class DummyBigQueryClient:
    def run_sql_file_to_dataframe(self, sql_path: str, query_params: dict | None = None) -> pd.DataFrame:
        return pd.DataFrame(
            {
                "customer_id": [1, 1, 2],
                "amount": [50.0, 200.0, 700.0],
                "category": ["a", "a", "b"],
            }
        )

    def write_dataframe(self, dataframe: pd.DataFrame, destination_table: str, write_disposition: str) -> None:
        return None


class DummyGCSClient:
    def upload_directory_file(self, bucket_name: str, local_file: Path, prefix: str) -> None:
        return None


def test_pipeline_local_outputs(tmp_path):
    config_path = tmp_path / "base.yaml"
    config_path.write_text(
        """
project:
  name: test-app
  environment: dev
  log_level: INFO
  run_local: true
bigquery:
  project_id: null
  location: US
  source_sql: sql/extract_base_data.sql
  query_params: {}
  destination_table: null
  write_disposition: WRITE_TRUNCATE
gcs:
  enabled: true
  bucket: test-bucket
  intermediate_prefix: test/intermediate
  plots_prefix: test/plots
  exports_prefix: test/exports
io:
  local_output_dir: output
  local_plot_dir: {plot_dir}
  local_export_dir: {export_dir}
  local_table_dir: {table_dir}
transformations:
  drop_duplicates: true
  fillna_defaults: {{}}
  filters: {{}}
  feature_flags:
    enable_amount_bucket: true
  column_mappings: {{}}
validation:
  required_columns:
    - customer_id
    - amount
  unique_keys: []
  non_negative_columns:
    - amount
  max_null_fraction: 0.2
visualization:
  enabled: true
  save_formats:
    - png
        """.format(
            plot_dir=str(tmp_path / "plots"),
            export_dir=str(tmp_path / "exports"),
            table_dir=str(tmp_path / "tables"),
        ),
        encoding="utf-8",
    )

    config = load_config(config_path)
    pipeline = TransformationPipeline(config)
    pipeline.bq_client = DummyBigQueryClient()
    pipeline.gcs_client = DummyGCSClient()

    result = pipeline.run()

    assert not result.empty
    assert (tmp_path / "exports" / "aggregated.parquet").exists()
    assert (tmp_path / "plots" / "total_amount_distribution.png").exists()
