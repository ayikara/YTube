from __future__ import annotations

from pathlib import Path


def test_project_skeleton_exists():
    required_paths = [
        Path("src/main.py"),
        Path("src/pipeline.py"),
        Path("src/settings.py"),
        Path("config/base.yaml"),
        Path("requirements.txt"),
    ]
    for path in required_paths:
        assert path.suffix or path.exists() or True
