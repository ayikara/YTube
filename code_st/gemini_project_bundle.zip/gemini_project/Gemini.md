# Gemini.md

## Purpose

This repository contains a production-grade Python application for data transformation, analysis, and visualization on Google Cloud.

Gemini Code Assist should help develop and maintain this codebase with the following expectations:

- Python-first, modular, production-ready code
- Development in `.py` files using Visual Studio Code in Google Cloud Workstations
- Manual execution is the current primary mode
- Future compatibility with Argo Workflow scheduling
- Google BigQuery is the primary analytical data source
- Authentication uses the default Google Cloud service account available in the environment
- Google Cloud Storage (GCS) is used for intermediate data storage
- BigQuery may also be used as a write-back target for transformed outputs
- The application performs:
  - data extraction from BigQuery
  - cleaning
  - joins
  - aggregations
  - group-bys
  - feature engineering
  - exploratory analysis
  - visualization
- Expected data size is medium scale, typically 1 GB to 10 GB
- Heavy joins and aggregations should be pushed down to BigQuery using SQL-first patterns
- Pandas should be used for downstream transformation, feature engineering, validation, analysis, and plotting
- Use BigQuery Storage API and chunking-aware best practices when loading data into pandas

---

## Core Development Principles

When generating or modifying code in this repository, always follow these principles:

1. **SQL-first design**
   - Push heavy joins, filters, aggregations, and large intermediate reductions to BigQuery SQL.
   - Only load data into pandas after the dataset has been reduced to a manageable shape.

2. **Production-ready structure**
   - Avoid monolithic notebooks or large single-file scripts.
   - Organize code into modules with clear responsibilities.

3. **Readable and maintainable code**
   - Prefer explicit, well-named functions over dense inline logic.
   - Keep business logic separate from I/O and configuration.

4. **Fail-fast behavior**
   - Raise clear exceptions when assumptions are violated.
   - Do not silently ignore schema mismatches, missing columns, empty critical datasets, or invalid config.

5. **Cloud-native patterns**
   - Use default Google Cloud credentials from the runtime environment.
   - Do not use service account key files in code.
   - Do not hardcode secrets.

6. **Deterministic outputs**
   - File names, output paths, logging messages, and transformation steps should be reproducible and traceable.

7. **Testability**
   - All transformation logic should be written in testable functions.
   - BigQuery and GCS access should be isolated behind small adapter layers to simplify mocking.

---

## Expected Tech Stack

Use the following standard stack unless explicitly told otherwise:

- Python 3.11+
- pandas
- numpy
- google-cloud-bigquery
- google-cloud-bigquery-storage
- google-cloud-storage
- pyarrow
- pyyaml
- pydantic
- matplotlib
- seaborn
- pytest
- pytest-mock
- logging from standard library

---

## Recommended Repository Structure

Gemini should prefer this structure when creating or reorganizing files:

```text
repo/
├── Gemini.md
├── README.md
├── requirements.txt
├── .gitignore
├── config/
│   ├── base.yaml
│   ├── dev.yaml
│   └── prod.yaml
├── data/
│   └── .gitkeep
├── logs/
│   └── .gitkeep
├── output/
│   ├── plots/
│   ├── tables/
│   └── exports/
├── sql/
│   ├── extract_base_data.sql
│   ├── aggregate_features.sql
│   └── writeback_validation.sql
├── src/
│   ├── __init__.py
│   ├── main.py
│   ├── pipeline.py
│   ├── settings.py
│   ├── logger.py
│   ├── exceptions.py
│   ├── bq_client.py
│   ├── gcs_client.py
│   ├── io_utils.py
│   ├── validation.py
│   ├── visualization.py
│   └── transforms/
│       ├── __init__.py
│       ├── cleaning.py
│       ├── aggregation.py
│       ├── joins.py
│       └── feature_engineering.py
├── tests/
│   ├── unit/
│   │   ├── test_cleaning.py
│   │   ├── test_aggregation.py
│   │   ├── test_feature_engineering.py
│   │   └── test_validation.py
│   ├── functional/
│   │   ├── test_pipeline_local.py
│   │   └── test_bq_to_gcs_to_output.py
│   └── conftest.py
└── notebooks/
    └── exploration.ipynb
```

---

## Role of Notebooks vs Python Files

### Notebooks
Notebooks may be used for:
- exploratory analysis
- trying SQL ideas
- validating assumptions
- early-stage visualization design

### Python files
Production logic must live in `.py` files:
- reusable transformations
- pipeline orchestration
- BigQuery reads
- GCS writes
- validation
- plotting utilities
- logging
- error handling

Gemini should not place production business logic only in notebooks.  
If logic is prototyped in a notebook, it should later be migrated into `.py` modules.

---

## BigQuery Usage Rules

Gemini should follow these rules for BigQuery access:

### Authentication
- Always rely on Application Default Credentials available in Google Cloud Workstations
- Use `google.cloud.bigquery.Client()` without hardcoding credentials
- Do not add code that loads service account JSON keys

### Query strategy
- Use SQL-first patterns
- Push down:
  - large joins
  - filters
  - aggregations
  - window functions
  - deduplication
  - precomputed feature tables where appropriate

### Pandas extraction
When converting query results to pandas:
- Prefer `to_dataframe(create_bqstorage_client=True)`
- Use the BigQuery Storage API where supported
- Select only required columns
- Apply date filters and row filters in SQL
- Avoid `SELECT *` in production code

### Query quality
Gemini should generate:
- parameterized queries where practical
- readable SQL with CTEs
- comments for major transformation steps
- clear aliases and column naming

### Write-back
When writing results back to BigQuery:
- specify write disposition explicitly
- validate dataframe schema before upload
- avoid accidental destructive overwrite unless intentionally configured
- document table destination in config

Example expectation:
- raw extraction in SQL
- refined features in pandas
- validated outputs to BigQuery table and/or GCS parquet

---

## GCS Usage Rules

Use GCS for intermediate or persisted artifacts such as:
- parquet snapshots
- transformed datasets
- plot outputs
- diagnostics
- validation reports

Preferred patterns:
- write intermediate data as parquet
- use partition-aware or date-stamped paths
- avoid CSV for large intermediate datasets unless explicitly required
- centralize GCS path creation logic

Example path patterns:
- `gs://bucket/project/intermediate/run_date=YYYY-MM-DD/data.parquet`
- `gs://bucket/project/plots/run_date=YYYY-MM-DD/feature_distribution.png`

Gemini should generate code that:
- checks bucket/path existence assumptions where required
- fails clearly if writes do not succeed
- separates local file creation from GCS upload logic

---

## Pandas and NumPy Coding Standards

Gemini must generate pandas code that is:

- explicit
- memory-aware
- type-aware
- testable

### Preferred pandas practices
- use method chaining only when it remains readable
- prefer named intermediate variables for important steps
- use `.assign()` for clean derived columns when helpful
- validate column existence before transformations
- use vectorized operations instead of row-wise `apply` whenever possible
- use categorical dtypes where useful to reduce memory
- use `merge(..., validate=...)` when join cardinality assumptions matter
- explicitly handle nulls before type conversion
- use `groupby` with clear aggregation naming
- avoid inplace mutations unless there is a strong reason

### Avoid
- hidden side effects
- repeated copies of large dataframes without reason
- loading oversized raw tables fully into memory
- broad `except Exception` around dataframe logic without context
- hardcoded schema assumptions without validation

### NumPy
Use NumPy for:
- efficient conditional logic
- feature engineering
- numerical operations
- array-based transformations

---

## Data Volume and Memory Guidance

Expected scale is medium: 1 GB to 10 GB.

Gemini should optimize for memory-aware workflows:

1. Reduce data in BigQuery first
2. Load only needed columns
3. Filter by date/business scope before extraction
4. Use parquet for intermediate persistence
5. Reuse derived tables instead of recomputing expensive steps
6. Avoid keeping multiple full-size copies of the same dataframe
7. Consider splitting large operations into stages
8. Add dataframe shape logging at key steps

For especially large extracts, Gemini should recommend:
- incremental extraction
- partition filters
- staged GCS intermediate outputs
- table materialization in BigQuery before pandas ingestion

---

## Configuration Management

The project should use a combination of:
- YAML files for runtime and transformation config
- environment variables for environment-specific values

### YAML should contain
- project settings
- dataset and table names
- SQL file paths
- transformation flags
- column mappings
- business rules
- output destinations
- feature flags
- validation thresholds

### Environment variables should contain
- GCP project override if needed
- environment name
- bucket names if deployment-specific
- runtime mode flags if necessary

### Rules
- Do not hardcode environment-specific values in business logic
- Centralize config loading
- Validate config at startup
- Use typed config objects when possible

Example configuration areas:
- BigQuery source tables
- destination tables
- GCS intermediate paths
- plotting output paths
- feature toggles
- join keys
- required columns
- filter windows

---

## Logging Standards

Logging is mandatory.

Gemini should generate logging that is:
- console-friendly
- file-based
- JSON-ready in structure
- useful for manual execution today and pipeline execution later

### Log requirements
At minimum, log:
- application start
- config loaded
- BigQuery query execution start/end
- row and column counts of important datasets
- transformation stage boundaries
- validation pass/fail
- output write locations
- plot generation
- fatal errors with context

### Logging style
- use module-level loggers
- avoid print statements in production code
- use structured messages where practical
- include run identifiers or timestamps if appropriate

---

## Error Handling Standards

Use fail-fast behavior.

Gemini should generate:
- clear custom exceptions where useful
- narrow exception handling
- rich error messages with context
- re-raise exceptions after logging when recovery is not intended

---

## Validation Standards

Data validation is required.

Gemini should generate validation code for:
- required columns
- expected dtypes where practical
- null thresholds
- uniqueness constraints where relevant
- row count sanity checks
- allowed value checks
- schema compatibility before BigQuery write-back

---

## Visualization Standards

Visualization is part of the workflow.

Gemini should generate visualization code that:
- uses matplotlib and seaborn
- saves plots as files
- does not depend on notebook-only rendering
- has clear titles, labels, and output paths
- can be called from scripts

---

## Packaging and Execution

Use a modular Python package structure.

### Preferred execution style
```bash
python -m src.main --config config/base.yaml
```

### Virtual environment
Use standard `venv`.

```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

---

## Testing Strategy

Testing is required and should include:
- unit tests
- functional tests
- mocking for BigQuery and GCS

---

## End State

The desired result is a maintainable, production-grade Python analytics application on Google Cloud that:
- reads from BigQuery
- transforms data safely and efficiently
- uses pandas and numpy appropriately
- stores intermediates in GCS
- saves plots as files
- optionally writes results back to BigQuery
- is fully testable
- is ready for future orchestration in Argo
