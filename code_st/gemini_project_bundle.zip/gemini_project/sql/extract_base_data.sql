-- Replace the source table below with your production table.
WITH source_data AS (
    SELECT
        customer_id,
        CAST(order_amount AS FLOAT64) AS amount,
        order_date,
        category
    FROM `your_project.your_dataset.your_source_table`
    WHERE 1 = 1
)
SELECT *
FROM source_data
