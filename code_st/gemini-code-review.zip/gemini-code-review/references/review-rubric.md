# Review Rubric

## Output Template

### Concise pass/fail checklist
- Python standards: PASS | PARTIAL | FAIL
- SQL standards: PASS | PARTIAL | FAIL
- Correctness and bug risk: PASS | PARTIAL | FAIL
- BigQuery cost and performance: PASS | PARTIAL | FAIL
- Notebook reproducibility: PASS | PARTIAL | FAIL | N/A
- Logging and error handling: PASS | PARTIAL | FAIL
- Config and environment handling: PASS | PARTIAL | FAIL
- Testing and validation: PASS | PARTIAL | FAIL

### Critical
- Title
- Why it matters
- Location
- Fix

### High
- Title
- Why it matters
- Location
- Fix

### Medium
- Title
- Why it matters
- Location
- Fix

### Low
- Title
- Why it matters
- Location
- Fix

### Nit
- Title
- Why it matters
- Location
- Fix

### Line-specific comments
- `file.py:10-22 — comment`
- `query.sql:8-18 — comment`
- `analysis.ipynb cell 4 — comment`

### Suggested rewrites
Use short before/after snippets or direct replacement snippets.

### Final summary with priorities
- Priority 1
- Priority 2
- Priority 3
- Merge recommendation

## BigQuery review heuristics

### Correctness
- Join keys are explicit and cardinality assumptions are checked
- Grouping matches business grain
- Null semantics are intentional
- Window functions use stable partition and order clauses
- Date logic is timezone-aware when relevant

### Cost and performance
- Filters are applied as early as possible
- Partition columns are used in prune-friendly ways
- Only needed columns are selected
- Large repeated CTE scans are avoided when a staged table would help
- Expensive expressions are not repeated unnecessarily

### Readability
- CTEs have meaningful names
- One transformation step per CTE where practical
- Final select is easy to map to upstream logic
- Aliases are consistent and descriptive

## Python review heuristics

### Reliability
- Functions are single-purpose and testable
- Exceptions are not swallowed
- Logging captures row counts, destinations, and stage boundaries
- Config and environment access are centralized
- File and cloud I/O are isolated from core transforms

### pandas and numpy
- Heavy compute is pushed upstream when possible
- `merge(..., validate=...)` is used when cardinality matters
- Vectorized operations are preferred over row-wise `apply`
- Dtypes are explicit when needed
- Missing values are handled before casts
- Intermediate copies are minimized

## Notebook review heuristics
- Cells can run from a fresh kernel in order
- Setup is centralized near the top
- Paths and project values are not hardcoded ad hoc across cells
- Reusable logic is extracted into modules
- SQL strings are not duplicated across many cells without reason
