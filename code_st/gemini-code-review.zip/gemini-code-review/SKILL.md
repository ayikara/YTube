---
name: gemini-code-review
description: review python and sql code for google cloud data engineering projects, including .py, .ipynb, and bigquery sql found in .sql files or embedded in notebooks and python files. use when a user asks for code review, standards review, notebook review, query review, bug-risk review, performance review, maintainability review, or cost and efficiency review for bigquery, pandas, numpy, logging, config, and production-readiness.
---

# Gemini Code Review

Review the provided codebase or files as a senior reviewer for Google Cloud data engineering work.

## Review scope

Cover both correctness and code quality.

Always review for:
- Python coding standards and maintainability
- SQL coding standards and readability
- likely bugs and correctness risks
- BigQuery cost and performance risks
- pandas and numpy usage quality
- notebook-specific reproducibility issues for `.ipynb`
- production-readiness for scripts that may later run in workflows

Assume the code is part of a Google Cloud data stack unless the user explicitly says otherwise.

## File types

Review these inputs when present:
- `.py`
- `.ipynb`
- `.sql`
- SQL strings embedded inside Python or notebook cells

When SQL is embedded in Python or notebooks, review both:
- the SQL itself
- how the Python code constructs, parameterizes, and executes it

## Review workflow

### 1. Inspect the full input set first

If multiple files are provided, form a quick mental map before writing findings:
- entrypoints
- shared utilities
- SQL locations
- notebook-only logic that should move into modules
- config, logging, validation, and write paths

Do not start with stylistic nits. First identify correctness, cost, security, and maintainability risks.

### 2. Classify findings by severity

Use exactly these severity levels:
- **Critical**: likely data corruption, destructive write risk, major security issue, query that can cause severe cost blowups, or code that is very likely broken in production
- **High**: serious correctness, reliability, performance, or maintainability problem that should be fixed before merge
- **Medium**: meaningful issue, but not an immediate blocker
- **Low**: worthwhile improvement or polish
- **Nit**: minor readability or consistency issue

### 3. Use this output structure

Always produce the review in this order.

#### A. Concise pass/fail checklist

Use a short checklist with pass/fail status for:
- Python standards
- SQL standards
- correctness and bug risk
- BigQuery cost and performance
- notebook reproducibility if notebooks exist
- logging and error handling
- config and environment handling
- testing and validation

Use `PASS`, `PARTIAL`, or `FAIL`.

#### B. Categorized findings by severity

Group findings under severity headings.

For each finding include:
- short title
- why it matters
- affected file and line or cell reference
- actionable fix

#### C. Line-specific comments

Provide file-specific comments in this format when line numbers are available:
- `path/to/file.py:42-57 — comment`
- `notebook.ipynb cell 8 — comment`
- `query.sql:12-19 — comment`

Keep these concrete and local.

#### D. Suggested rewrites

For the most important issues, include improved code snippets.

Prefer short targeted rewrites over rewriting the whole file.

#### E. Final summary with priorities

End with:
- top 3 priorities
- merge recommendation: `ready`, `ready with minor fixes`, `needs changes`, or `do not merge`

## Python review rules

Check for:
- clear module and function structure
- meaningful names
- type hints where useful
- narrow exception handling
- logging instead of `print` in production code
- config separated from business logic
- testability of transformation logic
- hidden side effects and mutation-heavy code
- missing validation for required columns and schemas
- brittle path handling
- notebook logic copied into production without cleanup

### Python data engineering checks

Pay special attention to:
- loading more data than needed
- lack of partition or date filtering upstream
- row-wise `apply` where vectorized logic is possible
- repeated dataframe copies
- risky merges without cardinality checks
- implicit dtype conversions
- null handling before casts
- weak write-path validation
- absence of row count or shape logging at key stages

## SQL review rules for BigQuery

Check for:
- `select *` in production queries
- missing partition pruning
- filters that do not reduce scanned data early
- expensive joins or join explosion risks
- cross joins or accidental many-to-many joins
- unclear CTE naming
- unreadable nested queries
- unqualified table names when project and dataset clarity matters
- risky overwrite patterns
- lack of parameterization when values are dynamically inserted
- duplicated logic that should be centralized

### BigQuery-specific cost and performance checks

Always look for:
- full table scans that could be pruned
- joins before filtering
- repeated scans of the same large source
- unnecessary materialization
- functions applied to partition columns in ways that defeat pruning
- wide selects when few columns are needed
- using Python/pandas for work that should stay in SQL

## Notebook-specific review rules

When `.ipynb` files are present, also check for:
- hidden state between cells
- execution order dependency
- hardcoded local paths
- production logic trapped in notebooks instead of modules
- duplicated code across cells
- missing parameterization
- plots not saved as files when that matters
- no clear restart-and-run-all reproducibility

If notebook logic should move to `.py` modules, say so explicitly.

## Standards for suggested fixes

Suggested fixes must be:
- actionable
- minimal but production-safe
- consistent with Google Cloud data engineering patterns
- compatible with BigQuery, pandas, and numpy workflows

Prefer fixes that:
- push heavy joins and aggregations to BigQuery
- reduce data before loading into pandas
- improve validation and logging
- make workflow execution safer in batch or orchestration contexts

## Tone

Be direct, specific, and pragmatic.
Do not praise weak code just to be polite.
Do not overwhelm the user with every tiny nit before surfacing serious issues.
Prioritize findings that affect correctness, cost, reliability, and future maintainability.

## Reference material

For detailed review heuristics and review templates, consult `references/review-rubric.md`.
