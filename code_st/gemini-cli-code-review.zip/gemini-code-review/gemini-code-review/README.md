# Gemini Code Review Project

This project contains a custom Gemini CLI skill designed to review Python, SQL, and Jupyter Notebooks with a focus on Google Cloud data engineering standards.

## Directory Structure

- `.gemini/skills/gemini-code-review/`: Contains the skill logic and reference materials.
  - `SKILL.md`: The core instructions and metadata for the skill.
  - `references/review-rubric.md`: Detailed heuristics used by the skill.
- `samples/`: Example files with intentional issues to test the skill.

## How to Use

### 1. List Available Skills
To confirm that Gemini CLI has detected your skill, run:
```bash
gemini skills list
```
Or, if you are already in an interactive session, type:
```bash
/skills list
```

### 2. Trigger a Code Review
You don't need to "manually" call the skill. Instead, simply ask Gemini to perform a task that matches the skill's description (e.g., "review", "audit", "check standards").

#### Example Commands:
Ask Gemini to review the sample files I've prepared for you:

```bash
# Review a single file
gemini "Please review samples/inefficient_query.sql"

# Review the entire samples directory
gemini "Review the code in the samples/ folder and provide findings ranked by severity"
```

### 3. What to Expect
The skill is programmed to:
1.  Provide a **pass/fail checklist** for various standards.
2.  Categorize findings by **severity** (Critical, High, Medium, Low, Nit).
3.  Provide **line-specific comments**.
4.  Suggest **targeted rewrites**.
5.  Give a **final summary** with top 3 priorities and a merge recommendation.

## Supported Standards

The skill evaluates code against Google Cloud data engineering best practices, specifically:

- **Python**: PEP 8 compliance, vectorized pandas/numpy operations, secure SQL handling, and production-ready logging/error handling.
- **SQL (BigQuery)**: Cost optimization (partition pruning, explicit column selection), join performance, and query readability.
- **Jupyter Notebooks**: Reproducibility (execution order), removal of hardcoded local paths, and transition of logic to modules.

## Testing with Samples
The `samples/` directory contains files specifically designed to trigger the skill's rules:
- `inefficient_query.sql`: Triggers BigQuery cost and performance checks.
- `data_script.py`: Triggers pandas efficiency and SQL injection checks.
- `analysis_notebook.ipynb`: Triggers notebook reproducibility and hardcoded path checks.
