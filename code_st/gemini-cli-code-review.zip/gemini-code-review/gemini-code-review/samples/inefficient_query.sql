-- Issue: SELECT *, no partition filter, expensive JOIN
SELECT *
FROM `google-cloud-project.analytics.events` e
JOIN `google-cloud-project.analytics.users` u ON e.user_id = u.id
WHERE e.event_name = 'purchase'
ORDER BY e.timestamp DESC
