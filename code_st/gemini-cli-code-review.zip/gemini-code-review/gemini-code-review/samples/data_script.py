import pandas as pd
import numpy as np

def process_data(file_path):
    # Issue: Hardcoded path and no error handling
    df = pd.read_csv(file_path)
    
    # Issue: Row-wise apply instead of vectorized operation
    df['price_with_tax'] = df['price'].apply(lambda x: x * 1.1)
    
    # Issue: Print instead of logging
    print(f"Loaded {len(df)} rows")
    
    # Issue: Embedded SQL with string formatting (risk of injection)
    category = "electronics"
    query = f"SELECT item_id, price FROM `prod.inventory` WHERE category = '{category}'"
    
    return df

if __name__ == "__main__":
    process_data("data.csv")
