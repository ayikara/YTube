# CME vs Hyperliquid — S&P 500 comparison pipeline (arch v2.2)

Agentic five-stage pipeline comparing a CME future (ES/MES) against the
Hyperliquid SP-USDC perpetual on liquidity, price divergence, and cross-venue
price/return correlation. Built on synthetic data with a modular ingest layer
so BigQuery can be retrofitted without pipeline changes.

## Run
```
pip install langgraph plotly pandas numpy pyarrow ipywidgets nbformat
jupyter notebook cme_vs_hyperliquid_v2_2.ipynb
```
Run all cells. §6 is a control panel (symbol / date / mode + run button); §5 is
the agent review panel (human-in-loop). Optionally set `ANTHROPIC_API_KEY` for
the LLM narrative layer.

## Structure
```
cme_hl/
  config/           product_specs, data_characteristics, calendar, anomaly_config (JSON)
  ingest/
    base.py         DataSource interface (the abstraction)
    synthetic.py    SyntheticDataSource  <- live now
    bigquery.py     BigQueryDataSource   <- retrofit stub
    loader.py       get_data_source(mode) factory
  quality.py        schema validation, crossed-book, sanity bounds
  transform.py      as-of alignment, notional, roll back-adjustment, CME TWA
  metrics.py        liquidity, cost-to-trade, imbalance, basis, funding, correlation
  agent.py          anomaly detection + classification + LangGraph investigate cycle
  persist.py        parquet + BigQuery output stub (idempotent write policy)
  visualize.py      Plotly figures (correlation headline)
  summarize.py      stakeholder findings summary + optional LLM narrative
  pipeline.py       LangGraph 5-stage graph + agent
cme_vs_hyperliquid_v2_2.ipynb
```

## Retrofitting BigQuery
- Input (deferred): fill in `cme_hl/ingest/bigquery.py`, pass `data_mode="bigquery"`.
- Output (in scope): uncomment the block in `cme_hl/persist.py`.

## Extending to CL / GC
Config entries exist as design-target stubs. Add a loader call for the new
symbols and call `run(pair_id="CRUDE"/"GOLD", ...)`. Decide the commodity
session-window definition (currently NYSE hours by direction).
