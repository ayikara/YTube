"""
Visualize stage (arch v2.2 sec 6.6, 9.2). Plotly figures. Correlation is the
headline stakeholder deliverable; liquidity comparison, basis, imbalance, and
session-bucket (stress) views support the four acceptance targets.
"""
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

C = {"cme": "#2a78d6", "hl": "#eb6834", "corr": "#4a3aa7", "warn": "#e34948",
     "closed": "rgba(137,135,129,0.15)", "roll": "rgba(233,30,99,0.12)",
     "win": "rgba(237,161,0,0.14)"}


def _shade(fig, d, row=1, col=1):
    def runs(mask, color):
        m = mask.to_numpy(); ts = d["ts"].to_numpy()
        inr = False; start = None
        for i in range(len(m)):
            if m[i] and not inr:
                inr, start = True, ts[i]
            elif not m[i] and inr:
                inr = False
                fig.add_vrect(x0=start, x1=ts[i], fillcolor=color, line_width=0, row=row, col=col, layer="below")
        if inr:
            fig.add_vrect(x0=start, x1=ts[-1], fillcolor=color, line_width=0, row=row, col=col, layer="below")
    runs(~d["cme_market_open"].fillna(False), C["closed"])
    runs(d["is_roll_period"], C["roll"])
    runs(d["is_open_window"] | d["is_close_window"], C["win"])


def fig_correlation(d, corr_summary, cme_symbol="ES", hl_symbol="SP-USDC"):
    """Headline: returns scatter + regression, and rolling correlation over time."""
    fig = make_subplots(rows=1, cols=2, column_widths=[0.42, 0.58],
                        subplot_titles=(f"1-min returns: {cme_symbol} vs {hl_symbol}<br>"
                                        f"return ρ={corr_summary['return_corr_pearson']:.3f}, "
                                        f"β={corr_summary['cross_venue_beta']:.3f}",
                                        "Rolling return correlation over time"))
    sub = d.dropna(subset=["cme_ret_1m", "hl_ret_1m"])
    fig.add_trace(go.Scattergl(x=sub["cme_ret_1m"], y=sub["hl_ret_1m"], mode="markers",
                               marker=dict(size=3, color=C["corr"], opacity=0.35),
                               name="minutes"), row=1, col=1)
    if len(sub) > 2:
        b1, b0 = np.polyfit(sub["cme_ret_1m"], sub["hl_ret_1m"], 1)
        xr = np.array([sub["cme_ret_1m"].min(), sub["cme_ret_1m"].max()])
        fig.add_trace(go.Scatter(x=xr, y=b0 + b1 * xr, mode="lines",
                                 line=dict(color=C["warn"], width=2), name="fit"), row=1, col=1)
    fig.add_trace(go.Scatter(x=d["ts"], y=d["rolling_return_corr"], mode="lines",
                             line=dict(color=C["corr"], width=1.3), name="rolling ρ"), row=1, col=2)
    fig.add_hline(y=0, line_color="#999", line_width=1, row=1, col=2)
    _shade(fig, d, row=1, col=2)
    fig.update_xaxes(title_text=f"{cme_symbol} return", row=1, col=1)
    fig.update_yaxes(title_text=f"{hl_symbol} return", row=1, col=1)
    fig.update_yaxes(title_text="ρ", range=[-1.05, 1.05], row=1, col=2)
    fig.update_layout(height=420, template="plotly_white", showlegend=False,
                      margin=dict(t=70, l=50, r=20, b=45))
    return fig


def fig_liquidity(d, cme_symbol="ES"):
    """Spread, band-limited depth, cost-to-trade side by side."""
    fig = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.05,
                        subplot_titles=("Top-of-book spread (points)",
                                        "Depth within \u00b110bps of mid (USD)",
                                        "Cost to trade $1M (bps slippage)"))
    fig.add_trace(go.Scatter(x=d["ts"], y=d["cme_spread"], name=f"{cme_symbol} (CME)",
                             line=dict(color=C["cme"], width=1.2)), row=1, col=1)
    fig.add_trace(go.Scatter(x=d["ts"], y=d["hl_spread"], name="SP-USDC (HL)",
                             line=dict(color=C["hl"], width=1.2)), row=1, col=1)
    fig.add_trace(go.Scatter(x=d["ts"], y=d["cme_depth_band_10bps"], showlegend=False,
                             line=dict(color=C["cme"], width=1.2)), row=2, col=1)
    fig.add_trace(go.Scatter(x=d["ts"], y=d["hl_depth_band_10bps"], showlegend=False,
                             line=dict(color=C["hl"], width=1.2)), row=2, col=1)
    fig.add_trace(go.Scatter(x=d["ts"], y=d["cme_cost_to_trade_1m"], showlegend=False,
                             line=dict(color=C["cme"], width=1.2)), row=3, col=1)
    fig.add_trace(go.Scatter(x=d["ts"], y=d["hl_cost_to_trade_1m"], showlegend=False,
                             line=dict(color=C["hl"], width=1.2)), row=3, col=1)
    for r in (1, 2, 3):
        _shade(fig, d, row=r, col=1)
    fig.update_yaxes(type="log", row=2, col=1)
    fig.update_layout(height=620, template="plotly_white", legend=dict(orientation="h", y=1.06),
                      margin=dict(t=60, l=55, r=20, b=40))
    return fig


def fig_basis(d, cme_symbol="ES"):
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, row_heights=[0.5, 0.5],
                        vertical_spacing=0.07,
                        subplot_titles=("Raw basis: CME mid - HL mid (points, contains carry)",
                                        "Divergence volatility (rolling std of demeaned basis)"))
    fig.add_trace(go.Scatter(x=d["ts"], y=d["raw_basis_points"], name="raw basis",
                             line=dict(color=C["corr"], width=1), fill="tozeroy",
                             fillcolor="rgba(74,58,167,0.08)"), row=1, col=1)
    fig.add_trace(go.Scatter(x=d["ts"], y=d["basis_divergence_vol"], name="divergence vol",
                             line=dict(color=C["warn"], width=1.2)), row=2, col=1)
    _shade(fig, d, row=1, col=1); _shade(fig, d, row=2, col=1)
    fig.update_layout(height=460, template="plotly_white", showlegend=False,
                      margin=dict(t=60, l=55, r=20, b=40))
    return fig


def fig_imbalance(d, cme_symbol="ES"):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=d["ts"], y=d["cme_imbalance"], name=f"{cme_symbol} (CME)",
                             line=dict(color=C["cme"], width=1)))
    fig.add_trace(go.Scatter(x=d["ts"], y=d["hl_imbalance"], name="SP-USDC (HL)",
                             line=dict(color=C["hl"], width=1)))
    fig.add_hline(y=0, line_color="#999", line_width=1)
    _shade(fig, d)
    fig.update_layout(title="Top-of-book order-book imbalance (liquidity quality)",
                      height=340, template="plotly_white", legend=dict(orientation="h", y=1.12),
                      yaxis_title="(bid-ask)/(bid+ask)", margin=dict(t=55, l=55, r=20, b=40))
    return fig


def fig_stress_bars(summary):
    """Liquidity under stress: metrics by session bucket."""
    buckets = summary.index.tolist()
    fig = make_subplots(rows=1, cols=3, subplot_titles=("Avg spread (pts)", "Avg cost to trade (bps)", "Avg return ρ"))
    fig.add_trace(go.Bar(x=buckets, y=summary["avg_cme_spread"], name="CME", marker_color=C["cme"]), row=1, col=1)
    fig.add_trace(go.Bar(x=buckets, y=summary["avg_hl_spread"], name="HL", marker_color=C["hl"]), row=1, col=1)
    fig.add_trace(go.Bar(x=buckets, y=summary["avg_cme_cost_bps"], showlegend=False, marker_color=C["cme"]), row=1, col=2)
    fig.add_trace(go.Bar(x=buckets, y=summary["avg_hl_cost_bps"], showlegend=False, marker_color=C["hl"]), row=1, col=2)
    fig.add_trace(go.Bar(x=buckets, y=summary["avg_return_corr"], showlegend=False, marker_color=C["corr"]), row=1, col=3)
    fig.update_layout(height=380, template="plotly_white", barmode="group",
                      legend=dict(orientation="h", y=1.18), margin=dict(t=70, l=50, r=20, b=60))
    fig.update_xaxes(tickangle=-30)
    return fig
