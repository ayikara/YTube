"""
Data-quality guards (arch v2.2 sec 11.3-11.4). Built now against mock data.
Each guard returns a cleaned frame plus a list of structured issue records that
the anomaly agent later consumes.
"""
import numpy as np
import pandas as pd


def validate_schema(df: pd.DataFrame, required_columns: list, venue: str) -> list:
    missing = [c for c in required_columns if c not in df.columns]
    issues = []
    if missing:
        issues.append({"type": "schema_drift", "venue": venue,
                       "detail": f"missing columns: {missing}", "severity": "fatal"})
    return issues


def guard_crossed_book(df: pd.DataFrame, venue: str) -> tuple:
    """Flag/exclude rows where best bid >= best ask."""
    issues = []
    if "bid_px_1" not in df.columns or "ask_px_1" not in df.columns:
        return df, issues
    crossed = df["bid_px_1"] >= df["ask_px_1"]
    n = int(crossed.sum())
    if n:
        issues.append({"type": "crossed_book", "venue": venue,
                       "detail": f"{n} crossed/locked rows excluded", "severity": "data_quality"})
        df = df.loc[~crossed].copy()
    return df, issues


def guard_price_sanity(df: pd.DataFrame, venue: str, window: int = 50,
                       max_dev_pct: float = 20.0) -> tuple:
    """Flag/exclude zero/negative prices and prints far from a short rolling median."""
    issues = []
    if "bid_px_1" not in df.columns:
        return df, issues
    mid = (df["bid_px_1"] + df["ask_px_1"]) / 2
    nonpos = (df["bid_px_1"] <= 0) | (df["ask_px_1"] <= 0)
    med = mid.rolling(window, min_periods=5, center=True).median()
    dev = (mid - med).abs() / med.replace(0, np.nan) * 100
    outlier = (dev > max_dev_pct).fillna(False)
    bad = nonpos | outlier
    n = int(bad.sum())
    if n:
        issues.append({"type": "bad_price", "venue": venue,
                       "detail": f"{n} zero/negative or >{max_dev_pct}% median-deviating rows excluded",
                       "severity": "data_quality"})
        df = df.loc[~bad].copy()
    return df, issues


def run_all_guards(df: pd.DataFrame, venue: str, required_columns: list) -> tuple:
    issues = []
    issues += validate_schema(df, required_columns, venue)
    if any(i["severity"] == "fatal" for i in issues):
        return df, issues  # don't proceed on schema failure
    df, i1 = guard_crossed_book(df, venue); issues += i1
    df, i2 = guard_price_sanity(df, venue); issues += i2
    return df, issues
