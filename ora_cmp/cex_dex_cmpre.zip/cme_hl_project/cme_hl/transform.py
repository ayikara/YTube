"""
Transform stage (arch v2.2 sec 5). Validates + guards raw input, aligns CME
ticks to the HL 1-minute grid (as-of), computes per-minute CME time-weighted
metrics from the ticks, applies notional, and flags roll periods.
"""
import numpy as np
import pandas as pd

from .quality import run_all_guards


def _cme_closed_mask(ts: pd.Series) -> pd.Series:
    dow = ts.dt.dayofweek
    h = ts.dt.hour + ts.dt.minute / 60
    return ((dow == 5) | ((dow == 4) & (h >= 21)) | ((dow == 6) & (h < 22))
            | (dow.isin([0, 1, 2, 3]) & (h >= 21) & (h < 22)))


def _cme_tick_metrics_per_minute(cme: pd.DataFrame, point_value: float) -> pd.DataFrame:
    """Time-weighted spread & depth per minute from the raw CME ticks (sec 6.3)."""
    c = cme.copy()
    c["ts"] = pd.to_datetime(c["ts_ns"], unit="ns", utc=True).astype("datetime64[ns, UTC]")
    c = c.sort_values("ts")
    c["minute"] = c["ts"].dt.floor("min")
    c["spread"] = c["ask_px_1"] - c["bid_px_1"]
    depth_cols_b = [f"bid_sz_{i}" for i in range(1, 11)]
    depth_cols_a = [f"ask_sz_{i}" for i in range(1, 11)]
    pxb = [f"bid_px_{i}" for i in range(1, 11)]
    pxa = [f"ask_px_{i}" for i in range(1, 11)]
    c["depth_usd"] = (sum(c[pxb[i]] * c[depth_cols_b[i]] for i in range(10))
                      + sum(c[pxa[i]] * c[depth_cols_a[i]] for i in range(10))) * point_value
    # time weight = seconds until next tick within the minute
    c["dt"] = c.groupby("minute")["ts"].shift(-1) - c["ts"]
    c["w"] = c["dt"].dt.total_seconds().fillna(0.5).clip(lower=1e-3)

    def _twa(g):
        w = g["w"].to_numpy()
        return pd.Series({"cme_spread_twa": np.average(g["spread"], weights=w),
                          "cme_depth_twa": np.average(g["depth_usd"], weights=w)})

    twa = c.groupby("minute").apply(_twa, include_groups=False).reset_index()
    twa = twa.rename(columns={"minute": "ts"})
    return twa


def align(hl_raw: pd.DataFrame, cme_raw: pd.DataFrame, hl_spec: dict, cme_spec: dict,
          data_chars: dict) -> tuple:
    """Returns (aligned_df, issues). Aligned df is on the HL minute grid."""
    issues = []
    hl, i_hl = run_all_guards(hl_raw, "HYPERLIQUID",
                              data_chars["HYPERLIQUID"]["required_columns"])
    cme, i_cme = run_all_guards(cme_raw, "CME", data_chars["CME"]["required_columns"])
    issues += i_hl + i_cme
    if any(i["severity"] == "fatal" for i in issues):
        return None, issues

    hl = hl.copy(); cme = cme.copy()
    hl["ts"] = pd.to_datetime(hl["ts_us"], unit="us", utc=True).astype("datetime64[ns, UTC]")
    cme["ts"] = pd.to_datetime(cme["ts_ns"], unit="ns", utc=True).astype("datetime64[ns, UTC]")
    hl = hl.sort_values("ts"); cme = cme.sort_values("ts")

    tol = data_chars["alignment_policy"]["staleness_tolerance_seconds"]
    twa = _cme_tick_metrics_per_minute(cme, cme_spec["point_value"])

    merged = pd.merge_asof(hl, cme, on="ts", direction="backward", suffixes=("_hl", "_cme"))

    last_valid = merged["ts"].where(merged["symbol_cme"].notna()).ffill()
    merged["cme_age_seconds"] = (merged["ts"] - last_valid).dt.total_seconds()
    merged["cme_stale"] = (merged["cme_age_seconds"] > tol).fillna(True)
    merged["cme_market_open"] = ~_cme_closed_mask(merged["ts"])

    cme_fields = [c for c in merged.columns if c.endswith("_cme") and ("px" in c or "sz" in c or c == "open_interest_cme")]
    invalid = (~merged["cme_market_open"]) | merged["cme_stale"]
    merged.loc[invalid, cme_fields] = np.nan

    merged = merged.merge(twa, on="ts", how="left")
    merged.loc[invalid, ["cme_spread_twa", "cme_depth_twa"]] = np.nan
    return merged, issues


def add_prices_and_notional(df: pd.DataFrame, hl_spec: dict, cme_spec: dict) -> pd.DataFrame:
    df = df.copy()
    df["hl_mid"] = (df["bid_px_1_hl"] + df["ask_px_1_hl"]) / 2
    df["hl_spread"] = df["ask_px_1_hl"] - df["bid_px_1_hl"]
    df["cme_mid"] = (df["bid_px_1_cme"] + df["ask_px_1_cme"]) / 2
    df["cme_spread"] = df["ask_px_1_cme"] - df["bid_px_1_cme"]
    df["hl_notional_l1"] = df["hl_mid"] * hl_spec["point_value"]
    df["cme_notional_l1"] = df["cme_mid"] * cme_spec["point_value"]
    return df


def flag_roll(df: pd.DataFrame, calendar: dict) -> pd.DataFrame:
    df = df.copy()
    rs = pd.Timestamp(calendar["demo_window"]["start_utc"]) + pd.Timedelta(
        hours=calendar["demo_window"]["roll_offset_hours"])
    re = rs + pd.Timedelta(hours=calendar["demo_window"]["roll_duration_hours"])
    df["is_roll_period"] = (df["ts"] >= rs) & (df["ts"] < re)
    return df


def ratio_back_adjust(series: pd.Series, roll_mask: pd.Series) -> pd.Series:
    """Ratio back-adjust a continuous series across a roll (sec 5.4). Scales
    pre-roll history by the price ratio at the roll boundary so the joined
    series is continuous. Applied only to continuous (multi-contract) views."""
    s = series.copy()
    if not roll_mask.any():
        return s
    idx = np.where(roll_mask.to_numpy())[0]
    boundary = idx[0]
    if boundary == 0 or boundary >= len(s):
        return s
    pre = s.iloc[boundary - 1]
    post = s.iloc[boundary]
    if pd.notna(pre) and pd.notna(post) and pre != 0:
        ratio = post / pre
        s.iloc[:boundary] = s.iloc[:boundary] * ratio
    return s
