"""
Pipeline orchestration (arch v2.2 sec 7). LangGraph 5-stage substrate with the
anomaly-investigation agent running between Discover and Save. Human-in-loop
escalations are collected in state for the notebook UI to review.

    transform_data -> discover_insights -> investigate (agent)
                   -> save_insights -> visualize -> summarize_key_insights
"""
import json
import os
from typing import Any, TypedDict

from langgraph.graph import StateGraph, END

from .ingest.loader import get_data_source
from . import transform as T
from . import metrics as M
from . import agent as A
from . import persist as P
from . import visualize as V
from . import summarize as S


def load_config(cfg_dir):
    with open(f"{cfg_dir}/product_specs.json") as f: specs = json.load(f)
    with open(f"{cfg_dir}/data_characteristics.json") as f: dc = json.load(f)
    with open(f"{cfg_dir}/calendar.json") as f: cal = json.load(f)
    with open(f"{cfg_dir}/anomaly_config.json") as f: anom = json.load(f)
    return specs, dc, cal, anom


class PipelineState(TypedDict, total=False):
    pair_id: str
    cme_symbol: str
    hl_symbol: str
    start: str
    end: str
    cfg_dir: str
    data_mode: str
    out_dir: str
    specs: dict; dc: dict; cal: dict; anom: dict
    raw_hl: Any; raw_cme: Any
    aligned: Any; issues: list
    metrics: Any; corr: dict; session_summary: Any
    agent_result: dict
    save_result: dict
    figures: dict
    summary: str


def node_transform(s: PipelineState) -> PipelineState:
    specs, dc, cal, anom = load_config(s.get("cfg_dir", "cme_hl/config"))
    src = get_data_source(s.get("data_mode", "mock"), specs, cal)
    hl_spec = specs["products"][s["hl_symbol"]]
    cme_spec = specs["products"][s["cme_symbol"]]
    raw_hl = src.load_hl(s["hl_symbol"], s["start"], s["end"])
    raw_cme = src.load_cme(s["cme_symbol"], s["start"], s["end"])
    aligned, issues = T.align(raw_hl, raw_cme, hl_spec, cme_spec, dc)
    aligned = T.add_prices_and_notional(aligned, hl_spec, cme_spec)
    aligned = T.flag_roll(aligned, cal)
    return {**s, "specs": specs, "dc": dc, "cal": cal, "anom": anom,
            "raw_hl": raw_hl, "raw_cme": raw_cme, "aligned": aligned, "issues": issues}


def node_discover(s: PipelineState) -> PipelineState:
    hl_spec = s["specs"]["products"][s["hl_symbol"]]
    cme_spec = s["specs"]["products"][s["cme_symbol"]]
    d = M.discover(s["aligned"], hl_spec, cme_spec, s["cal"], s["dc"]["metric_params"])
    return {**s, "metrics": d, "corr": M.correlation_summary(d),
            "session_summary": M.session_summary(d)}


def node_investigate(s: PipelineState) -> PipelineState:
    res = A.run_agent(s["metrics"], s["issues"], s["anom"])
    return {**s, "agent_result": res}


def node_save(s: PipelineState) -> PipelineState:
    res = P.save_outputs(s["metrics"], s["agent_result"], s["corr"],
                         s["pair_id"], s["cme_symbol"], out_dir=s.get("out_dir", "outputs_local"))
    return {**s, "save_result": res}


def node_visualize(s: PipelineState) -> PipelineState:
    d = s["metrics"]
    figs = {
        "correlation": V.fig_correlation(d, s["corr"], s["cme_symbol"], s["hl_symbol"]),
        "liquidity": V.fig_liquidity(d, s["cme_symbol"]),
        "basis": V.fig_basis(d, s["cme_symbol"]),
        "imbalance": V.fig_imbalance(d, s["cme_symbol"]),
        "stress": V.fig_stress_bars(s["session_summary"]),
    }
    return {**s, "figures": figs}


def node_summarize(s: PipelineState) -> PipelineState:
    txt = S.build_summary(s["session_summary"], s["corr"], s["agent_result"],
                          s["cme_symbol"], s["hl_symbol"])
    return {**s, "summary": S.maybe_llm_narrative(txt)}


def build_pipeline():
    g = StateGraph(PipelineState)
    g.add_node("transform_data", node_transform)
    g.add_node("discover_insights", node_discover)
    g.add_node("investigate", node_investigate)
    g.add_node("save_insights", node_save)
    g.add_node("visualize", node_visualize)
    g.add_node("summarize_key_insights", node_summarize)
    g.set_entry_point("transform_data")
    g.add_edge("transform_data", "discover_insights")
    g.add_edge("discover_insights", "investigate")
    g.add_edge("investigate", "save_insights")
    g.add_edge("save_insights", "visualize")
    g.add_edge("visualize", "summarize_key_insights")
    g.add_edge("summarize_key_insights", END)
    return g.compile()


def run(pair_id="SP500", cme_symbol="ES", start=None, end=None,
        cfg_dir="cme_hl/config", data_mode="mock", out_dir="outputs_local"):
    specs, dc, cal, anom = load_config(cfg_dir)
    pair = specs["pairs"][pair_id]
    hl_symbol = pair["hl_symbol"]
    start = start or cal["demo_window"]["start_utc"][:10]
    end = end or cal["demo_window"]["end_utc"][:10]
    app = build_pipeline()
    return app.invoke({"pair_id": pair_id, "cme_symbol": cme_symbol, "hl_symbol": hl_symbol,
                       "start": start, "end": end, "cfg_dir": cfg_dir,
                       "data_mode": data_mode, "out_dir": out_dir})
