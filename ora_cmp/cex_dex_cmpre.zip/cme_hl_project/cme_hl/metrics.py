"""
Discover stage (arch v2.2 sec 6). Computes liquidity (spread, band-limited
depth, cost-to-trade), imbalance, basis (raw/demeaned/divergence-vol/delta),
funding, returns + correlation (headline), and session-bucket slicing.
"""
import numpy as np
import pandas as pd

NYSE_OPEN_UTC_H = 13.5
NYSE_CLOSE_UTC_H = 20.0


def _depth_band_and_l10(df: pd.DataFrame, suffix: str, point_value: float, band_bps: float):
    bidpx = [f"bid_px_{i}_{suffix}" for i in range(1, 11)]
    askpx = [f"ask_px_{i}_{suffix}" for i in range(1, 11)]
    bidsz = [f"bid_sz_{i}_{suffix}" for i in range(1, 11)]
    asksz = [f"ask_sz_{i}_{suffix}" for i in range(1, 11)]
    mid = (df[bidpx[0]] + df[askpx[0]]) / 2
    l10 = (sum(df[bidpx[i]] * df[bidsz[i]] for i in range(10))
           + sum(df[askpx[i]] * df[asksz[i]] for i in range(10))) * point_value
    lo = mid * (1 - band_bps / 10000.0)
    hi = mid * (1 + band_bps / 10000.0)
    band = np.zeros(len(df))
    for i in range(10):
        band = band + np.where(df[bidpx[i]] >= lo, df[bidpx[i]] * df[bidsz[i]], 0.0)
        band = band + np.where(df[askpx[i]] <= hi, df[askpx[i]] * df[asksz[i]], 0.0)
    return l10, band * point_value


def _cost_to_trade(df: pd.DataFrame, suffix: str, point_value: float, notional_usd: float):
    """Slippage (bps vs mid) to fill `notional_usd` on the ask side, walking levels."""
    askpx = [f"ask_px_{i}_{suffix}" for i in range(1, 11)]
    asksz = [f"ask_sz_{i}_{suffix}" for i in range(1, 11)]
    bidpx1 = f"bid_px_1_{suffix}"
    mid = (df[bidpx1] + df[askpx[0]]) / 2
    out = np.full(len(df), np.nan)
    px = df[[*askpx]].to_numpy()
    sz = df[[*asksz]].to_numpy()
    midv = mid.to_numpy()
    for r in range(len(df)):
        if np.isnan(px[r, 0]) or np.isnan(midv[r]):
            continue
        remaining = notional_usd
        cost = 0.0
        filled = 0.0
        for lvl in range(10):
            if np.isnan(px[r, lvl]) or np.isnan(sz[r, lvl]):
                break
            lvl_notional = px[r, lvl] * sz[r, lvl] * point_value
            take = min(remaining, lvl_notional)
            qty = take / (px[r, lvl] * point_value) if px[r, lvl] else 0.0
            cost += qty * px[r, lvl]
            filled += qty
            remaining -= take
            if remaining <= 0:
                break
        if filled > 0 and remaining <= 0:
            avg_fill = cost / filled
            out[r] = (avg_fill - midv[r]) / midv[r] * 10000.0  # bps
    return out


def _imbalance(df, suffix):
    b = df[f"bid_sz_1_{suffix}"]; a = df[f"ask_sz_1_{suffix}"]
    denom = (b + a).replace(0, np.nan)
    return (b - a) / denom


def _session_bucket(df, calendar):
    ts = df["ts"]
    h = ts.dt.hour + ts.dt.minute / 60
    ow = calendar["window_definitions"]["open_window_minutes"] / 60
    cw = calendar["window_definitions"]["close_window_minutes"] / 60
    is_open = (h >= NYSE_OPEN_UTC_H) & (h < NYSE_OPEN_UTC_H + ow)
    is_close = (h >= NYSE_CLOSE_UTC_H - cw) & (h < NYSE_CLOSE_UTC_H)
    closed = ~df["cme_market_open"]
    roll = df["is_roll_period"]
    bucket = np.select([closed, roll, is_open, is_close],
                       ["cme_closed", "roll_period", "nyse_open_window", "nyse_close_window"],
                       default="normal")
    return is_open, is_close, bucket


def discover(df, hl_spec, cme_spec, calendar, params):
    d = df.copy()
    band = params["depth_band_bps"]
    notional = params["cost_to_trade_notional_usd"]

    d["hl_depth_usd_l10"], d["hl_depth_band_10bps"] = _depth_band_and_l10(d, "hl", hl_spec["point_value"], band)
    d["cme_depth_usd_l10"], d["cme_depth_band_10bps"] = _depth_band_and_l10(d, "cme", cme_spec["point_value"], band)
    d["hl_cost_to_trade_1m"] = _cost_to_trade(d, "hl", hl_spec["point_value"], notional)
    d["cme_cost_to_trade_1m"] = _cost_to_trade(d, "cme", cme_spec["point_value"], notional)
    d["hl_imbalance"] = _imbalance(d, "hl")
    d["cme_imbalance"] = _imbalance(d, "cme")

    # basis (raw carry-bearing) + divergence measures
    d["raw_basis_points"] = d["cme_mid"] - d["hl_mid"]
    d["raw_basis_usd_cme_pv"] = d["raw_basis_points"] * cme_spec["point_value"]
    d["raw_basis_usd_hl_pv"] = d["raw_basis_points"] * hl_spec["point_value"]
    w = params["divergence_vol_window_minutes"]
    d["basis_demeaned"] = d["raw_basis_points"] - d["raw_basis_points"].rolling(w, min_periods=3).mean()
    d["basis_divergence_vol"] = d["basis_demeaned"].rolling(w, min_periods=3).std()
    d["basis_rms_zero"] = d["raw_basis_points"].pow(2).rolling(w, min_periods=3).mean().pow(0.5)
    d["basis_delta"] = d["raw_basis_points"].diff()

    # funding
    d["funding_cum"] = d["funding_rate_1h"].fillna(0).cumsum()
    d["funding_annualized"] = d["funding_rate_1h"] * 24 * 365

    # returns + correlation (headline)
    d["hl_ret_1m"] = np.log(d["hl_mid"]).diff()
    d["cme_ret_1m"] = np.log(d["cme_mid"]).diff()
    cw = params["rolling_corr_window_minutes"]
    d["rolling_return_corr"] = d["hl_ret_1m"].rolling(cw, min_periods=5).corr(d["cme_ret_1m"])

    is_open, is_close, bucket = _session_bucket(d, calendar)
    d["is_open_window"] = is_open
    d["is_close_window"] = is_close
    d["session_bucket"] = bucket
    return d


def correlation_summary(d: pd.DataFrame) -> dict:
    both = d.dropna(subset=["hl_ret_1m", "cme_ret_1m"])
    level = d.dropna(subset=["hl_mid", "cme_mid"])
    out = {
        "level_corr_pearson": float(level["cme_mid"].corr(level["hl_mid"])) if len(level) > 2 else np.nan,
        "return_corr_pearson": float(both["cme_ret_1m"].corr(both["hl_ret_1m"])) if len(both) > 2 else np.nan,
        "return_corr_spearman": float(both["cme_ret_1m"].corr(both["hl_ret_1m"], method="spearman")) if len(both) > 2 else np.nan,
        "rolling_corr_min": float(d["rolling_return_corr"].min()),
        "rolling_corr_mean": float(d["rolling_return_corr"].mean()),
        "rolling_corr_max": float(d["rolling_return_corr"].max()),
    }
    if len(both) > 2:
        beta = np.polyfit(both["cme_ret_1m"], both["hl_ret_1m"], 1)[0]
        out["cross_venue_beta"] = float(beta)
    else:
        out["cross_venue_beta"] = np.nan
    return out


def session_summary(d: pd.DataFrame) -> pd.DataFrame:
    return d.groupby("session_bucket").agg(
        n_minutes=("ts", "count"),
        avg_hl_spread=("hl_spread", "mean"),
        avg_cme_spread=("cme_spread", "mean"),
        avg_hl_depth_band=("hl_depth_band_10bps", "mean"),
        avg_cme_depth_band=("cme_depth_band_10bps", "mean"),
        avg_hl_cost_bps=("hl_cost_to_trade_1m", "mean"),
        avg_cme_cost_bps=("cme_cost_to_trade_1m", "mean"),
        avg_basis_points=("raw_basis_points", "mean"),
        avg_divergence_vol=("basis_divergence_vol", "mean"),
        avg_return_corr=("rolling_return_corr", "mean"),
        avg_hl_imbalance=("hl_imbalance", "mean"),
        avg_cme_imbalance=("cme_imbalance", "mean"),
    ).round(4)
