"""
Summarize stage (arch v2.2 sec 9.2). Surfaces the four stakeholder acceptance
targets: liquidity comparison, liquidity quality (imbalance), liquidity under
stress, and price correlation. Optional LLM narrative layer.
"""
import os


def build_summary(summary_df, corr, agent_result, cme_symbol="ES", hl_symbol="SP-USDC") -> str:
    L = [f"## Findings summary: {cme_symbol} (CME) vs {hl_symbol} (Hyperliquid)\n"]
    n = summary_df.loc["normal"] if "normal" in summary_df.index else None
    o = summary_df.loc["nyse_open_window"] if "nyse_open_window" in summary_df.index else None
    c = summary_df.loc["nyse_close_window"] if "nyse_close_window" in summary_df.index else None
    r = summary_df.loc["roll_period"] if "roll_period" in summary_df.index else None

    L.append("### 1. Liquidity comparison")
    if n is not None:
        L.append(f"- Normal-conditions spread: CME **{n['avg_cme_spread']:.2f} pts** vs "
                 f"HL **{n['avg_hl_spread']:.2f} pts**.")
        L.append(f"- Depth within \u00b110bps: CME **${n['avg_cme_depth_band']:,.0f}** vs "
                 f"HL **${n['avg_hl_depth_band']:,.0f}**.")
        L.append(f"- Cost to trade $1M: CME **{n['avg_cme_cost_bps']:.2f} bps** vs "
                 f"HL **{n['avg_hl_cost_bps']:.2f} bps**.")

    L.append("\n### 2. Liquidity quality (order-book imbalance)")
    if n is not None:
        L.append(f"- Avg top-of-book imbalance: CME **{n['avg_cme_imbalance']:+.3f}**, "
                 f"HL **{n['avg_hl_imbalance']:+.3f}** (0 = balanced).")

    L.append("\n### 3. Liquidity under stress (high-volatility windows)")
    if o is not None and n is not None:
        L.append(f"- NYSE open: CME spread **{o['avg_cme_spread']:.2f} pts** "
                 f"({o['avg_cme_spread']/n['avg_cme_spread']:.1f}x normal), "
                 f"cost to trade **{o['avg_cme_cost_bps']:.2f} bps**.")
    if c is not None and n is not None:
        L.append(f"- NYSE close: CME spread **{c['avg_cme_spread']:.2f} pts**, "
                 f"divergence vol **{c['avg_divergence_vol']:.3f}**.")
    if r is not None:
        L.append(f"- Roll period: return ρ **{r['avg_return_corr']:.3f}**, "
                 f"basis **{r['avg_basis_points']:.2f} pts**.")

    L.append("\n### 4. Price correlation (headline)")
    L.append(f"- **Return correlation (the meaningful measure): {corr['return_corr_pearson']:.3f}** "
             f"(Spearman {corr['return_corr_spearman']:.3f}); cross-venue beta {corr['cross_venue_beta']:.3f}.")
    L.append(f"- Rolling return ρ ranges {corr['rolling_corr_min']:.3f} to {corr['rolling_corr_max']:.3f} "
             f"(mean {corr['rolling_corr_mean']:.3f}) \u2014 co-movement weakens in the shaded stress windows.")
    L.append(f"- Level (price) correlation is {corr['level_corr_pearson']:.3f}, but note this is "
             f"near-1 by construction for two co-trending series and is *not* a quality signal on its own.")

    L.append("\n### Agent investigation")
    L.append(f"- {len(agent_result['anomalies'])} anomalies detected across "
             f"{agent_result['iterations']} investigation cycles; "
             f"**{len(agent_result['escalations'])} escalated** to human review.")

    L.append("\n*Synthetic mock data built to exercise the pipeline (weekend gaps, a roll window, "
             "open/close volatility). Magnitudes are illustrative.*")
    return "\n".join(L)


def maybe_llm_narrative(text: str) -> str:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return text + "\n\n*(Set ANTHROPIC_API_KEY for an added LLM narrative layer.)*"
    try:
        import anthropic
        client = anthropic.Anthropic()
        resp = client.messages.create(model="claude-sonnet-4-6", max_tokens=350, temperature=0,
            messages=[{"role": "user", "content":
                       "Write a 4-6 sentence executive narrative for a CME stakeholder from this "
                       "findings summary; synthesize, don't repeat every number:\n" + text}])
        return text + "\n\n## Narrative\n" + "".join(b.text for b in resp.content if hasattr(b, "text"))
    except Exception as e:
        return text + f"\n\n*(LLM narrative skipped: {e})*"
