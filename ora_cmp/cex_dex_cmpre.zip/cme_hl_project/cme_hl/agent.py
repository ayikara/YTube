"""
Anomaly-investigation agent (arch v2.2 sec 7.5).

Deterministic rule-based core does detection + classification + action. Wrapped
in a LangGraph graph with a real investigate cycle and conditional routing.
Human-in-loop escalations are collected into a queue that the notebook UI
reviews (the notebook-friendly equivalent of interrupt(); production upgrade
noted in the notebook). Optional LLM narration if ANTHROPIC_API_KEY is set.

Autonomy policy (confirmed, arch v2.2): known effects auto-proceed; data-quality
auto-remedied and escalated only if material; dislocations + ambiguous always
escalate; bias toward over-escalation.
"""
import os
from typing import Any, TypedDict

import numpy as np
import pandas as pd
from langgraph.graph import StateGraph, END


# ----------------------------- detection -----------------------------------

def detect_anomalies(d: pd.DataFrame, quality_issues: list, cfg: dict) -> list:
    th = cfg["detection_thresholds"]
    anomalies = list(quality_issues)  # crossed-book / bad-price / schema issues arrive pre-detected

    open_mask = d["cme_market_open"].fillna(False)
    normal = d[(d["session_bucket"] == "normal")]

    # basis outliers (z-score on demeaned basis, open only)
    b = d.loc[open_mask, "basis_demeaned"].dropna()
    if len(b) > 10:
        z = (b - b.mean()) / (b.std() or 1)
        n_out = int((z.abs() > th["basis_outlier_zscore"]).sum())
        if n_out:
            anomalies.append({"type": "basis_outlier", "severity": "dislocation",
                              "detail": f"{n_out} minutes with |z|>{th['basis_outlier_zscore']} demeaned-basis"})

    # correlation breaks
    corr_break = d["rolling_return_corr"] < th["return_corr_break_threshold"]
    n_cb = int((corr_break & open_mask).sum())
    if n_cb:
        anomalies.append({"type": "corr_break", "severity": "dislocation",
                          "detail": f"{n_cb} minutes with rolling return corr < {th['return_corr_break_threshold']}"})

    # staleness clusters during open hours
    stale_open = (d["cme_stale"] & d["cme_market_open"]).astype(int)
    if stale_open.sum():
        runs = (stale_open.groupby((stale_open != stale_open.shift()).cumsum()).cumcount() + 1) * stale_open
        if runs.max() >= th["staleness_cluster_min_consecutive"]:
            anomalies.append({"type": "stale_cluster", "severity": "data_quality",
                              "detail": f"stale run up to {int(runs.max())} min during open hours"})

    # spread spikes vs normal-median
    if len(normal) and normal["cme_spread"].median() > 0:
        med = normal["cme_spread"].median()
        n_spk = int((d["cme_spread"] > med * th["spread_spike_multiple"]).sum())
        if n_spk:
            anomalies.append({"type": "spread_spike", "severity": "data_quality",
                              "detail": f"{n_spk} minutes with CME spread > {th['spread_spike_multiple']}x normal median"})
    return anomalies


def classify(anomaly: dict, cfg: dict) -> str:
    """Return one of: known_effect, data_quality, dislocation, ambiguous."""
    t = anomaly.get("type")
    sev = anomaly.get("severity")
    if sev == "known_effect" or t in cfg["classification"]["known_effect_buckets"]:
        return "known_effect"
    if t in cfg["classification"]["data_quality_types"] or sev == "data_quality":
        return "data_quality"
    if t in cfg["classification"]["dislocation_types"] or sev == "dislocation":
        return "dislocation"
    return "ambiguous"


def decide_action(classification: str, cfg: dict) -> dict:
    pol = cfg["autonomy_policy"]
    if classification == "known_effect":
        return {"action": "annotate", "escalate": False}
    if classification == "data_quality":
        return {"action": "auto_remedy", "escalate": "if_material"}
    return {"action": "flag_finding", "escalate": True}


# ----------------------------- LangGraph ------------------------------------

class AgentState(TypedDict, total=False):
    metrics: Any
    quality_issues: list
    cfg: dict
    anomalies: list
    pending: list
    decisions: list
    escalations: list
    iteration: int


def node_detect(state: AgentState) -> AgentState:
    a = detect_anomalies(state["metrics"], state.get("quality_issues", []), state["cfg"])
    return {**state, "anomalies": a, "pending": list(a), "decisions": [],
            "escalations": [], "iteration": 0}


def node_investigate(state: AgentState) -> AgentState:
    """Process one pending anomaly per cycle: classify, decide, route."""
    pending = list(state["pending"])
    decisions = list(state["decisions"])
    escalations = list(state["escalations"])
    it = state["iteration"] + 1
    if pending:
        item = pending.pop(0)
        cls = classify(item, state["cfg"])
        act = decide_action(cls, state["cfg"])
        rec = {"anomaly": item, "classification": cls, **act}
        decisions.append(rec)
        if act["escalate"] is True or (act["escalate"] == "if_material"):
            # over-escalation bias: escalate data-quality remedies for human confirmation too
            escalations.append(rec)
    return {**state, "pending": pending, "decisions": decisions,
            "escalations": escalations, "iteration": it}


def route(state: AgentState) -> str:
    if not state["pending"]:
        return "done"
    if state["iteration"] >= state["cfg"]["guardrails"]["max_investigation_iterations"]:
        return "max_iter"
    return "continue"


def node_max_iter(state: AgentState) -> AgentState:
    # escalate everything still pending wholesale (guardrail)
    esc = list(state["escalations"])
    for item in state["pending"]:
        esc.append({"anomaly": item, "classification": "ambiguous",
                    "action": "escalate_on_max_iter", "escalate": True})
    return {**state, "pending": [], "escalations": esc}


def build_agent_graph():
    g = StateGraph(AgentState)
    g.add_node("detect", node_detect)
    g.add_node("investigate", node_investigate)
    g.add_node("max_iter", node_max_iter)
    g.set_entry_point("detect")
    g.add_edge("detect", "investigate")
    g.add_conditional_edges("investigate", route,
                            {"continue": "investigate", "done": END, "max_iter": "max_iter"})
    g.add_edge("max_iter", END)
    return g.compile()


def run_agent(metrics_df, quality_issues, cfg) -> dict:
    app = build_agent_graph()
    final = app.invoke({"metrics": metrics_df, "quality_issues": quality_issues, "cfg": cfg})
    return {"anomalies": final["anomalies"], "decisions": final["decisions"],
            "escalations": final["escalations"], "iterations": final["iteration"]}


def maybe_llm_agent_narrative(agent_result: dict) -> str:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return ""
    try:
        import anthropic
        client = anthropic.Anthropic()
        lines = [f"- [{d['classification']}] {d['anomaly'].get('type')}: {d['anomaly'].get('detail')}"
                 for d in agent_result["decisions"]]
        resp = client.messages.create(
            model="claude-sonnet-4-6", max_tokens=300, temperature=0,
            messages=[{"role": "user", "content":
                       "As a market-structure analyst, write 3-4 sentences summarizing what the "
                       "anomaly investigation found and what the human should focus on:\n" + "\n".join(lines)}])
        return "".join(b.text for b in resp.content if hasattr(b, "text"))
    except Exception as e:
        return f"(LLM narrative skipped: {e})"
