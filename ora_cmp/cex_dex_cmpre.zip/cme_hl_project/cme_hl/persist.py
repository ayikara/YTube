"""
Save stage (arch v2.2 sec 7.3, 11.4). Writes processed output + insights.
Local parquet now; BigQuery OUTPUT persistence is in scope and stubbed with the
idempotent-write policy documented. Raw input load stays out of scope.
"""
import json
import pandas as pd

OUTPUT_COLUMNS = [
    "ts", "hl_mid", "cme_mid", "hl_spread", "cme_spread", "cme_spread_twa", "cme_depth_twa",
    "hl_depth_usd_l10", "cme_depth_usd_l10", "hl_depth_band_10bps", "cme_depth_band_10bps",
    "hl_cost_to_trade_1m", "cme_cost_to_trade_1m", "hl_imbalance", "cme_imbalance",
    "raw_basis_points", "raw_basis_usd_cme_pv", "raw_basis_usd_hl_pv",
    "basis_demeaned", "basis_divergence_vol", "basis_rms_zero", "basis_delta",
    "funding_rate_1h", "funding_cum", "funding_annualized",
    "hl_ret_1m", "cme_ret_1m", "rolling_return_corr",
    "cme_market_open", "cme_stale", "cme_age_seconds",
    "is_roll_period", "is_open_window", "is_close_window", "session_bucket",
]


def save_outputs(metrics_df, agent_result, corr_summary, pair_id, cme_symbol,
                 out_dir="outputs_local") -> dict:
    import os
    os.makedirs(out_dir, exist_ok=True)
    cols = [c for c in OUTPUT_COLUMNS if c in metrics_df.columns]
    base = f"{pair_id}_{cme_symbol}".lower()
    metrics_path = f"{out_dir}/processed_{base}.parquet"
    insights_path = f"{out_dir}/insights_{base}.json"
    metrics_df[cols].to_parquet(metrics_path, index=False)
    with open(insights_path, "w") as f:
        json.dump({"pair": pair_id, "cme_symbol": cme_symbol,
                   "correlation_summary": corr_summary,
                   "agent": {"n_anomalies": len(agent_result["anomalies"]),
                             "n_escalations": len(agent_result["escalations"]),
                             "iterations": agent_result["iterations"],
                             "decisions": agent_result["decisions"],
                             "escalations": agent_result["escalations"]}}, f, indent=2, default=str)

    # --- BigQuery OUTPUT persistence (in scope; stub) ------------------------
    # Idempotent write policy (sec 11.4): WRITE_TRUNCATE per (pair, window)
    # partition, or MERGE on (symbol, ts), so re-runs do not duplicate rows.
    #
    # from google.cloud import bigquery
    # client = bigquery.Client(project=PROJECT)
    # job = client.load_table_from_dataframe(
    #     metrics_df[cols].assign(pair=pair_id, cme_symbol=cme_symbol),
    #     f"{PROJECT}.{DATASET}.processed_metrics",
    #     job_config=bigquery.LoadJobConfig(
    #         write_disposition="WRITE_TRUNCATE",   # per (pair, window) partition
    #         time_partitioning=bigquery.TimePartitioning(field="ts"),
    #         clustering_fields=["cme_symbol"]))
    # job.result()
    # (insights table written similarly, keyed on run_id / (pair, window))
    # -------------------------------------------------------------------------

    return {"rows": len(metrics_df), "metrics_path": metrics_path,
            "insights_path": insights_path,
            "bigquery": "stub (output persistence in scope; see save.py for policy)"}
