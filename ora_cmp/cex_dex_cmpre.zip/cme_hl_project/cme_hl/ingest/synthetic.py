"""
SyntheticDataSource — the live ingest implementation for this build.

Generates mock CME tick data, HL 1-minute snapshots, and CME settlement rows
matching the canonical schema. Deterministic (seeded). Designed so the exact
same DataFrames could later come from BigQuery instead (see bigquery.py).
"""
import numpy as np
import pandas as pd

from .base import DataSource

# NYSE cash session in UTC on the demo summer dates (ET = UTC-4)
NYSE_OPEN_UTC_H = 13.5   # 09:30 ET
NYSE_CLOSE_UTC_H = 20.0  # 16:00 ET


def _is_cme_closed(ts: pd.Timestamp) -> bool:
    dow = ts.dayofweek
    h = ts.hour + ts.minute / 60
    if dow == 5:                      # Saturday
        return True
    if dow == 4 and h >= 21:          # Fri after 16:00 CT
        return True
    if dow == 6 and h < 22:           # Sun before 17:00 CT
        return True
    if dow in (0, 1, 2, 3) and 21 <= h < 22:  # daily maintenance break
        return True
    return False


class SyntheticDataSource(DataSource):
    def __init__(self, product_specs: dict, calendar: dict, seed: int = 42):
        self.specs = product_specs
        self.calendar = calendar
        self.rng = np.random.default_rng(seed)
        self._base_price = {"SPX": 6100.0, "WTI": 78.0, "XAU": 2400.0}

    def _fair_value_path(self, ts_index: pd.DatetimeIndex, underlying: str) -> np.ndarray:
        # Cache by (underlying, first_ts, last_ts, length) so CME and HL, which
        # call this over the same window, share the SAME realized path (they
        # track the same underlying). Without this they'd be independent draws
        # and cross-venue return correlation would be spurious noise.
        key = (underlying, int(ts_index.asi8[0]), int(ts_index.asi8[-1]), len(ts_index))
        if not hasattr(self, "_fv_cache"):
            self._fv_cache = {}
        if key in self._fv_cache:
            return self._fv_cache[key]
        n = len(ts_index)
        base = self._base_price.get(underlying, 100.0)
        vol = np.full(n, base * 1.0e-4)  # ~1bp per-minute baseline, realistic for index
        hours = ts_index.hour + ts_index.minute / 60
        open_mask = (hours >= NYSE_OPEN_UTC_H) & (hours < NYSE_OPEN_UTC_H + 0.25)
        close_mask = (hours >= NYSE_CLOSE_UTC_H - 0.25) & (hours < NYSE_CLOSE_UTC_H)
        vol[open_mask] *= 4.0
        vol[close_mask] *= 3.5
        path = base + np.cumsum(self.rng.normal(0, vol))
        self._fv_cache[key] = path
        return path

    def load_hl(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        spec = self.specs["products"][symbol]
        underlying = spec["underlying"]
        ts = pd.date_range(start, end, freq="1min", tz="UTC", inclusive="left")
        fair = self._fair_value_path(ts, underlying)
        drift = 0.15 * np.sin(np.arange(len(ts)) / 240.0) + self.rng.normal(0, 0.02, len(ts))
        mid = fair + drift * (self._base_price.get(underlying, 100.0) / 6100.0)
        n = len(ts)
        d = {"ts_us": ts.asi8.astype("int64"), "symbol": symbol, "exchange": "Hyperliquid"}
        tick = spec["tick_size"]
        half_spread = np.clip(self.rng.normal(1.5 * tick, 0.5 * tick, n), 0.5 * tick, None)
        for lvl in range(1, 11):
            step = tick * lvl
            d[f"bid_px_{lvl}"] = np.round(mid - half_spread - step, 4)
            d[f"ask_px_{lvl}"] = np.round(mid + half_spread + step, 4)
            base_sz = self.rng.gamma(2.0, 8.0, n) * (1.0 / lvl) * 40.0
            d[f"bid_sz_{lvl}"] = np.round(base_sz, 3)
            d[f"ask_sz_{lvl}"] = np.round(base_sz * self.rng.uniform(0.85, 1.15, n), 3)
        d["funding_rate_1h"] = self.rng.normal(1e-5, 5e-6, n)
        d["open_interest"] = 50000 + np.cumsum(self.rng.normal(0, 15, n))
        return pd.DataFrame(d)

    def load_cme(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        spec = self.specs["products"][symbol]
        underlying = spec["underlying"]
        tick = spec["tick_size"]
        minute_grid = pd.date_range(start, end, freq="1min", tz="UTC", inclusive="left")
        fair = self._fair_value_path(minute_grid, underlying)
        roll_start = pd.Timestamp(start, tz="UTC") + pd.Timedelta(
            hours=self.calendar["demo_window"]["roll_offset_hours"])
        roll_end = roll_start + pd.Timedelta(hours=self.calendar["demo_window"]["roll_duration_hours"])
        base_rate = 6.0 if symbol == "ES" else 4.0
        rows = []
        for t, fv in zip(minute_grid, fair):
            if _is_cme_closed(t):
                continue
            h = t.hour + t.minute / 60
            vol_win = ((h >= NYSE_OPEN_UTC_H) & (h < NYSE_OPEN_UTC_H + 0.25)) or \
                      ((h >= NYSE_CLOSE_UTC_H - 0.25) & (h < NYSE_CLOSE_UTC_H))
            n_ticks = self.rng.poisson(base_rate * (3.0 if vol_win else 1.0))
            if n_ticks == 0:
                continue
            offs = np.sort(self.rng.integers(0, 60_000_000_000, size=n_ticks))
            offs[0] = 0  # guarantee a tick at the minute mark for clean as-of alignment
            widen = 3.0 if vol_win else 1.0
            cme_mid = fv + self.rng.normal(0, 0.02 * widen, n_ticks)
            in_roll = roll_start <= t < roll_end
            oi = 1_200_000 if not in_roll else 1_200_000 * (1 - (t - roll_start) / (roll_end - roll_start))
            for i in range(n_ticks):
                mid = cme_mid[i]
                hs = tick * (0.5 if not vol_win else 1.5)
                row = {"ts_ns": int(t.value + offs[i]), "symbol": symbol,
                       "contract_month": "2026U" if (not in_roll or i % 3) else "2026Z",
                       "exchange": "CME", "volume_cum": int(self.rng.integers(1, 50)),
                       "open_interest": float(oi)}
                for lvl in range(1, 11):
                    step = tick * lvl
                    row[f"bid_px_{lvl}"] = round(mid - hs - step + tick, 4)
                    row[f"ask_px_{lvl}"] = round(mid + hs + step - tick, 4)
                    sz = int(self.rng.integers(1, 200) // lvl + 1)
                    row[f"bid_sz_{lvl}"] = sz
                    row[f"ask_sz_{lvl}"] = int(max(1, sz * self.rng.uniform(0.8, 1.2)))
                rows.append(row)
        return pd.DataFrame(rows)

    def load_cme_settlement(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        spec = self.specs["products"][symbol]
        underlying = spec["underlying"]
        days = pd.date_range(start, end, freq="1D", tz="UTC", inclusive="left")
        base = self._base_price.get(underlying, 100.0)
        rows = []
        for i, d in enumerate(days):
            if d.dayofweek == 5:
                continue
            rows.append({"settle_date": d.date().isoformat(), "symbol": symbol,
                         "contract_month": "2026U",
                         "settlement_price": round(base + self.rng.normal(0, 2) + 0.3 * i, 4)})
        return pd.DataFrame(rows)
