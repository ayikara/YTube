"""
BigQueryDataSource — RETROFIT STUB (arch v2.2 sec 4.1, 7.3).

Loading raw exchange *input* from BigQuery is out of scope for the current
build; input is synthetic. This class documents the exact shape of the future
retrofit so that switching `mode="bigquery"` becomes a drop-in with no
downstream pipeline changes. Fill in the query bodies and remove the
NotImplementedError raises when live access is available.
"""
import pandas as pd

from .base import DataSource


class BigQueryDataSource(DataSource):
    def __init__(self, product_specs: dict, calendar: dict, project: str = None,
                 dataset: str = None):
        self.specs = product_specs
        self.calendar = calendar
        self.project = project
        self.dataset = dataset
        # Retrofit: self._client = bigquery.Client(project=project)

    def _q(self, table: str, symbol: str, ts_col: str, start: str, end: str) -> str:
        # Scope by partition (date) and cluster (symbol) to control cost (sec 8).
        return (f"SELECT * FROM `{self.project}.{self.dataset}.{table}` "
                f"WHERE symbol = @symbol "
                f"AND {ts_col} BETWEEN @start AND @end")

    def load_cme(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        raise NotImplementedError(
            "Retrofit: run self._client.query(self._q('cme_l2_book', symbol, 'ts_ns', "
            "start, end), job_config=...).to_dataframe(). Must return the canonical "
            "CME schema (config/data_characteristics.json).")

    def load_hl(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        raise NotImplementedError(
            "Retrofit: query hl_l2_book with ts_us. Must return the canonical HL schema.")

    def load_cme_settlement(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        raise NotImplementedError(
            "Retrofit: query cme_settlement (settle_date, symbol, contract_month, "
            "settlement_price). Table is available in BigQuery per arch v2.2.")

    def load_spot(self, underlying: str, start: str, end: str) -> pd.DataFrame:
        raise NotImplementedError("Mode B / spot data gated on availability.")
