"""
DataLoader factory — selects the ingest implementation by mode.
The pipeline only ever talks to this, never to a concrete source directly.
"""
from .synthetic import SyntheticDataSource
from .bigquery import BigQueryDataSource


def get_data_source(mode: str, product_specs: dict, calendar: dict, **kwargs):
    mode = (mode or "mock").lower()
    if mode in ("mock", "synthetic"):
        return SyntheticDataSource(product_specs, calendar, seed=kwargs.get("seed", 42))
    if mode == "bigquery":
        return BigQueryDataSource(product_specs, calendar,
                                  project=kwargs.get("project"), dataset=kwargs.get("dataset"))
    raise ValueError(f"Unknown data_mode: {mode!r}. Use 'mock' or 'bigquery'.")
