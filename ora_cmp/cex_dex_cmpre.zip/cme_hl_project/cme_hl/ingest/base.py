"""
Ingest abstraction (arch v2.2 sec 7.3).

`DataSource` is the single interface the pipeline depends on. Today the only
live implementation is `SyntheticDataSource`. `BigQueryDataSource` is a
documented stub; retrofitting live BigQuery input is a matter of filling in its
methods and selecting mode="bigquery" — no downstream pipeline code changes.
"""
from abc import ABC, abstractmethod
import pandas as pd


class DataSource(ABC):
    """Every method returns a pandas DataFrame matching the schema documented in
    config/data_characteristics.json. Timestamp columns: CME `ts_ns` (int64 ns),
    HL `ts_us` (int64 us)."""

    @abstractmethod
    def load_cme(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        """CME tick-by-tick L1-L10 book for one symbol over [start, end)."""

    @abstractmethod
    def load_hl(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        """Hyperliquid 1-minute L1-L10 snapshots for one symbol over [start, end)."""

    @abstractmethod
    def load_cme_settlement(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        """CME daily settlement prices per contract month. Available, but the
        carry analysis that consumes it is deferred to the with-spot redo."""

    def load_spot(self, underlying: str, start: str, end: str) -> pd.DataFrame:
        """Spot/index reference. Mode B only; not available now.
        Default raises to make the gating explicit."""
        raise NotImplementedError(
            "Spot data is not available yet; Mode B (with-spot carry attribution) "
            "is gated on this. See arch v2.2 sec 5.5."
        )
