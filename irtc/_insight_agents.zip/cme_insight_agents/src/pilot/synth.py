"""Synthetic data generator for tests and demos.

Writes events, 50 ms and 200 ms samples, and output records in the schema of the Technical
Requirements, as hive-partitioned Parquet, plus a split manifest. It can inject faults for the
Integrity agent to find.

The output records are generated so that their probabilities are correlated with FUTURE price
moves. That is a deliberate test fixture: it gives the Evaluation agent something to measure.
It is not evidence about any real model or market.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from pilot.config import NS_PER_SECOND, PilotConfig, day_start_ns, load_config
from pilot.io import write_partition

LEVELS = range(1, 11)
MS = 1_000_000
BASE_PRICE = {"ES": 5600.0, "CL": 72.5}
EDGE = 2.2  # how strongly the synthetic probabilities lean toward the realized future move


@dataclass
class Fault:
    """A fault to inject: kind is one of seq_gap, stale, crossed, bad_value, degraded.
    `at_s` is seconds after the first grid time; `duration_s` is how long it lasts."""

    kind: str
    at_s: float
    duration_s: float


@dataclass
class DayData:
    events: pd.DataFrame
    samples: pd.DataFrame
    outputs: pd.DataFrame
    expected: dict[str, list[tuple[int, int]]] = field(default_factory=dict)


def _softmax(logits: np.ndarray) -> np.ndarray:
    e = np.exp(logits - logits.max(axis=1, keepdims=True))
    return e / e.sum(axis=1, keepdims=True)


def _dir_probs(rng: np.random.Generator, d: np.ndarray) -> np.ndarray:
    logits = np.zeros((len(d), 3))
    logits[:, 1] = 1.0
    logits[:, 2] += EDGE * (d > 0)
    logits[:, 0] += EDGE * (d < 0)
    logits[:, 1] += EDGE * (d == 0)
    logits += rng.normal(0, 0.6, logits.shape)
    return _softmax(logits)


def _future_diff(x: np.ndarray, h: int) -> np.ndarray:
    out = np.zeros_like(x)
    out[:-h] = x[h:] - x[:-h]
    return out


def make_day(
    symbol: str,
    date: str,
    tick: float,
    seed: int,
    minutes: int = 5,
    events_per_sec: int = 40,
    base: float | None = None,
    faults: list[Fault] | None = None,
    stale_ms: int = 5000,
) -> DayData:
    """Generate one symbol-day. `expected` maps reason names to the open time intervals in
    which samples are expected to be flagged, so tests can check the agent independently."""
    rng = np.random.default_rng(seed)
    n = minutes * 60 * 20
    t0 = day_start_ns(date) + 14 * 3600 * NS_PER_SECOND
    grid = t0 + (np.arange(n, dtype=np.int64) + 1) * 50 * MS
    base_ticks = (base or BASE_PRICE.get(symbol, 100.0)) / tick

    # book
    p = base_ticks + np.cumsum(rng.normal(0, 0.35, n))
    spread = np.where(rng.random(n) < 0.2, 2, 1).astype(np.int64)
    bid1 = np.floor(p).astype(np.int64)
    ask1 = bid1 + spread
    mid = bid1 + spread / 2.0
    cols: dict[str, np.ndarray] = {}
    for i in LEVELS:
        cols[f"bid_px_{i}"] = bid1 - (i - 1)
        cols[f"ask_px_{i}"] = ask1 + (i - 1)
        cols[f"bid_sz_{i}"] = rng.integers(5, 60, n)
        cols[f"ask_sz_{i}"] = rng.integers(5, 60, n)

    # events (price-level feed): a snapshot, then contiguous sequence numbers
    n_ev = int(minutes * 60 * events_per_sec)
    ts = np.concatenate(([t0], np.sort(rng.integers(t0, t0 + n * 50 * MS, n_ev))))
    action = np.concatenate(
        (
            ["snapshot"],
            rng.choice(["add", "cancel", "modify", "trade"], n_ev, p=[0.4, 0.3, 0.1, 0.2]),
        )
    ).astype(object)
    side = rng.choice(["bid", "ask"], n_ev + 1).astype(object)
    near = np.searchsorted(grid, ts).clip(0, n - 1)
    price = (mid[near] + rng.integers(-5, 6, n_ev + 1)).astype(np.int64)
    size = rng.integers(1, 30, n_ev + 1)
    expected: dict[str, list[tuple[int, int]]] = {}
    stale_ns = stale_ms * MS
    faults = faults or []
    for f in faults:
        if f.at_s < 0 or f.at_s + f.duration_s >= minutes * 60:
            raise ValueError(
                f"fault {f.kind} at {f.at_s}s for {f.duration_s}s does not fit in a "
                f"{minutes}-minute day; use more --minutes or earlier faults"
            )

    keep = np.ones(len(ts), dtype=bool)
    for f in faults:
        if f.kind == "stale":
            a = t0 + int(f.at_s * NS_PER_SECOND)
            b = a + int(f.duration_s * NS_PER_SECOND)
            keep &= ~((ts > a) & (ts < b))
            before = ts[ts <= a].max()
            after = ts[(ts >= b) & keep].min()
            expected.setdefault("STALE", []).append((int(before) + stale_ns, int(after)))
    ts, action, side, price, size = ts[keep], action[keep], side[keep], price[keep], size[keep]
    seq = 1000 + np.arange(len(ts), dtype=np.int64)
    for f in faults:
        if f.kind == "seq_gap":
            a = t0 + int(f.at_s * NS_PER_SECOND)
            b = a + int(f.duration_s * NS_PER_SECOND)
            i = int(np.searchsorted(ts, a, side="right")) - 1
            j = int(np.searchsorted(ts, b, side="left"))
            action[j] = "reset"
            seq[i + 1 :] += 7
            expected.setdefault("SEQ_GAP", []).append((int(ts[i]), int(ts[j])))
    events = pd.DataFrame(
        {
            "ts_event": ts,
            "seq": seq,
            "action": action,
            "side": side,
            "price_tick": price,
            "size": size,
            "order_id": pd.array([pd.NA] * len(ts), dtype="Int64"),
        }
    )

    # per-sample counts and bars
    n_add, n_cancel, n_trade = rng.poisson(1.0, n), rng.poisson(0.7, n), rng.poisson(0.3, n)
    mid_open = np.concatenate(([mid[0]], mid[:-1]))
    samples = pd.DataFrame({"ts_grid": grid, "channel_ms": np.int32(50)})
    for k, v in cols.items():
        samples[k] = v
    empty = rng.random(n) < 0.03  # an empty ask level 10 (null price and size)
    samples["ask_px_10"] = pd.array(np.where(empty, -1, cols["ask_px_10"]), dtype="Int64")
    samples["ask_sz_10"] = pd.array(np.where(empty, -1, cols["ask_sz_10"]), dtype="Int64")
    samples.loc[empty, ["ask_px_10", "ask_sz_10"]] = pd.NA
    samples["n_add"] = n_add.astype(np.int32)
    samples["n_cancel"] = n_cancel.astype(np.int32)
    samples["n_trade"] = n_trade.astype(np.int32)
    samples["trade_vol_buy"] = (n_trade * rng.integers(1, 10, n)).astype(np.int64)
    samples["trade_vol_sell"] = (n_trade * rng.integers(1, 10, n)).astype(np.int64)
    samples["mid_open"] = mid_open
    samples["mid_high"] = np.maximum(mid_open, mid)
    samples["mid_low"] = np.minimum(mid_open, mid)
    samples["mid_close"] = mid
    samples["book_valid"] = True
    samples["n_unapplied"] = np.int32(0)

    # outputs from the clean book, before faults
    outputs = _make_outputs(rng, grid, cols, bid1, ask1, mid, spread, ts)

    # sample-level faults
    invalid = np.zeros(n, dtype=bool)
    degraded = np.zeros(n, dtype=bool)
    for f in faults:
        a, b = t0 + int(f.at_s * NS_PER_SECOND), t0 + int((f.at_s + f.duration_s) * NS_PER_SECOND)
        win = (grid >= a) & (grid < b)
        if f.kind == "crossed":
            samples.loc[win, "bid_px_1"] = samples.loc[win, "ask_px_1"]
            invalid |= win
            expected.setdefault("CROSSED", []).append(
                (int(grid[win].min()) - 1, int(grid[win].max()) + 1)
            )
        elif f.kind == "bad_value":
            samples.loc[win, "bid_sz_4"] = -5
            invalid |= win
            expected.setdefault("BAD_VALUE", []).append(
                (int(grid[win].min()) - 1, int(grid[win].max()) + 1)
            )
        elif f.kind == "degraded":
            samples.loc[win, "n_unapplied"] = 1
            degraded |= win
            expected.setdefault("DEGRADED", []).append(
                (int(grid[win].min()) - 1, int(grid[win].max()) + 1)
            )
    book_invalid = invalid.copy()
    for name in ("SEQ_GAP", "STALE"):
        for a, b in expected.get(name, []):
            book_invalid |= (grid > a) & (grid < b)
    invalid = book_invalid
    # the sampler marks gapped, stale and crossed books invalid; bad values it does not see
    sampler_invalid = book_invalid.copy()
    for a, b in expected.get("BAD_VALUE", []):
        sampler_invalid &= ~((grid > a) & (grid < b))
    samples["book_valid"] = ~sampler_invalid
    derived = [
        c
        for c in outputs.columns
        if c
        not in (
            "ts_grid",
            "channel_ms",
            "model_version",
            "quality_flag",
            "ts_event_max",
            "ts_publish",
        )
    ]
    outputs.loc[invalid, derived] = np.nan
    outputs["quality_flag"] = np.where(invalid, 2, np.where(degraded, 1, 0)).astype(np.int8)

    # 200 ms rows: every fourth 50 ms row, with the interval's counts and bar summed
    s200 = samples.iloc[3::4].copy()
    s200["channel_ms"] = np.int32(200)
    m = (n // 4) * 4
    for c in ("n_add", "n_cancel", "n_trade", "trade_vol_buy", "trade_vol_sell", "n_unapplied"):
        s200[c] = samples[c].to_numpy()[:m].reshape(-1, 4).sum(axis=1)
    s200["mid_open"] = samples["mid_open"].to_numpy()[:m:4]
    s200["mid_high"] = samples["mid_high"].to_numpy()[:m].reshape(-1, 4).max(axis=1)
    s200["mid_low"] = samples["mid_low"].to_numpy()[:m].reshape(-1, 4).min(axis=1)
    s200["book_valid"] = samples["book_valid"].to_numpy()[:m].reshape(-1, 4).all(axis=1)
    o200 = outputs.iloc[3::4].copy()
    o200["channel_ms"] = np.int32(200)
    return DayData(
        events=events,
        samples=pd.concat([samples, s200], ignore_index=True),
        outputs=pd.concat([outputs, o200], ignore_index=True),
        expected=expected,
    )


def _make_outputs(
    rng: np.random.Generator,
    grid: np.ndarray,
    cols: dict[str, np.ndarray],
    bid1: np.ndarray,
    ask1: np.ndarray,
    mid: np.ndarray,
    spread: np.ndarray,
    ev_ts: np.ndarray,
) -> pd.DataFrame:
    n = len(grid)
    bs = np.column_stack([cols[f"bid_sz_{i}"] for i in LEVELS]).astype(float)
    az = np.column_stack([cols[f"ask_sz_{i}"] for i in LEVELS]).astype(float)

    def imb(k: int) -> np.ndarray:
        b, a = bs[:, :k].sum(axis=1), az[:, :k].sum(axis=1)
        return (b - a) / (b + a)

    qb, qa = bs[:, 0], az[:, 0]
    micro = (bid1 * qa + ask1 * qb) / (qa + qb)
    pb, pa = np.concatenate(([bid1[0]], bid1[:-1])), np.concatenate(([ask1[0]], ask1[:-1]))
    pqb, pqa = np.concatenate(([qb[0]], qb[:-1])), np.concatenate(([qa[0]], qa[:-1]))
    ofi = (bid1 >= pb) * qb - (bid1 <= pb) * pqb - ((ask1 <= pa) * qa - (ask1 >= pa) * pqa)
    dm2 = np.concatenate(([0.0], np.diff(mid) ** 2))
    c = np.concatenate(([0.0], np.cumsum(dm2)))
    idx = np.arange(1, n + 1)
    rv = np.sqrt(c[idx] - c[np.maximum(idx - 100, 0)])
    sizes = np.hstack([bs, az])
    share = sizes / sizes.sum(axis=1, keepdims=True)
    depth_h = -(share * np.log(share)).sum(axis=1) / np.log(20)
    p200 = _dir_probs(rng, _future_diff(mid, 4))
    p1000 = _dir_probs(rng, _future_diff(mid, 20))
    widen = 1 / (
        1
        + np.exp(
            -(-1.2 + 1.5 * (_future_diff(spread.astype(float), 4) > 0) + rng.normal(0, 0.5, n))
        )
    )
    ent = -(p200 * np.log(p200)).sum(axis=1) / np.log(3)
    last = np.searchsorted(ev_ts, grid, side="right") - 1
    return pd.DataFrame(
        {
            "ts_grid": grid,
            "channel_ms": np.int32(50),
            "microprice": micro,
            "spread_ticks": spread.astype(float),
            "imbalance_l1": imb(1),
            "imbalance_l3": imb(3),
            "imbalance_l10": imb(10),
            "ofi": ofi,
            "rv_short": rv,
            "depth_entropy": depth_h,
            "flow_entropy": rng.uniform(0.6, 1.0, n),
            "p_down_200": p200[:, 0],
            "p_flat_200": p200[:, 1],
            "p_up_200": p200[:, 2],
            "p_down_1000": p1000[:, 0],
            "p_flat_1000": p1000[:, 1],
            "p_up_1000": p1000[:, 2],
            "p_spread_widen": widen,
            "pred_entropy": ent,
            "model_version": "synthetic-0.1",
            "quality_flag": np.zeros(n, dtype=np.int8),
            "ts_event_max": ev_ts[np.maximum(last, 0)],
            "ts_publish": grid + 2 * MS,
        }
    )


def dates_from(start: str, days: int) -> list[str]:
    d0 = datetime.strptime(start, "%Y-%m-%d")
    return [(d0 + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days)]


def generate(
    cfg: PilotConfig,
    dates: list[str],
    minutes: int = 5,
    seed: int = 7,
    faults: dict[tuple[str, str], list[Fault]] | None = None,
    test_days: int = 2,
) -> dict[tuple[str, str], DayData]:
    """Write synthetic data for every configured symbol and date. `faults` maps
    (symbol, date) to the faults to inject. Returns the generated days."""
    faults = faults or {}
    out: dict[tuple[str, str], DayData] = {}
    for si, inst in enumerate(cfg.instruments):
        for di, date in enumerate(dates):
            day = make_day(
                inst.symbol,
                date,
                inst.tick_size,
                seed=seed * 1000 + si * 100 + di,
                minutes=minutes,
                faults=faults.get((inst.symbol, date)),
                stale_ms=cfg.stale_ms_for(inst.symbol),
            )
            write_partition(cfg.data_root / "events", inst.symbol, date, day.events)
            write_partition(cfg.data_root / "samples", inst.symbol, date, day.samples)
            write_partition(cfg.outputs_root, inst.symbol, date, day.outputs)
            out[(inst.symbol, date)] = day
    manifest = {
        "model_version": "synthetic-0.1",
        "train_days": dates[: max(0, len(dates) - test_days - 1)],
        "validation_days": dates[max(0, len(dates) - test_days - 1) : len(dates) - test_days],
        "test_days": dates[len(dates) - test_days :],
    }
    path = cfg.split_manifest_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Generate synthetic pilot data.")
    ap.add_argument("--config", default="config/pilot.yaml")
    ap.add_argument("--start", default="2026-09-28")
    ap.add_argument("--days", type=int, default=6)
    ap.add_argument("--minutes", type=int, default=5)
    ap.add_argument("--test-days", type=int, default=2)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--faults", choices=["none", "demo"], default="demo")
    args = ap.parse_args(argv)
    if args.faults == "demo" and args.minutes < 4:
        ap.error("--faults demo needs --minutes 4 or more (the demo faults run up to 222 s)")
    cfg = load_config(args.config)
    dates = dates_from(args.start, args.days)
    faults = {}
    if args.faults == "demo":
        faults[(cfg.symbols[0], dates[0])] = [
            Fault("seq_gap", 60, 3),
            Fault("stale", 120, 8),
            Fault("crossed", 180, 2),
            Fault("bad_value", 200, 1),
            Fault("degraded", 220, 2),
        ]
        print(f"injected demo faults into {cfg.symbols[0]} on {dates[0]}")
    generate(cfg, dates, args.minutes, args.seed, faults, args.test_days)
    test = dates[-args.test_days :]
    print(f"wrote {len(dates)} days for {', '.join(cfg.symbols)}; test days: {test}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
