"""CME Insight Feed pilot: integrity and evaluation agents."""

__version__ = "0.1.0"
