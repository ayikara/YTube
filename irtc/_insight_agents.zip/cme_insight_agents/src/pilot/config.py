"""Configuration loading for the pilot agents."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import yaml
from pydantic import BaseModel, Field, field_validator

NS_PER_SECOND = 1_000_000_000
NS_PER_DAY = 24 * 3600 * NS_PER_SECOND


class Instrument(BaseModel):
    symbol: str
    tick_size: float


class Paths(BaseModel):
    data: str = "data"
    outputs: str = "data/outputs"
    artifacts: str = "artifacts"
    split_manifest: str = "artifacts/models/current/split.json"


class AgentsConfig(BaseModel):
    stale_ms: int = 5000
    stale_ms_overrides: dict[str, int] = Field(default_factory=dict)
    trading_hours: dict[str, list[list[str]]] = Field(default_factory=dict)
    cost_ticks: float = 0.5
    latency_steps: int = 1
    bootstrap_resamples: int = 1000
    causality_days: int = 3
    causality_cuts: int = 20
    sandbox_timeout_s: int = 60
    sandbox_memory_mb: int = 4096
    require_network_isolation: bool = True
    seed: int = 42

    @field_validator("latency_steps")
    @classmethod
    def _latency_non_negative(cls, v: int) -> int:
        if v < 0:
            raise ValueError("latency_steps must be >= 0")
        return v


class PilotConfig(BaseModel):
    instruments: list[Instrument]
    channels_ms: list[int] = Field(default_factory=lambda: [50, 200])
    book_depth: int = 10
    seed: int = 42
    paths: Paths = Field(default_factory=Paths)
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    root: Path = Path(".")

    def resolve(self, p: str) -> Path:
        path = Path(p)
        return path if path.is_absolute() else self.root / path

    @property
    def data_root(self) -> Path:
        return self.resolve(self.paths.data)

    @property
    def outputs_root(self) -> Path:
        return self.resolve(self.paths.outputs)

    @property
    def artifacts_root(self) -> Path:
        return self.resolve(self.paths.artifacts)

    @property
    def agents_dir(self) -> Path:
        return self.artifacts_root / "agents"

    @property
    def split_manifest_path(self) -> Path:
        return self.resolve(self.paths.split_manifest)

    @property
    def symbols(self) -> list[str]:
        return [i.symbol for i in self.instruments]

    def stale_ms_for(self, symbol: str) -> int:
        return self.agents.stale_ms_overrides.get(symbol, self.agents.stale_ms)


def load_config(path: str | Path, root: str | Path | None = None) -> PilotConfig:
    """Load a YAML config. Relative paths resolve against `root`, which defaults to the
    parent of the directory that holds the config file (the project root)."""
    p = Path(path).resolve()
    raw = yaml.safe_load(p.read_text())
    cfg = PilotConfig(**raw)
    cfg.root = Path(root).resolve() if root else p.parent.parent
    return cfg


def config_hash(cfg: PilotConfig) -> str:
    payload = json.dumps(cfg.model_dump(mode="json", exclude={"root"}), sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()[:16]


def day_start_ns(date: str) -> int:
    """Nanoseconds since the Unix epoch at 00:00 UTC on `date` (YYYY-MM-DD)."""
    d = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=UTC)
    return int(d.timestamp()) * NS_PER_SECOND


def _hhmm_ns(s: str) -> int:
    hh, mm = s.split(":")
    return (int(hh) * 60 + int(mm)) * 60 * NS_PER_SECOND


def sessions_ns(cfg: PilotConfig, symbol: str, date: str) -> list[tuple[int, int]]:
    """Trading sessions for `symbol` on `date` as (start_ns, end_ns) pairs in UTC.
    An instrument with no configured hours is treated as open all day."""
    d0 = day_start_ns(date)
    spec = cfg.agents.trading_hours.get(symbol)
    if not spec:
        return [(d0, d0 + NS_PER_DAY)]
    out = []
    for start, end in spec:
        s, e = d0 + _hhmm_ns(start), d0 + _hhmm_ns(end)
        if e <= s:
            e += NS_PER_DAY
        out.append((s, e))
    return sorted(out)


def iso_utc(ns: int) -> str:
    """ISO 8601 UTC string with millisecond precision for an epoch-nanosecond value."""
    dt = datetime.fromtimestamp(0, UTC) + timedelta(microseconds=ns // 1000)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"
