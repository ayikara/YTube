"""Parquet input and output helpers for hive-partitioned datasets (symbol=.../date=...)."""

from __future__ import annotations

import hashlib
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.dataset as ds
import pyarrow.parquet as pq

_PARTITIONING = ds.partitioning(
    pa.schema([("symbol", pa.string()), ("date", pa.string())]), flavor="hive"
)


def _dataset(base: Path) -> ds.Dataset | None:
    if not base.exists():
        return None
    return ds.dataset(base, format="parquet", partitioning=_PARTITIONING)


def read_partition(
    base: Path,
    symbol: str,
    date: str,
    columns: list[str] | None = None,
    channel_ms: int | None = None,
) -> pd.DataFrame | None:
    """Read one symbol-day from a partitioned dataset. Returns None if the partition is
    missing. Columns not present in the files are skipped silently; `symbol` and `date` are
    available as partition columns."""
    dataset = _dataset(base)
    if dataset is None:
        return None
    day_filter = (ds.field("symbol") == symbol) & (ds.field("date") == date)
    if not list(dataset.get_fragments(filter=day_filter)):
        return None
    flt = day_filter
    if channel_ms is not None:
        flt = flt & (ds.field("channel_ms") == channel_ms)
    if columns is not None:
        have = set(dataset.schema.names)
        columns = [c for c in columns if c in have]
    return dataset.to_table(columns=columns, filter=flt).to_pandas()


def partition_dir(base: Path, symbol: str, date: str) -> Path:
    return base / f"symbol={symbol}" / f"date={date}"


def write_partition(
    base: Path, symbol: str, date: str, df: pd.DataFrame, filename: str = "part-0.parquet"
) -> Path:
    """Write one symbol-day. The partition keys are encoded in the path, not in the file."""
    d = partition_dir(base, symbol, date)
    d.mkdir(parents=True, exist_ok=True)
    path = d / filename
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), path)
    return path


def partition_files(base: Path, symbol: str, date: str) -> list[Path]:
    d = partition_dir(base, symbol, date)
    return sorted(d.glob("*.parquet")) if d.exists() else []


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()
