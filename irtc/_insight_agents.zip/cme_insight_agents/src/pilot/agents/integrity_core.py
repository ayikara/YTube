"""Vectorized integrity checks. All times are int64 nanoseconds (UTC).

Reason codes are bit flags so one sample can carry several at once. A sample's quality flag
is 2 (invalid) if any of SEQ_GAP, CROSSED, STALE or BAD_VALUE applies, 1 (degraded) if only
DEGRADED applies, and 0 otherwise.
"""

from __future__ import annotations

import numpy as np

SEQ_GAP, CROSSED, STALE, BAD_VALUE, DEGRADED = 1, 2, 4, 8, 16
CODE_NAMES = {
    SEQ_GAP: "SEQ_GAP",
    CROSSED: "CROSSED",
    STALE: "STALE",
    BAD_VALUE: "BAD_VALUE",
    DEGRADED: "DEGRADED",
}
INVALID_BITS = SEQ_GAP | CROSSED | STALE | BAD_VALUE


def mark(reasons: np.ndarray, grid_ts: np.ndarray, start: int, end: int, bit: int) -> None:
    """Flag samples with start < grid_ts < end. `grid_ts` is sorted int64 ns."""
    i0 = np.searchsorted(grid_ts, start, side="right")
    i1 = np.searchsorted(grid_ts, end, side="left")
    if i1 > i0:
        reasons[i0:i1] |= bit


def to_flag(reasons: np.ndarray) -> np.ndarray:
    flag = np.zeros(len(reasons), dtype=np.int8)
    flag[(reasons & DEGRADED) > 0] = 1
    flag[(reasons & INVALID_BITS) > 0] = 2
    return flag


def seq_gap_intervals(
    ts: np.ndarray, seq: np.ndarray, reset_ts: np.ndarray, day_end: int
) -> list[tuple[int, int]]:
    """Invalid from the last good event before a gap to the next snapshot or reset event,
    or to the end of the day if none arrives."""
    out = []
    for i in np.flatnonzero(np.diff(seq) > 1):  # gap between event i and i + 1
        j = np.searchsorted(reset_ts, ts[i + 1], side="left")
        out.append((int(ts[i]), int(reset_ts[j]) if j < len(reset_ts) else int(day_end)))
    return out


def stale_intervals(
    ts: np.ndarray, sessions: list[tuple[int, int]], stale_ns: int
) -> list[tuple[int, int]]:
    """Samples more than `stale_ns` after the last update, until the next update. The
    session start and end count as virtual events."""
    out = []
    for s, e in sessions:
        lo = np.searchsorted(ts, s, side="left")
        hi = np.searchsorted(ts, e, side="right")
        t = np.concatenate(([s], ts[lo:hi], [e]))
        for i in np.flatnonzero(np.diff(t) > stale_ns):
            out.append((int(t[i] + stale_ns), int(t[i + 1])))
    return out


def crossed_mask(bid1: np.ndarray, ask1: np.ndarray) -> np.ndarray:
    """Best bid at or above best ask. Compared only where both prices exist."""
    with np.errstate(invalid="ignore"):
        return bid1 >= ask1  # NaN compares False


def bad_value_mask(px: np.ndarray, sz: np.ndarray) -> np.ndarray:
    """px, sz: float arrays (n, 20) with NaN for empty levels. A level is bad if its price
    or size is not positive, or if it has one of the two but not the other."""
    with np.errstate(invalid="ignore"):
        nonpositive = (px <= 0) | (sz <= 0)
    half_empty = np.isnan(px) != np.isnan(sz)
    return (nonpositive | half_empty).any(axis=1)


def runs(mask: np.ndarray, grid_ts: np.ndarray) -> list[tuple[int, int]]:
    """Contiguous True runs as (first_ts, last_ts) pairs."""
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return []
    cut = np.flatnonzero(np.diff(idx) > 1)
    starts = np.concatenate(([idx[0]], idx[cut + 1]))
    ends = np.concatenate((idx[cut], [idx[-1]]))
    return [(int(grid_ts[a]), int(grid_ts[b])) for a, b in zip(starts, ends, strict=True)]


def check_symbol(
    ev: dict,
    sm: dict,
    sessions: list[tuple[int, int]],
    stale_ms: int,
    day_end: int,
    max_ranges: int = 100,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Run all checks for one symbol-day on the 50 ms channel.

    ev: sorted arrays `ts`, `seq`, `is_reset` (bool).
    sm: arrays `grid_ts`, `bid_px`, `ask_px`, `bid_sz`, `ask_sz` (each (n, 10), NaN for
        empty levels), `n_unapplied`, `book_valid`.
    Returns (reasons, flags, report)."""
    g = sm["grid_ts"]
    reasons = np.zeros(len(g), dtype=np.uint8)
    reset_ts = ev["ts"][ev["is_reset"]]
    for a, b in seq_gap_intervals(ev["ts"], ev["seq"], reset_ts, day_end):
        mark(reasons, g, a, b, SEQ_GAP)
    for a, b in stale_intervals(ev["ts"], sessions, int(stale_ms) * 1_000_000):
        mark(reasons, g, a, b, STALE)
    if len(g):
        reasons[crossed_mask(sm["bid_px"][:, 0], sm["ask_px"][:, 0])] |= CROSSED
        px = np.hstack([sm["bid_px"], sm["ask_px"]])
        sz = np.hstack([sm["bid_sz"], sm["ask_sz"]])
        reasons[bad_value_mask(px, sz)] |= BAD_VALUE
        reasons[sm["n_unapplied"] > 0] |= DEGRADED
    flags = to_flag(reasons)
    checks = {}
    for bit, name in CODE_NAMES.items():
        rr = runs((reasons & bit) > 0, g)
        checks[name] = {
            "count": len(rr),
            "ranges": [list(r) for r in rr[:max_ranges]],
            "ranges_truncated": len(rr) > max_ranges,
        }
    report = {
        "samples_total": int(len(g)),
        "flag_counts": {str(k): int((flags == k).sum()) for k in (0, 1, 2)},
        "flag_mismatch": int(((flags == 2) != (~sm["book_valid"])).sum()),
        "checks": checks,
    }
    return reasons, flags, report


def window_reasons(
    grid_50: np.ndarray, reasons_50: np.ndarray, grid_coarse: np.ndarray, width_ns: int
) -> np.ndarray:
    """Reason bits for coarser samples: the union of the fine samples in (g - width, g].
    Uses cumulative counts per bit, so it does not assume the grids tile exactly."""
    out = np.zeros(len(grid_coarse), dtype=np.uint8)
    i0 = np.searchsorted(grid_50, grid_coarse - width_ns, side="right")
    i1 = np.searchsorted(grid_50, grid_coarse, side="right")
    for bit in CODE_NAMES:
        cum = np.concatenate(([0], np.cumsum((reasons_50 & bit) > 0)))
        out[(cum[i1] - cum[i0]) > 0] |= bit
    return out
