"""Pilot agents: deterministic checks and evaluation that run outside the data path."""
