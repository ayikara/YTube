"""Summary templates. The pilot uses fixed templates only; there is no LLM."""

from __future__ import annotations


def integrity_summary(symbol: str, report: dict) -> str:
    """One-line summary for a symbol's integrity report."""
    counts = report["flag_counts"]
    incidents = sum(v["count"] for v in report["checks"].values())
    if incidents == 0:
        return f"{symbol}: no incidents found."
    return (
        f"{symbol}: {incidents} incident(s); {counts['2']} samples marked invalid "
        f"and {counts['1']} degraded."
    )


def evaluation_summary(n_days: int, diff: float, lo: float, hi: float) -> str:
    """Summary of the Pilot-minus-Raw difference in mean daily net ticks."""
    if lo > 0 or hi < 0:
        return (
            f"Over {n_days} held-out days, adding the pilot features changed mean daily net "
            f"PnL by {diff:+.2f} ticks (95% interval {lo:+.2f} to {hi:+.2f})."
        )
    return (
        f"Over {n_days} held-out days, the interval ({lo:+.2f} to {hi:+.2f} ticks) includes "
        "zero, so no improvement is established."
    )


def evaluation_summary_lookahead() -> str:
    return (
        "The signal looks ahead: its output at earlier rows changed when later rows were "
        "removed. Performance numbers are omitted."
    )


def evaluation_summary_unavailable(n_days: int) -> str:
    return (
        f"Over {n_days} held-out days the pilot-feature run completed, but the Raw run was "
        "unavailable (the signal needs pilot columns), so no comparison is made."
    )


def evaluation_summary_failed(message: str) -> str:
    return f"The evaluation could not complete: {message}"


CAVEATS = (
    "Results show incremental information on held-out data, not a promised return. Costs and "
    "latency are assumptions. Past results do not predict future results."
)
