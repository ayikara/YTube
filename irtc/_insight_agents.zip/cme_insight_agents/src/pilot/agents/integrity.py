"""Integrity agent: checks every published sample and says which ones are not trustworthy.

Reads the event and sample files for one date, re-derives each check from the raw data (it
does not trust `book_valid`), writes per-sample flags and a JSON report, and never modifies its
inputs. Run: python -m pilot.agents.integrity --date 2026-10-05
"""

from __future__ import annotations

import argparse
import json
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from pilot import __version__
from pilot.agents import integrity_core as core
from pilot.agents.templates import integrity_summary
from pilot.config import (
    NS_PER_DAY,
    PilotConfig,
    config_hash,
    day_start_ns,
    iso_utc,
    load_config,
    sessions_ns,
)
from pilot.io import file_sha256, partition_files, read_partition, write_partition

LEVELS = range(1, 11)
SAMPLE_COLUMNS = ["ts_grid", "channel_ms", "book_valid", "n_unapplied"] + [
    f"{side}_{kind}_{i}" for side in ("bid", "ask") for kind in ("px", "sz") for i in LEVELS
]


@dataclass
class IntegrityReport:
    date: str
    summary: str
    symbols: dict
    files: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """The deterministic part of the report (what is written to the JSON file)."""
        return {"date": self.date, "summary": self.summary, "symbols": self.symbols}


def load_symbol_day(
    cfg: PilotConfig, symbol: str, date: str
) -> tuple[dict, dict, np.ndarray] | None:
    """Load events and 50 ms samples as numpy arrays. Returns (ev, sm, grid_200) or None if
    either dataset has no partition for the symbol-day. Empty book levels become NaN."""
    ev_df = read_partition(cfg.data_root / "events", symbol, date, ["ts_event", "seq", "action"])
    sm_df = read_partition(cfg.data_root / "samples", symbol, date, SAMPLE_COLUMNS)
    if ev_df is None or sm_df is None:
        return None
    order = np.lexsort((ev_df["seq"].to_numpy(), ev_df["ts_event"].to_numpy()))
    ev_df = ev_df.iloc[order]
    ev = {
        "ts": ev_df["ts_event"].to_numpy(dtype=np.int64),
        "seq": ev_df["seq"].to_numpy(dtype=np.int64),
        "is_reset": ev_df["action"].isin(["snapshot", "reset"]).to_numpy(),
    }
    grid_200 = np.sort(sm_df.loc[sm_df["channel_ms"] == 200, "ts_grid"].to_numpy(dtype=np.int64))
    sm50 = sm_df[sm_df["channel_ms"] == 50].sort_values("ts_grid", kind="stable")

    def block(side: str, kind: str) -> np.ndarray:
        cols = [f"{side}_{kind}_{i}" for i in LEVELS]
        return sm50[cols].to_numpy(dtype=float)

    n = len(sm50)
    sm = {
        "grid_ts": sm50["ts_grid"].to_numpy(dtype=np.int64),
        "bid_px": block("bid", "px"),
        "ask_px": block("ask", "px"),
        "bid_sz": block("bid", "sz"),
        "ask_sz": block("ask", "sz"),
        "n_unapplied": (
            sm50["n_unapplied"].fillna(0).to_numpy() if "n_unapplied" in sm50 else np.zeros(n)
        ),
        "book_valid": sm50["book_valid"].to_numpy(dtype=bool),
    }
    return ev, sm, grid_200


def _ranges_utc(ranges: list[list[int]]) -> list[list[str]]:
    return [[iso_utc(a), iso_utc(b)] for a, b in ranges]


class IntegrityAgent:
    def __init__(self, cfg: PilotConfig) -> None:
        self.cfg = cfg

    def run(self, date: str) -> IntegrityReport:
        """Check all configured symbols for `date` and write flags and reports."""
        started = time.time()
        cfg = self.cfg
        day_end = day_start_ns(date) + NS_PER_DAY
        symbols: dict = {}
        files: list[str] = []
        inputs: dict[str, str] = {}
        for symbol in cfg.symbols:
            loaded = load_symbol_day(cfg, symbol, date)
            if loaded is None:
                symbols[symbol] = {
                    "missing": True,
                    "summary": f"{symbol}: no data found for {date}.",
                }
                continue
            ev, sm, grid_200 = loaded
            reasons, flags, rep = core.check_symbol(
                ev,
                sm,
                sessions_ns(cfg, symbol, date),
                cfg.stale_ms_for(symbol),
                day_end,
            )
            for kind in ("events", "samples"):
                for p in partition_files(cfg.data_root / kind, symbol, date):
                    inputs[str(p.relative_to(cfg.root))] = file_sha256(p)
            reasons_200 = core.window_reasons(sm["grid_ts"], reasons, grid_200, 200 * 1_000_000)
            flags_200 = core.to_flag(reasons_200)
            for rr in rep["checks"].values():
                rr["ranges_utc"] = _ranges_utc(rr["ranges"])
            rep["channel_ms"] = 50
            rep["flag_counts_200"] = {str(k): int((flags_200 == k).sum()) for k in (0, 1, 2)}
            rep["summary"] = integrity_summary(symbol, rep)
            symbols[symbol] = rep
            flag_path = self._write_flags(
                symbol, date, sm["grid_ts"], reasons, flags, grid_200, reasons_200, flags_200
            )
            files.append(str(flag_path))
        summary = " ".join(symbols[s]["summary"] for s in sorted(symbols))
        report = IntegrityReport(date=date, summary=summary, symbols=symbols)
        stamp = date.replace("-", "")
        out_dir = cfg.agents_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        json_path = out_dir / f"integrity_{stamp}.json"
        json_path.write_text(json.dumps(report.to_dict(), sort_keys=True, indent=2) + "\n")
        meta = {
            "agent": "integrity",
            "run_id": uuid.uuid4().hex,
            "started_at": iso_utc(int(started * 1e9)),
            "finished_at": iso_utc(int(time.time() * 1e9)),
            "config_hash": config_hash(cfg),
            "code_version": __version__,
            "inputs": inputs,
        }
        meta_path = out_dir / f"integrity_{stamp}.meta.json"
        meta_path.write_text(json.dumps(meta, sort_keys=True, indent=2) + "\n")
        report.files = [str(json_path), str(meta_path), *files]
        return report

    def _write_flags(
        self,
        symbol: str,
        date: str,
        grid_50: np.ndarray,
        reasons_50: np.ndarray,
        flags_50: np.ndarray,
        grid_200: np.ndarray,
        reasons_200: np.ndarray,
        flags_200: np.ndarray,
    ) -> Path:
        """Write the flags Parquet file: one row per sample, both channels, sorted."""
        frames = []
        for ch, g, r, f in (
            (50, grid_50, reasons_50, flags_50),
            (200, grid_200, reasons_200, flags_200),
        ):
            frames.append(
                pd.DataFrame(
                    {
                        "symbol": symbol,
                        "ts_grid": g.astype(np.int64),
                        "channel_ms": np.int32(ch),
                        "quality_flag": f.astype(np.int8),
                        "reason_code": r.astype(np.int16),
                    }
                )
            )
        df = pd.concat(frames, ignore_index=True).sort_values(["channel_ms", "ts_grid"])
        df["channel_ms"] = df["channel_ms"].astype(np.int32)
        base = self.cfg.agents_dir / "flags"
        # symbol and date are encoded in the path, so they are not stored as columns
        return write_partition(base, symbol, date, df.drop(columns=["symbol"]), "flags.parquet")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Run the Integrity agent for one date.")
    ap.add_argument("--date", required=True, help="YYYY-MM-DD (UTC)")
    ap.add_argument("--config", default="config/pilot.yaml")
    args = ap.parse_args(argv)
    cfg = load_config(args.config)
    report = IntegrityAgent(cfg).run(args.date)
    print(report.summary)
    for f in report.files:
        print("wrote", f)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
