"""Evaluation agent: backtests a client's signal with and without the pilot features.

Run by CME staff on signal files supplied by clients, on a machine with no production access.
Client code runs only inside the sandbox. Run:
  python -m pilot.agents.evaluation_agent --signal signal.py --symbols ES --start 2026-10-04 \
      --end 2026-10-05
"""

from __future__ import annotations

import argparse
import json
import re
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from pilot import __version__
from pilot.agents import templates
from pilot.agents.backtest import (
    backtest,
    bootstrap_diff,
    prepare_positions,
    summarize,
)
from pilot.agents.report import render_markdown
from pilot.agents.sandbox_parent import run_signal
from pilot.config import PilotConfig, config_hash, iso_utc, load_config
from pilot.io import file_sha256, read_partition

NON_FEATURE = {
    "ts_grid",
    "channel_ms",
    "symbol",
    "date",
    "model_version",
    "quality_flag",
    "ts_event_max",
    "ts_publish",
}


@dataclass
class EvaluationReport:
    name: str
    results: dict
    markdown: str
    files: list[str] = field(default_factory=list)


@dataclass
class DayFrame:
    raw: pd.DataFrame
    pilot: pd.DataFrame
    mid: np.ndarray
    quality_flag: np.ndarray
    any_nan: np.ndarray
    model_version: list[str]


def _safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", s).strip("_") or "signal"


class EvaluationAgent:
    def __init__(self, cfg: PilotConfig) -> None:
        self.cfg = cfg

    # ----- data -----
    def test_days(self, start: str, end: str) -> list[str]:
        """Test-split days within [start, end]. Refuses a range that reaches outside the test
        split recorded in the split manifest."""
        path = self.cfg.split_manifest_path
        if not path.exists():
            raise FileNotFoundError(f"split manifest not found: {path}")
        days = sorted(json.loads(path.read_text())["test_days"])
        if not days:
            raise ValueError("the split manifest lists no test days")
        if start < days[0] or end > days[-1] or start > end:
            raise ValueError(
                f"requested range {start} to {end} is outside the test split "
                f"{days[0]} to {days[-1]}"
            )
        return [d for d in days if start <= d <= end]

    def load_day(self, symbol: str, day: str) -> DayFrame | None:
        """Join 50 ms samples and outputs for one symbol-day into Raw and Pilot views."""
        cfg = self.cfg
        samples = read_partition(cfg.data_root / "samples", symbol, day, channel_ms=50)
        outputs = read_partition(cfg.outputs_root, symbol, day, channel_ms=50)
        if samples is None or outputs is None or samples.empty or outputs.empty:
            return None
        samples = samples.drop(columns=["date"])
        outputs = outputs.drop(columns=["date"])
        df = (
            samples.merge(
                outputs, on=["ts_grid", "channel_ms", "symbol"], how="inner", validate="one_to_one"
            )
            .sort_values("ts_grid", kind="stable")
            .reset_index(drop=True)
        )
        raw_cols = list(samples.columns)
        out_cols = [c for c in outputs.columns if c not in raw_cols]
        feature_cols = [c for c in out_cols if c not in NON_FEATURE]
        any_nan = df[feature_cols].isna().any(axis=1) | df["mid_close"].isna()
        return DayFrame(
            raw=df[raw_cols].copy(),
            pilot=df[raw_cols + out_cols].copy(),
            mid=df["mid_close"].to_numpy(dtype=float),
            quality_flag=df["quality_flag"].to_numpy(),
            any_nan=any_nan.to_numpy(),
            model_version=sorted(df["model_version"].dropna().unique().tolist()),
        )

    # ----- run -----
    def run(
        self,
        signal_path: str | Path,
        symbols: list[str],
        start: str,
        end: str,
        baseline_signal_path: str | Path | None = None,
        name: str | None = None,
    ) -> EvaluationReport:
        a = self.cfg.agents
        days = self.test_days(start, end)
        name = _safe_name(name or Path(signal_path).stem)
        rng = np.random.default_rng(a.seed)
        n_check = min(a.causality_days, len(days))
        check_days = set(rng.choice(days, n_check, replace=False).tolist()) if n_check else set()
        parts: dict[str, list] = {"raw": [], "pilot": []}
        daily: dict[str, dict[str, float]] = {
            "raw": defaultdict(float),
            "pilot": defaultdict(float),
        }
        warnings: list[str] = []
        violations: list[dict] = []
        checked = 0
        isolated: list[bool] = []
        versions: set[str] = set()
        raw_unavailable = False
        failure: str | None = None
        base_path = baseline_signal_path or signal_path

        for di, day in enumerate(days):
            for si, symbol in enumerate(symbols):
                frame = self.load_day(symbol, day)
                if frame is None:
                    warnings.append(f"no data for {symbol} on {day}")
                    continue
                versions.update(frame.model_version)
                cuts = a.causality_cuts if day in check_days else 0
                seed = a.seed + di * 100 + si
                runs = [("pilot", signal_path, frame.pilot)]
                if not raw_unavailable:
                    runs.append(("raw", base_path, frame.raw))
                for label, path, df in runs:
                    try:
                        pos, info = run_signal(
                            path,
                            df,
                            limit_s=a.sandbox_timeout_s,
                            mem_mb=a.sandbox_memory_mb,
                            n_cuts=cuts,
                            require_isolation=a.require_network_isolation,
                            seed=seed,
                        )
                    except RuntimeError as exc:
                        if label == "raw" and baseline_signal_path is None:
                            raw_unavailable = True
                            warnings.append(f"Raw run unavailable: {exc}")
                            continue
                        failure = f"{label} signal on {symbol} {day}: {exc}"
                        break
                    isolated.append(bool(info["network_isolated"]))
                    c = info.get("causality")
                    if c:
                        checked += c["checked"]
                        violations += [
                            {"symbol": symbol, "day": day, "run": label, "cut": v}
                            for v in c["violations"]
                        ]
                    pos = prepare_positions(pos, frame.quality_flag, frame.any_nan)
                    pnl, eff = backtest(frame.mid, pos, a.cost_ticks, a.latency_steps)
                    parts[label].append((pnl, eff))
                    daily[label][day] += float(pnl.sum())
                if failure:
                    break
            if failure:
                break

        results = self._results(
            name,
            symbols,
            start,
            end,
            days,
            parts,
            daily,
            raw_unavailable,
            failure,
            violations,
            checked,
            isolated,
            sorted(versions),
            warnings,
            baseline_signal_path is not None,
        )
        markdown = render_markdown(results)
        out = self.cfg.agents_dir
        out.mkdir(parents=True, exist_ok=True)
        stem = f"evaluation_{name}_{end.replace('-', '')}"
        (out / f"{stem}.json").write_text(json.dumps(results, sort_keys=True, indent=2) + "\n")
        (out / f"{stem}.md").write_text(markdown)
        inputs = {"signal": file_sha256(Path(signal_path))}
        if baseline_signal_path:
            inputs["baseline_signal"] = file_sha256(Path(baseline_signal_path))
        if self.cfg.split_manifest_path.exists():
            inputs["split_manifest"] = file_sha256(self.cfg.split_manifest_path)
        meta = {
            "agent": "evaluation",
            "run_id": uuid.uuid4().hex,
            "finished_at": iso_utc(int(time.time() * 1e9)),
            "config_hash": config_hash(self.cfg),
            "code_version": __version__,
            "inputs": inputs,
        }
        (out / f"{stem}.meta.json").write_text(json.dumps(meta, sort_keys=True, indent=2) + "\n")
        files = [str(out / f"{stem}{ext}") for ext in (".json", ".md", ".meta.json")]
        return EvaluationReport(name=name, results=results, markdown=markdown, files=files)

    def _results(
        self,
        name,
        symbols,
        start,
        end,
        days,
        parts,
        daily,
        raw_unavailable,
        failure,
        violations,
        checked,
        isolated,
        versions,
        warnings,
        has_baseline,
    ) -> dict:
        a = self.cfg.agents
        setup = {
            "name": name,
            "symbols": list(symbols),
            "start": start,
            "end": end,
            "days": list(days),
            "cost_ticks": a.cost_ticks,
            "latency_steps": a.latency_steps,
            "model_version": versions,
            "baseline_provided": has_baseline,
            "network_isolated": bool(isolated) and all(isolated),
        }
        causality = {"checked": checked, "violations": violations}
        base = {
            "setup": setup,
            "raw": None,
            "pilot": None,
            "difference": None,
            "causality": causality,
            "warnings": warnings,
        }
        if failure:
            return {
                **base,
                "status": "failed",
                "summary": templates.evaluation_summary_failed(failure),
            }
        if not parts["pilot"]:
            return {**base, "status": "no_data", "summary": "No data was found for the request."}
        if violations:
            return {
                **base,
                "status": "lookahead",
                "summary": templates.evaluation_summary_lookahead(),
            }
        pilot = summarize(parts["pilot"])
        raw = None if raw_unavailable or not parts["raw"] else summarize(parts["raw"])
        diff = None
        if raw is None:
            summary = templates.evaluation_summary_unavailable(len(days))
        else:
            common = sorted(set(daily["raw"]) & set(daily["pilot"]))
            mean, lo, hi = bootstrap_diff(
                [daily["pilot"][d] for d in common],
                [daily["raw"][d] for d in common],
                n=a.bootstrap_resamples,
                seed=a.seed,
            )
            diff = {"n_days": len(common), "mean_daily_ticks": mean, "ci95": [lo, hi]}
            summary = templates.evaluation_summary(len(common), mean, lo, hi)
            if len(common) < 20:
                warnings.append(
                    f"only {len(common)} days available; the interval is unreliable below 20"
                )
        return {
            **base,
            "raw": raw,
            "pilot": pilot,
            "difference": diff,
            "status": "ok",
            "summary": summary,
        }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Run the Evaluation agent on a client signal file.")
    ap.add_argument("--signal", required=True, help="client signal.py")
    ap.add_argument("--baseline", default=None, help="optional baseline_signal.py (raw columns)")
    ap.add_argument("--symbols", nargs="+", required=True)
    ap.add_argument("--start", required=True)
    ap.add_argument("--end", required=True)
    ap.add_argument("--name", default=None)
    ap.add_argument("--config", default="config/pilot.yaml")
    args = ap.parse_args(argv)
    cfg = load_config(args.config)
    report = EvaluationAgent(cfg).run(
        args.signal, args.symbols, args.start, args.end, args.baseline, args.name
    )
    print(report.results["summary"])
    for f in report.files:
        print("wrote", f)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
