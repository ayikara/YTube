"""Parent side of the sandbox: runs client signal code in a separate, limited process.

This is a pilot-level safeguard, not full isolation. The worker has CPU and memory limits, a
wall-clock timeout, a minimal environment, and (where the host allows it) no network access.
It can still read files the process user can read, so staff must review client code first and
run the agent on a machine with no production access."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

RUNNER = str(Path(__file__).with_name("sandbox_runner.py"))


@lru_cache(maxsize=1)
def network_isolation_available() -> bool:
    """True if `unshare -rn` works on this host (a new network namespace with no network)."""
    if not shutil.which("unshare"):
        return False
    try:
        probe = subprocess.run(["unshare", "-rn", "true"], capture_output=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return probe.returncode == 0


def choose_cuts(n_rows: int, n_cuts: int, seed: int) -> list[int]:
    """Random cut points between 10% and 90% of the rows, sorted and de-duplicated."""
    if n_cuts <= 0 or n_rows < 20:
        return []
    rng = np.random.default_rng(seed)
    lo, hi = int(n_rows * 0.1), int(n_rows * 0.9)
    return sorted({int(c) for c in rng.integers(lo, hi, size=n_cuts)})


def run_signal(
    signal_path: str | Path,
    df: pd.DataFrame,
    limit_s: int = 60,
    mem_mb: int = 4096,
    n_cuts: int = 0,
    require_isolation: bool = True,
    seed: int = 42,
) -> tuple[np.ndarray, dict]:
    """Run `signal(df)` from a client file on one symbol-day.

    Returns (positions as int8, info) where info holds `network_isolated` and, when cuts were
    requested, `causality` = {"checked": n, "violations": [cut, ...]}.
    Raises RuntimeError if the signal fails, times out, returns invalid output, or if
    isolation is required but unavailable."""
    cuts = choose_cuts(len(df), n_cuts, seed)
    isolated = network_isolation_available()
    if require_isolation and not isolated:
        raise RuntimeError("network isolation is unavailable on this host and is required")
    with tempfile.TemporaryDirectory() as tmp:
        inp, out = str(Path(tmp) / "in.parquet"), str(Path(tmp) / "out.parquet")
        df.to_parquet(inp)
        signal = str(Path(signal_path).resolve())  # the worker runs in a temp directory
        cmd = [sys.executable, "-I", RUNNER, signal, inp, out, str(limit_s), str(mem_mb)]
        if cuts:
            cmd.append(json.dumps(cuts))
        if isolated:
            cmd = ["unshare", "-rn", *cmd]
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=limit_s + 5,
                env={"PATH": "/usr/bin:/bin"},
                cwd=tmp,
            )
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError("signal timed out") from exc
        if proc.returncode != 0:
            lines = proc.stderr.strip().splitlines()
            raise RuntimeError("signal failed: " + lines[-1] if lines else "signal failed")
        info = json.loads(proc.stdout.strip().splitlines()[-1])
        info["network_isolated"] = isolated
        positions = pd.read_parquet(out)["pos"].to_numpy(dtype="int8")
    return positions, info
