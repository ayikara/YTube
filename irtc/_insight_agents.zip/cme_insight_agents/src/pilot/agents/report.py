"""Markdown rendering for the Evaluation agent's report."""

from __future__ import annotations

from pilot.agents.templates import CAVEATS


def _pct(x: float) -> str:
    return f"{x * 100:.1f}%"


def _row(label: str, key: str, raw: dict | None, pilot: dict | None, fmt: str) -> str:
    def cell(d: dict | None) -> str:
        if d is None:
            return "unavailable"
        v = d[key]
        return _pct(v) if fmt == "pct" else (f"{v:,.0f}" if fmt == "int" else f"{v:,.2f}")

    return f"| {label} | {cell(raw)} | {cell(pilot)} |"


def render_markdown(r: dict) -> str:
    """Render the metrics dictionary as the six-section report."""
    s = r["setup"]
    lines = [f"# Evaluation report: {s['name']}", "", "## 1. Summary", "", r["summary"], ""]
    lines += ["## 2. Setup", ""]
    lines += [
        f"- Symbols: {', '.join(s['symbols'])}",
        f"- Test period: {s['start']} to {s['end']} ({len(s['days'])} held-out days)",
        f"- Cost per side per unit of position change: {s['cost_ticks']} ticks",
        f"- Latency between decision and fill: {s['latency_steps']} step(s) of 50 ms",
        f"- Model version: {', '.join(s['model_version']) or 'unknown'}",
        f"- Network isolation for client code: {s['network_isolated']}",
        "",
    ]
    lines += ["## 3. Results", ""]
    if r["pilot"] is None:
        lines += ["Performance numbers are omitted.", ""]
    else:
        raw, pilot = r["raw"], r["pilot"]
        lines += [
            "| Metric | Raw | Pilot |",
            "| --- | --- | --- |",
            _row("Trades", "trades", raw, pilot, "int"),
            _row("Hit rate", "hit_rate", raw, pilot, "pct"),
            _row("Mean net ticks per trade", "mean_net_ticks_per_trade", raw, pilot, "num"),
            _row("Total net ticks", "total_net_ticks", raw, pilot, "num"),
            _row("Maximum drawdown (ticks)", "max_drawdown_ticks", raw, pilot, "num"),
            "",
        ]
    lines += ["## 4. Difference (Pilot minus Raw)", ""]
    d = r["difference"]
    if d is None:
        lines += ["Not available.", ""]
    else:
        lo, hi = d["ci95"]
        lines += [
            f"Mean daily difference: {d['mean_daily_ticks']:+.2f} ticks over {d['n_days']} days, "
            f"95% interval {lo:+.2f} to {hi:+.2f}.",
            "",
        ]
    c = r["causality"]
    lines += ["## 5. Look-ahead check", ""]
    if c["checked"] == 0:
        lines += ["No cuts were checked.", ""]
    elif c["violations"]:
        lines += [
            f"FAILED: {len(c['violations'])} of {c['checked']} cuts changed earlier positions.",
            "",
        ]
    else:
        lines += [f"Passed: {c['checked']} cuts, no earlier position changed.", ""]
    if r["warnings"]:
        lines += ["Warnings:", ""] + [f"- {w}" for w in r["warnings"]] + [""]
    lines += ["## 6. Caveats", "", CAVEATS, ""]
    return "\n".join(lines)
