"""Backtest functions for the Evaluation agent. Prices are in ticks."""

from __future__ import annotations

import numpy as np


def backtest(
    mid: np.ndarray, pos: np.ndarray, cost_ticks: float, latency: int = 1
) -> tuple[np.ndarray, np.ndarray]:
    """Per-step PnL in ticks and the effective (delayed, flattened) position, for one day.

    A position decided from row t becomes effective `latency` steps later and then earns the
    mid change. Cost is charged on every change of the effective position. The day ends flat
    and the exit cost is charged. `mid` may contain NaN, which earn nothing."""
    n = len(pos)
    eff = np.zeros(n, dtype=np.int8)
    if latency < n:
        eff[latency:] = pos[: n - latency]
    if n:
        eff[-1] = 0
    prev = np.concatenate(([0], eff[:-1])).astype(np.int8)
    dm = np.nan_to_num(np.diff(mid, prepend=mid[0] if n else 0.0))
    pnl = prev * dm - cost_ticks * np.abs(eff.astype(float) - prev)
    return pnl, eff


def prepare_positions(pos: np.ndarray, quality_flag: np.ndarray, any_nan: np.ndarray) -> np.ndarray:
    """Force flat where the book is invalid or an input is NaN, before the delay."""
    pos = pos.copy()
    pos[(quality_flag == 2) | any_nan] = 0
    return pos


def trade_stats(pnl: np.ndarray, eff: np.ndarray) -> np.ndarray:
    """Net PnL per trade. A trade is a maximal run of constant non-zero effective position.

    Each step goes to the run that held the position into that step. An entry-cost step goes
    to the new run, and the cost of a position flip goes to the run being closed."""
    if len(eff) == 0:
        return np.zeros(0)
    prev = np.concatenate(([0], eff[:-1]))
    run_id = np.concatenate(([0], np.cumsum(eff[1:] != eff[:-1])))
    prev_run = np.concatenate(([0], run_id[:-1]))
    owner = np.where(prev != 0, prev_run, run_id)
    run_pos = np.zeros(run_id.max() + 1, dtype=eff.dtype)
    run_pos[run_id] = eff
    totals = np.bincount(owner, weights=pnl, minlength=len(run_pos))
    return totals[run_pos != 0]


def max_drawdown(pnl: np.ndarray) -> float:
    if len(pnl) == 0:
        return 0.0
    cum = np.cumsum(pnl)
    peak = np.maximum.accumulate(np.maximum(cum, 0.0))
    return float((peak - cum).max())


def summarize(parts: list[tuple[np.ndarray, np.ndarray]]) -> dict:
    """Aggregate metrics over a list of (pnl, eff) pairs, one per symbol-day, in time order.
    Maximum drawdown is taken on the concatenated step PnL."""
    if not parts:
        return {
            "trades": 0,
            "hit_rate": 0.0,
            "mean_net_ticks_per_trade": 0.0,
            "total_net_ticks": 0.0,
            "max_drawdown_ticks": 0.0,
        }
    trades = np.concatenate([trade_stats(p, e) for p, e in parts])
    pnl = np.concatenate([p for p, _ in parts])
    return {
        "trades": int(len(trades)),
        "hit_rate": float((trades > 0).mean()) if len(trades) else 0.0,
        "mean_net_ticks_per_trade": float(trades.mean()) if len(trades) else 0.0,
        "total_net_ticks": float(pnl.sum()),
        "max_drawdown_ticks": max_drawdown(pnl),
    }


def bootstrap_diff(
    daily_pilot: np.ndarray | list[float],
    daily_base: np.ndarray | list[float],
    n: int = 1000,
    seed: int = 42,
) -> tuple[float, float, float]:
    """Mean of the per-day difference (pilot minus base) and its 95% percentile interval,
    resampling days with replacement."""
    d = np.asarray(daily_pilot, dtype=float) - np.asarray(daily_base, dtype=float)
    rng = np.random.default_rng(seed)
    means = d[rng.integers(0, len(d), size=(n, len(d)))].mean(axis=1)
    lo, hi = np.percentile(means, [2.5, 97.5])
    return float(d.mean()), float(lo), float(hi)
