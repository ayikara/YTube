"""Worker process: runs a client signal file on one day of data.

usage: python -I sandbox_runner.py SIGNAL IN.parquet OUT.parquet LIMIT_S MEM_MB [CUTS_JSON]

This file is run as a script, so it must not import anything from the pilot package.
"""

from __future__ import annotations

import importlib.util
import json
import resource
import sys
from collections.abc import Callable

import numpy as np
import pandas as pd


def load_signal(path: str) -> Callable[[pd.DataFrame], pd.Series]:
    """Import the client file and return its `signal` function."""
    spec = importlib.util.spec_from_file_location("client_signal", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.signal


def validate(pos: object, n: int) -> np.ndarray:
    """Check length and values of a signal's output; return int8 positions."""
    s = pd.Series(pos).reset_index(drop=True)
    if len(s) != n:
        raise ValueError(f"signal returned {len(s)} rows, expected {n}")
    if s.isna().any() or not s.isin([-1, 0, 1]).all():
        raise ValueError("positions must be -1, 0 or 1 with no missing values")
    return s.to_numpy(dtype="int8")


def main(
    signal_path: str,
    in_path: str,
    out_path: str,
    limit_s: int,
    mem_mb: int,
    cuts: list[int] | None = None,
) -> None:
    resource.setrlimit(resource.RLIMIT_CPU, (limit_s, limit_s))
    mem = mem_mb * 1024 * 1024
    resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
    df = pd.read_parquet(in_path)
    sig = load_signal(signal_path)
    full = validate(sig(df.copy()), len(df))
    result: dict = {"causality": None}
    if cuts:
        bad = [
            int(c)
            for c in cuts
            if not np.array_equal(validate(sig(df.iloc[:c].copy()), c), full[:c])
        ]
        result["causality"] = {"checked": len(cuts), "violations": bad}
    pd.DataFrame({"pos": full}).to_parquet(out_path)
    print(json.dumps(result))


if __name__ == "__main__":
    cut_list = json.loads(sys.argv[6]) if len(sys.argv) > 6 else None
    main(sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5]), cut_list)
