"""Example baseline: the client's existing logic using raw book columns only.

Contract: define signal(df) -> Series of -1, 0 or 1, one value per row, using only the
current and earlier rows."""

import pandas as pd


def signal(df: pd.DataFrame) -> pd.Series:
    b, a = df["bid_sz_1"], df["ask_sz_1"]
    imbalance = (b - a) / (b + a)
    return (imbalance > 0.3).astype(int) - (imbalance < -0.3).astype(int)
