"""Example client signal that uses the pilot feed.

Go long when the model's 200 ms up probability clearly exceeds the down probability, go short
in the opposite case, and otherwise hold the last position. Holding avoids trading on every
noisy row.

Contract: define signal(df) -> Series of -1 (short), 0 (flat) or 1 (long), one value per row,
using only the current and earlier rows. No file or network access."""

import numpy as np
import pandas as pd


def signal(df: pd.DataFrame) -> pd.Series:
    edge = df["p_up_200"] - df["p_down_200"]
    raw = pd.Series(0.0, index=df.index)
    raw[edge > 0.4] = 1.0
    raw[edge < -0.4] = -1.0
    return raw.replace(0.0, np.nan).ffill().fillna(0).astype(int)
