"""Deliberately BAD example: reads the next row's mid, so the look-ahead check must fail it.
Used by the tests and the demo to show that a look-ahead signal gets no performance numbers."""

import pandas as pd


def signal(df: pd.DataFrame) -> pd.Series:
    return (df["mid_close"].shift(-1) > df["mid_close"]).astype(int)
