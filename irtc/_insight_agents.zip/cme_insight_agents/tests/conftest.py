"""Shared fixtures: a small synthetic workspace with injected faults on one test day."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from pilot import synth
from pilot.agents.sandbox_parent import network_isolation_available
from pilot.config import AgentsConfig, Instrument, PilotConfig

EXAMPLES = Path(__file__).resolve().parent.parent / "examples" / "signals"
DATES = synth.dates_from("2026-09-28", 6)  # last two are the test days
FAULT_DAY = DATES[-1]
FAULTS = [
    synth.Fault("seq_gap", 10, 3),
    synth.Fault("stale", 30, 8),
    synth.Fault("crossed", 50, 2),
    synth.Fault("bad_value", 60, 1),
    synth.Fault("degraded", 70, 2),
]


def make_cfg(root: Path, **agent_overrides) -> PilotConfig:
    agents = dict(
        bootstrap_resamples=200,
        causality_days=1,
        causality_cuts=5,
        sandbox_timeout_s=30,
        require_network_isolation=False,
    )
    agents.update(agent_overrides)
    return PilotConfig(
        instruments=[
            Instrument(symbol="ES", tick_size=0.25),
            Instrument(symbol="CL", tick_size=0.01),
        ],
        root=root,
        agents=AgentsConfig(**agents),
    )


@pytest.fixture(scope="session")
def template_workspace(tmp_path_factory):
    """Generate the synthetic data once per session; tests copy it."""
    root = tmp_path_factory.mktemp("template")
    cfg = make_cfg(root)
    days = synth.generate(cfg, DATES, minutes=2, faults={("ES", FAULT_DAY): FAULTS}, test_days=2)
    return root, days


@pytest.fixture
def workspace(template_workspace, tmp_path):
    """A fresh copy of the synthetic workspace: (cfg, generated days)."""
    src, days = template_workspace
    dst = tmp_path / "ws"
    shutil.copytree(src, dst)
    return make_cfg(dst), days


@pytest.fixture
def isolation_available() -> bool:
    return network_isolation_available()
