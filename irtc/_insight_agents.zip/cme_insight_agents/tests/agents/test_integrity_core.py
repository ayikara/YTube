import numpy as np

from pilot.agents import integrity_core as ic

MS = 1_000_000


def _book(n):
    bid_px = np.tile(np.arange(100, 90, -1, dtype=float), (n, 1))
    ask_px = np.tile(np.arange(101, 111, dtype=float), (n, 1))
    ask_px[:, 9:] = np.nan  # an empty level on the ask side
    bid_sz = np.full((n, 10), 5.0)
    ask_sz = np.full((n, 10), 5.0)
    ask_sz[:, 9:] = np.nan
    return bid_px, ask_px, bid_sz, ask_sz


def _scenario():
    grid = np.arange(0, 60_000, 50, dtype=np.int64) * MS
    n = len(grid)
    ts = np.arange(0, 60_000, 10, dtype=np.int64) * MS
    seq = np.arange(len(ts), dtype=np.int64)
    is_reset = np.zeros(len(ts), bool)
    is_reset[np.searchsorted(ts, 10_500 * MS)] = True
    keep = ~((ts > 30_000 * MS) & (ts < 37_000 * MS))
    ts, is_reset = ts[keep], is_reset[keep]
    seq = np.arange(len(ts), dtype=np.int64)
    kk = np.searchsorted(ts, 10_000 * MS)
    seq[kk + 1 :] += 5
    bid_px, ask_px, bid_sz, ask_sz = _book(n)
    bid_px[1000, 0] = 102.0
    bid_sz[1100, 3] = -1.0
    unapplied = np.zeros(n, int)
    unapplied[1150] = 2
    ev = {"ts": ts, "seq": seq, "is_reset": is_reset}
    sm = {
        "grid_ts": grid,
        "bid_px": bid_px,
        "ask_px": ask_px,
        "bid_sz": bid_sz,
        "ask_sz": ask_sz,
        "n_unapplied": unapplied,
        "book_valid": np.ones(n, bool),
    }
    return ev, sm, kk


def test_each_injected_fault_is_found():
    ev, sm, kk = _scenario()
    g = sm["grid_ts"]
    reasons, flags, rep = ic.check_symbol(ev, sm, [(0, 60_000 * MS)], 5000, 60_000 * MS)
    gap = np.flatnonzero((g > ev["ts"][kk]) & (g < 10_500 * MS))
    assert set(np.flatnonzero(reasons & ic.SEQ_GAP)) == set(gap)
    assert len(gap) == 9
    stale = np.flatnonzero(reasons & ic.STALE)
    assert len(stale) == 39 and g[stale[0]] > 35_000 * MS and g[stale[-1]] < 37_000 * MS
    assert list(np.flatnonzero(reasons & ic.CROSSED)) == [1000]
    assert list(np.flatnonzero(reasons & ic.BAD_VALUE)) == [1100]
    assert flags[1150] == 1 and list(np.flatnonzero(reasons & ic.DEGRADED)) == [1150]
    assert rep["checks"]["SEQ_GAP"]["count"] == 1
    assert rep["flag_counts"]["2"] == 9 + 39 + 1 + 1 and rep["flag_counts"]["1"] == 1


def test_clean_day_has_no_flags():
    ev, sm, _ = _scenario()
    n = len(sm["grid_ts"])
    ev = {
        "ts": np.arange(0, 60_000, 10, dtype=np.int64) * MS,
        "seq": np.arange(6000),
        "is_reset": np.zeros(6000, bool),
    }
    sm["bid_px"], sm["ask_px"], sm["bid_sz"], sm["ask_sz"] = _book(n)
    sm["n_unapplied"] = np.zeros(n, int)
    _, flags, rep = ic.check_symbol(ev, sm, [(0, 60_000 * MS)], 5000, 60_000 * MS)
    assert (flags == 0).all()
    assert all(v["count"] == 0 for v in rep["checks"].values())


def test_flag_mismatch_counts_disagreements_with_book_valid():
    ev, sm, _ = _scenario()
    n = len(sm["grid_ts"])
    ev = {
        "ts": np.arange(0, 60_000, 10, dtype=np.int64) * MS,
        "seq": np.arange(6000),
        "is_reset": np.zeros(6000, bool),
    }
    sm["bid_px"], sm["ask_px"], sm["bid_sz"], sm["ask_sz"] = _book(n)
    sm["n_unapplied"] = np.zeros(n, int)
    sm["book_valid"][5] = False
    _, _, rep = ic.check_symbol(ev, sm, [(0, 60_000 * MS)], 5000, 60_000 * MS)
    assert rep["flag_mismatch"] == 1


def test_no_reset_leaves_book_invalid_to_end_of_day():
    ts = np.array([0, 10, 20, 30], dtype=np.int64) * MS
    seq = np.array([1, 2, 9, 10], dtype=np.int64)
    out = ic.seq_gap_intervals(ts, seq, np.array([], dtype=np.int64), 1_000 * MS)
    assert out == [(10 * MS, 1_000 * MS)]


def test_stale_inside_session_only():
    ts = np.array([1_000, 2_000], dtype=np.int64) * MS
    out = ic.stale_intervals(ts, [(0, 20_000 * MS)], 5_000 * MS)
    assert out == [(7_000 * MS, 20_000 * MS)]  # after the last update, to session end
    assert ic.stale_intervals(ts, [], 5_000 * MS) == []  # outside any session: never stale


def test_half_empty_level_is_bad():
    px = np.array([[100.0, np.nan]])
    sz = np.array([[5.0, 5.0]])
    assert ic.bad_value_mask(px, sz).tolist() == [True]
    assert ic.bad_value_mask(np.array([[100.0, np.nan]]), np.array([[5.0, np.nan]])).tolist() == [
        False
    ]


def test_window_reasons_union_of_fine_samples():
    g50 = np.arange(1, 13, dtype=np.int64) * 50 * MS
    r50 = np.zeros(12, dtype=np.uint8)
    r50[5] = ic.CROSSED
    g200 = np.array([4, 8, 12], dtype=np.int64) * 50 * MS
    out = ic.window_reasons(g50, r50, g200, 200 * MS)
    assert out.tolist() == [0, ic.CROSSED, 0]
