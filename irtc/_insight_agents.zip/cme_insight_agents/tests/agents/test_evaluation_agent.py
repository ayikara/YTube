import json
import textwrap

import pytest

from pilot.agents.evaluation_agent import EvaluationAgent
from tests.conftest import DATES, EXAMPLES, make_cfg

START, END = DATES[-2], DATES[-1]
PILOT = EXAMPLES / "pilot_signal.py"
BASE = EXAMPLES / "baseline_signal.py"
AHEAD = EXAMPLES / "lookahead_signal.py"


def _run(cfg, signal=PILOT, baseline=BASE, name="t", symbols=("ES", "CL")):
    return EvaluationAgent(cfg).run(signal, list(symbols), START, END, baseline, name)


def test_report_files_and_comparison(workspace):
    cfg, _ = workspace
    rep = _run(cfg)
    r = rep.results
    assert r["status"] == "ok"
    assert r["raw"]["trades"] > 0 and r["pilot"]["trades"] > 0
    assert r["difference"]["n_days"] == 2
    lo, hi = r["difference"]["ci95"]
    assert lo <= r["difference"]["mean_daily_ticks"] <= hi
    assert (
        r["difference"]["mean_daily_ticks"] > 0
    )  # the fixture builds in an edge for pilot columns
    assert r["causality"]["checked"] > 0 and r["causality"]["violations"] == []
    assert any("unreliable" in w for w in r["warnings"])
    for f in rep.files:
        assert (cfg.agents_dir / f.split("/")[-1]).exists()
    md = rep.markdown
    for h in (
        "1. Summary",
        "2. Setup",
        "3. Results",
        "4. Difference",
        "5. Look-ahead",
        "6. Caveats",
    ):
        assert h in md
    assert "not a promised return" in md


def test_reports_are_reproducible_and_meta_is_separate(workspace):
    cfg, _ = workspace
    a = _run(cfg)
    first = {f: open(f, "rb").read() for f in a.files if not f.endswith(".meta.json")}
    b = _run(cfg)
    assert first == {f: open(f, "rb").read() for f in b.files if not f.endswith(".meta.json")}
    meta = json.loads(open([f for f in b.files if f.endswith(".meta.json")][0]).read())
    assert set(meta["inputs"]) >= {"signal", "baseline_signal", "split_manifest"}


def test_look_ahead_signal_gets_no_performance_numbers(workspace):
    cfg, _ = workspace
    rep = _run(cfg, signal=AHEAD, baseline=AHEAD, name="ahead")
    r = rep.results
    assert r["status"] == "lookahead"
    assert r["raw"] is None and r["pilot"] is None and r["difference"] is None
    assert len(r["causality"]["violations"]) > 0
    assert "Performance numbers are omitted" in rep.markdown and "FAILED" in rep.markdown


def test_dates_outside_the_test_split_are_refused(workspace):
    cfg, _ = workspace
    agent = EvaluationAgent(cfg)
    with pytest.raises(ValueError, match="outside the test split"):
        agent.run(PILOT, ["ES"], DATES[0], END)
    with pytest.raises(ValueError, match="outside the test split"):
        agent.run(PILOT, ["ES"], START, "2030-01-01")


def test_missing_split_manifest_is_an_error(workspace):
    cfg, _ = workspace
    cfg.split_manifest_path.unlink()
    with pytest.raises(FileNotFoundError):
        EvaluationAgent(cfg).run(PILOT, ["ES"], START, END)


def test_signal_needing_pilot_columns_without_baseline_leaves_raw_unavailable(workspace):
    cfg, _ = workspace
    rep = _run(cfg, baseline=None, name="nobase")
    r = rep.results
    assert r["status"] == "ok" and r["raw"] is None and r["difference"] is None
    assert r["pilot"]["trades"] > 0
    assert "unavailable" in r["summary"] and "Raw run unavailable" in " ".join(r["warnings"])


def test_failing_signal_is_reported_not_raised(workspace, tmp_path):
    cfg, _ = workspace
    bad = tmp_path / "bad.py"
    bad.write_text("def signal(df):\n    return df['p_up_200'].iloc[:3]\n")
    rep = _run(cfg, signal=bad, name="bad")
    assert rep.results["status"] == "failed"
    assert "could not complete" in rep.results["summary"]
    assert rep.results["pilot"] is None


def test_unknown_symbol_gives_no_data(workspace):
    cfg, _ = workspace
    rep = EvaluationAgent(cfg).run(PILOT, ["ZZ"], START, END, BASE, "zz")
    assert rep.results["status"] == "no_data"
    assert any("no data for ZZ" in w for w in rep.results["warnings"])


def test_isolation_requirement_is_recorded_when_available(workspace, isolation_available):
    cfg, _ = workspace
    cfg2 = make_cfg(cfg.root, require_network_isolation=isolation_available)
    rep = EvaluationAgent(cfg2).run(PILOT, ["ES"], START, END, BASE, "iso")
    assert rep.results["setup"]["network_isolated"] is isolation_available


def test_constant_long_signal_survives_invalid_book_rows(workspace, tmp_path):
    """The faulty ES day has invalid rows; positions are forced flat there, so the trades
    are split into several and the run still completes."""
    cfg, _ = workspace
    p = tmp_path / "long.py"
    p.write_text(
        textwrap.dedent("""
        def signal(df):
            return df['mid_close'] * 0 + 1
    """)
    )
    rep = EvaluationAgent(cfg).run(p, ["ES"], START, END, p, "long")
    assert rep.results["status"] == "ok"
    assert rep.results["pilot"]["trades"] >= 4  # at least a split around each invalid window
