import json

import yaml

from pilot import synth
from pilot.agents import evaluation_agent, integrity
from pilot.config import config_hash, iso_utc, load_config, sessions_ns


def test_sessions_handle_defaults_and_overnight(tmp_path):
    cfg_path = tmp_path / "config" / "pilot.yaml"
    cfg_path.parent.mkdir()
    cfg_path.write_text(
        yaml.safe_dump(
            {
                "instruments": [
                    {"symbol": "ES", "tick_size": 0.25},
                    {"symbol": "XX", "tick_size": 1.0},
                ],
                "agents": {"trading_hours": {"ES": [["22:00", "21:00"]], "XX": []}},
            }
        )
    )
    cfg = load_config(cfg_path)
    d0 = sessions_ns(cfg, "XX", "2026-10-05")
    assert d0[0][1] - d0[0][0] == 24 * 3600 * 10**9  # no hours: open all day
    ((s, e),) = sessions_ns(cfg, "ES", "2026-10-05")
    assert e - s == 23 * 3600 * 10**9  # 22:00 to 21:00 next day
    assert iso_utc(s) == "2026-10-05T22:00:00.000Z"
    assert cfg.root == tmp_path.resolve() and len(config_hash(cfg)) == 16


def test_fault_that_does_not_fit_the_day_is_a_clear_error():
    import pytest

    with pytest.raises(ValueError, match="does not fit"):
        synth.make_day(
            "ES", "2026-09-28", 0.25, 1, minutes=1, faults=[synth.Fault("stale", 50, 20)]
        )


def test_cli_round_trip(tmp_path, capsys):
    (tmp_path / "config").mkdir()
    cfg_path = tmp_path / "config" / "pilot.yaml"
    cfg_path.write_text(
        yaml.safe_dump(
            {
                "instruments": [{"symbol": "ES", "tick_size": 0.25}],
                "paths": {
                    "data": "data",
                    "outputs": "data/outputs",
                    "artifacts": "artifacts",
                    "split_manifest": "artifacts/split.json",
                },
                "agents": {
                    "bootstrap_resamples": 100,
                    "causality_days": 1,
                    "causality_cuts": 3,
                    "require_network_isolation": False,
                },
            }
        )
    )
    assert (
        synth.main(
            [
                "--config",
                str(cfg_path),
                "--start",
                "2026-09-28",
                "--days",
                "3",
                "--minutes",
                "1",
                "--test-days",
                "2",
                "--faults",
                "none",
            ]
        )
        == 0
    )
    assert integrity.main(["--config", str(cfg_path), "--date", "2026-09-30"]) == 0
    assert "no incidents found" in capsys.readouterr().out
    sig = tmp_path / "s.py"
    sig.write_text("def signal(df):\n    return (df['p_up_200'] > df['p_down_200']).astype(int)\n")
    base = tmp_path / "b.py"
    base.write_text("def signal(df):\n    return (df['bid_sz_1'] > df['ask_sz_1']).astype(int)\n")
    assert (
        evaluation_agent.main(
            [
                "--config",
                str(cfg_path),
                "--signal",
                str(sig),
                "--baseline",
                str(base),
                "--symbols",
                "ES",
                "--start",
                "2026-09-29",
                "--end",
                "2026-09-30",
                "--name",
                "cli",
            ]
        )
        == 0
    )
    out = json.loads((tmp_path / "artifacts/agents/evaluation_cli_20260930.json").read_text())
    assert out["status"] == "ok" and out["difference"]["n_days"] == 2
