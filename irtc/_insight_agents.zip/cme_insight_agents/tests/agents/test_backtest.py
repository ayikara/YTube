import numpy as np

from pilot.agents import backtest as bt


def test_known_pnl_on_a_rising_price():
    mid = np.arange(100, dtype=float)
    pnl, eff = bt.backtest(mid, np.ones(100, dtype=np.int8), 0.5, latency=1)
    assert abs(pnl.sum() - 97.0) < 1e-9  # 98 ticks earned, 0.5 to enter, 0.5 to exit
    s = bt.summarize([(pnl, eff)])
    assert s["trades"] == 1 and s["hit_rate"] == 1.0
    assert abs(s["mean_net_ticks_per_trade"] - 97.0) < 1e-9
    assert abs(s["max_drawdown_ticks"] - 0.5) < 1e-9


def test_zero_latency_enters_immediately():
    mid = np.arange(10, dtype=float)
    pnl, eff = bt.backtest(mid, np.ones(10, dtype=np.int8), 0.0, latency=0)
    assert eff[0] == 1 and eff[-1] == 0


def test_day_ends_flat_and_exit_cost_is_charged():
    mid = np.zeros(5)
    pnl, eff = bt.backtest(mid, np.ones(5, dtype=np.int8), 1.0, latency=0)
    assert eff[-1] == 0 and abs(pnl.sum() - (-2.0)) < 1e-9  # one entry, one exit


def test_flip_cost_goes_to_closing_trade_and_totals_match():
    pos = np.array([1, 1, -1, -1, 0, 0], dtype=np.int8)
    mid = np.array([0, 1, 2, 1, 0, 0], dtype=float)
    pnl, eff = bt.backtest(mid, pos, 0.0, latency=0)
    trades = bt.trade_stats(pnl, eff)
    assert trades.tolist() == [2.0, 2.0] and abs(trades.sum() - pnl.sum()) < 1e-9


def test_invalid_book_rows_are_forced_flat_and_nan_mid_earns_nothing():
    pos = bt.prepare_positions(
        np.ones(5, dtype=np.int8), np.array([0, 0, 2, 0, 0]), np.zeros(5, bool)
    )
    assert pos.tolist() == [1, 1, 0, 1, 1]
    pnl, _ = bt.backtest(np.array([1.0, np.nan, 3.0, 4.0, 5.0]), np.ones(5, dtype=np.int8), 0.0, 0)
    assert np.isfinite(pnl).all()


def test_empty_inputs_do_not_crash():
    pnl, eff = bt.backtest(np.zeros(0), np.zeros(0, dtype=np.int8), 0.5)
    assert len(pnl) == 0 and bt.summarize([(pnl, eff)])["trades"] == 0
    assert bt.summarize([])["trades"] == 0


def test_bootstrap_is_reproducible_and_sign_correct():
    a = bt.bootstrap_diff(np.arange(30.0), np.zeros(30), n=500, seed=1)
    assert a == bt.bootstrap_diff(np.arange(30.0), np.zeros(30), n=500, seed=1)
    mean, lo, hi = a
    assert lo < mean < hi and lo > 0
