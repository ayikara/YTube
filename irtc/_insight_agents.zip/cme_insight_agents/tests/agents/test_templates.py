from pilot.agents import templates as t


def test_integrity_summary_clean_and_faulty():
    clean = {"flag_counts": {"0": 10, "1": 0, "2": 0}, "checks": {"SEQ_GAP": {"count": 0}}}
    assert t.integrity_summary("ES", clean) == "ES: no incidents found."
    bad = {"flag_counts": {"0": 8, "1": 1, "2": 3}, "checks": {"SEQ_GAP": {"count": 2}}}
    assert t.integrity_summary("ES", bad) == (
        "ES: 2 incident(s); 3 samples marked invalid and 1 degraded."
    )


def test_evaluation_summary_branches():
    assert "changed mean daily net PnL by +1.50" in t.evaluation_summary(30, 1.5, 0.5, 2.5)
    assert "includes zero" in t.evaluation_summary(30, 0.2, -1.0, 1.4)


def test_templates_render_without_placeholders():
    for text in (
        t.evaluation_summary_lookahead(),
        t.evaluation_summary_unavailable(3),
        t.evaluation_summary_failed("boom"),
        t.CAVEATS,
    ):
        assert "{" not in text and "}" not in text
