import textwrap

import numpy as np
import pandas as pd
import pytest

from pilot.agents.sandbox_parent import choose_cuts, network_isolation_available, run_signal


def _write(tmp_path, name, body):
    p = tmp_path / name
    p.write_text(textwrap.dedent(body))
    return p


@pytest.fixture
def df():
    return pd.DataFrame({"x": np.cumsum(np.random.default_rng(0).normal(size=2000))})


def test_causal_signal_passes_all_cuts(tmp_path, df):
    p = _write(
        tmp_path,
        "good.py",
        """
        def signal(df):
            d = df["x"].diff()
            return (d > 0).astype(int) - (d < 0).astype(int)
    """,
    )
    pos, info = run_signal(p, df, limit_s=30, n_cuts=20, require_isolation=False)
    assert len(pos) == len(df) and info["causality"]["checked"] > 0
    assert info["causality"]["violations"] == []


def test_look_ahead_signal_is_caught(tmp_path, df):
    p = _write(
        tmp_path,
        "ahead.py",
        """
        def signal(df):
            return (df["x"].shift(-1) > df["x"]).astype(int)
    """,
    )
    _, info = run_signal(p, df, limit_s=30, n_cuts=20, require_isolation=False)
    assert len(info["causality"]["violations"]) > 0


def test_relative_signal_path_works(tmp_path, df, monkeypatch):
    _write(tmp_path, "rel.py", "def signal(df):\n    return df['x'] * 0\n")
    monkeypatch.chdir(tmp_path)
    pos, _ = run_signal("rel.py", df, limit_s=30, require_isolation=False)
    assert (pos == 0).all()


def test_timeout_is_reported(tmp_path, df):
    p = _write(tmp_path, "slow.py", "import time\ndef signal(df):\n    time.sleep(30)\n")
    with pytest.raises(RuntimeError, match="timed out|failed"):
        run_signal(p, df, limit_s=2, require_isolation=False)


@pytest.mark.parametrize(
    "body",
    [
        "def signal(df):\n    return df['x'].iloc[:5]\n",  # wrong length
        "def signal(df):\n    return df['x'] * 0 + 2\n",  # value outside -1, 0, 1
        "def signal(df):\n    return df['x'] * float('nan')\n",
        "def signal(df):\n    raise ValueError('boom')\n",
    ],
)
def test_invalid_output_or_exception_is_a_failure(tmp_path, df, body):
    p = _write(tmp_path, "bad.py", body)
    with pytest.raises(RuntimeError, match="signal failed"):
        run_signal(p, df, limit_s=30, require_isolation=False)


def test_missing_column_is_a_failure(tmp_path, df):
    p = _write(tmp_path, "col.py", "def signal(df):\n    return df['nope']\n")
    with pytest.raises(RuntimeError, match="KeyError"):
        run_signal(p, df, limit_s=30, require_isolation=False)


@pytest.mark.skipif(not network_isolation_available(), reason="unshare -rn is unavailable")
def test_network_access_is_blocked(tmp_path, df):
    p = _write(
        tmp_path,
        "net.py",
        """
        import socket, pandas as pd
        def signal(df):
            socket.create_connection(("1.1.1.1", 80), timeout=3)
            return pd.Series(0, index=df.index)
    """,
    )
    with pytest.raises(RuntimeError, match="unreachable|failed"):
        run_signal(p, df, limit_s=30, require_isolation=True)


def test_isolation_required_but_unavailable_aborts(tmp_path, df, monkeypatch):
    monkeypatch.setattr("pilot.agents.sandbox_parent.network_isolation_available", lambda: False)
    p = _write(tmp_path, "ok.py", "def signal(df):\n    return df['x'] * 0\n")
    with pytest.raises(RuntimeError, match="isolation"):
        run_signal(p, df, limit_s=30, require_isolation=True)


def test_choose_cuts_is_deterministic_and_in_range():
    a = choose_cuts(1000, 20, 7)
    assert a == choose_cuts(1000, 20, 7) and all(100 <= c < 900 for c in a)
    assert choose_cuts(10, 20, 7) == [] and choose_cuts(1000, 0, 7) == []
