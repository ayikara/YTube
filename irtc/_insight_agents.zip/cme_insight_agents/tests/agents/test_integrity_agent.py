import json

import numpy as np

from pilot.agents import integrity_core as ic
from pilot.agents.integrity import IntegrityAgent
from pilot.io import file_sha256, read_partition
from tests.conftest import DATES, FAULT_DAY

CLEAN_DAY = DATES[0]


def _flags(cfg, symbol, date, channel):
    df = read_partition(cfg.agents_dir / "flags", symbol, date)
    return df[df["channel_ms"] == channel].sort_values("ts_grid").reset_index(drop=True)


def test_flags_match_every_injected_fault(workspace):
    cfg, days = workspace
    IntegrityAgent(cfg).run(FAULT_DAY)
    f = _flags(cfg, "ES", FAULT_DAY, 50)
    g = f["ts_grid"].to_numpy()
    codes = f["reason_code"].to_numpy()
    expected = days[("ES", FAULT_DAY)].expected
    assert set(expected) == set(ic.CODE_NAMES.values())
    for bit, name in ic.CODE_NAMES.items():
        ((start, end),) = expected[name]
        want = np.flatnonzero((g > start) & (g < end))
        got = np.flatnonzero(codes & bit)
        assert got.tolist() == want.tolist(), name
        assert len(want) > 0, f"fixture should flag some samples for {name}"
    flags = f["quality_flag"].to_numpy()
    invalid_bits = ic.INVALID_BITS
    assert ((flags == 2) == ((codes & invalid_bits) > 0)).all()
    degraded_only = ((codes & ic.DEGRADED) > 0) & ((codes & invalid_bits) == 0)
    assert (flags[degraded_only] == 1).all()


def test_report_counts_and_summary(workspace):
    cfg, _ = workspace
    rep = IntegrityAgent(cfg).run(FAULT_DAY)
    es = rep.symbols["ES"]
    assert es["samples_total"] == 2400
    assert all(es["checks"][n]["count"] == 1 for n in ic.CODE_NAMES.values())
    assert es["flag_counts"]["2"] > 0 and es["flag_counts"]["1"] > 0
    assert "5 incident(s)" in rep.summary and "CL: no incidents found." in rep.summary
    assert es["checks"]["SEQ_GAP"]["ranges_utc"][0][0].endswith("Z")


def test_flag_mismatch_equals_bad_value_samples(workspace):
    cfg, days = workspace
    rep = IntegrityAgent(cfg).run(FAULT_DAY)
    ((start, end),) = days[("ES", FAULT_DAY)].expected["BAD_VALUE"]
    g = read_partition(cfg.data_root / "samples", "ES", FAULT_DAY, ["ts_grid", "channel_ms"], 50)
    n_bad = int(((g["ts_grid"] > start) & (g["ts_grid"] < end)).sum())
    assert rep.symbols["ES"]["flag_mismatch"] == n_bad


def test_clean_day_has_all_zero_flags(workspace):
    cfg, _ = workspace
    rep = IntegrityAgent(cfg).run(CLEAN_DAY)
    for sym in ("ES", "CL"):
        assert (_flags(cfg, sym, CLEAN_DAY, 50)["quality_flag"] == 0).all()
        assert rep.symbols[sym]["summary"] == f"{sym}: no incidents found."


def test_rerun_is_byte_identical(workspace):
    cfg, _ = workspace
    agent = IntegrityAgent(cfg)
    a = agent.run(FAULT_DAY)
    stamp = FAULT_DAY.replace("-", "")
    j = cfg.agents_dir / f"integrity_{stamp}.json"
    fl = cfg.agents_dir / "flags" / "symbol=ES" / f"date={FAULT_DAY}" / "flags.parquet"
    first = (j.read_bytes(), fl.read_bytes())
    b = agent.run(FAULT_DAY)
    assert (j.read_bytes(), fl.read_bytes()) == first
    assert a.to_dict() == b.to_dict()


def test_200ms_flags_are_the_max_of_their_50ms_samples(workspace):
    cfg, _ = workspace
    IntegrityAgent(cfg).run(FAULT_DAY)
    f50 = _flags(cfg, "ES", FAULT_DAY, 50)
    f200 = _flags(cfg, "ES", FAULT_DAY, 200)
    assert len(f200) == len(f50) // 4
    for _, row in f200.iloc[:: max(1, len(f200) // 60)].iterrows():
        win = f50[
            (f50["ts_grid"] > row["ts_grid"] - 200_000_000) & (f50["ts_grid"] <= row["ts_grid"])
        ]
        assert row["quality_flag"] == win["quality_flag"].max()


def test_missing_day_is_reported_not_raised(workspace):
    cfg, _ = workspace
    rep = IntegrityAgent(cfg).run("2030-01-01")
    assert rep.symbols["ES"]["missing"] is True and "no data found" in rep.summary


def test_inputs_are_never_modified_and_meta_records_hashes(workspace):
    cfg, _ = workspace
    files = sorted(cfg.data_root.rglob("*.parquet"))
    before = {str(p): file_sha256(p) for p in files}
    IntegrityAgent(cfg).run(FAULT_DAY)
    assert {str(p): file_sha256(p) for p in files} == before
    meta = json.loads(
        (cfg.agents_dir / f"integrity_{FAULT_DAY.replace('-', '')}.meta.json").read_text()
    )
    assert meta["agent"] == "integrity" and len(meta["inputs"]) == 4  # 2 symbols x 2 datasets


def test_empty_sample_file_is_handled(workspace):
    cfg, _ = workspace
    from pilot.io import write_partition

    day = "2026-10-10"
    ev = read_partition(cfg.data_root / "events", "ES", DATES[0])
    sm = read_partition(cfg.data_root / "samples", "ES", DATES[0]).iloc[0:0]
    write_partition(cfg.data_root / "events", "ES", day, ev.drop(columns=["symbol", "date"]))
    write_partition(cfg.data_root / "samples", "ES", day, sm.drop(columns=["symbol", "date"]))
    rep = IntegrityAgent(cfg).run(day)
    assert rep.symbols["ES"]["samples_total"] == 0
