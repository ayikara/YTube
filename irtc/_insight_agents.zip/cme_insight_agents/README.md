# CME Insight Feed pilot: Integrity and Evaluation agents

Two batch agents that run **outside the data path** of the pilot feed. They read files, never
modify their inputs, never block the pipeline, and write results to `artifacts/agents/`.

| Agent | What it does | Command |
| --- | --- | --- |
| Integrity | Checks every 50 ms sample for sequence gaps, crossed and stale books, bad values and unapplied updates; writes a quality flag per sample and a JSON report | `python -m pilot.agents.integrity --date 2026-10-05` |
| Evaluation | Backtests a client's signal with and without the pilot features, with a day-block bootstrap interval and a look-ahead check; client code runs in a sandbox | `python -m pilot.agents.evaluation_agent --signal signal.py --symbols ES --start ... --end ...` |

Both follow the *Implementation Guide: Integrity and Evaluation Agents* (section numbers below
refer to it) and section 9 of the Technical Requirements. Summaries come from fixed templates;
**there is no LLM in the pilot**.

> Research and analytics software. Nothing here is investment advice.

## Quick start

```bash
python3 -m venv .venv && . .venv/bin/activate     # Python 3.11 or newer
make install     # installs the package (editable) and its dependencies
make test        # 51 tests, about 30 seconds
make lint        # ruff
make demo        # synthetic data, both agents, reports in artifacts/agents/
```

After `make install` the `python -m pilot...` commands below work from the project root.
Without installing, prefix them with `PYTHONPATH=src`.

`make demo` writes a synthetic week for two symbols (with faults injected on ES on
2026-09-28), runs the Integrity agent on that faulty day and a clean day, then runs the
Evaluation agent on a good signal and on a look-ahead signal.

## Running the agents

Run everything from the project root. Both agents read `config/pilot.yaml` by default; pass
`--config path/to/pilot.yaml` to use another. Relative paths in the config resolve against the
project root (the parent of the `config/` folder).

**Prerequisites:** the Parquet datasets and split manifest described under *Data layout*. To try
the agents without real data, generate a synthetic set first:
`python -m pilot.synth --days 6 --minutes 5` (injects faults into ES on 2026-09-28).

**Integrity agent** (one UTC date, all symbols in the config):

```bash
python -m pilot.agents.integrity --date 2026-09-28
```

Prints one summary line per symbol and writes the report, the metadata file and the per-sample
flags to `artifacts/agents/`. Run it after each day's pipeline run.

**Evaluation agent** (on demand, for one client signal):

```bash
python -m pilot.agents.evaluation_agent \
    --signal examples/signals/pilot_signal.py \
    --baseline examples/signals/baseline_signal.py \
    --symbols ES CL --start 2026-10-02 --end 2026-10-03 --name demo
```

`--baseline` is optional, `--name` labels the report files (default: the signal file name), and
the date range must lie inside the test split. Prints the summary and writes
`evaluation_<name>_<YYYYMMDD>.md`, `.json` and `.meta.json` to `artifacts/agents/`, where the
date is the end date. See *Evaluation agent* below for the client contract and the sandbox.

**Both at once on synthetic data:** `make demo`.

## Layout

```text
config/pilot.yaml              configuration, including the agents: block (guide 3.2)
src/pilot/config.py            config loading, trading sessions
src/pilot/io.py                hive-partitioned Parquet read and write
src/pilot/synth.py             synthetic data and fault injection (tests and demo only)
src/pilot/agents/
  integrity_core.py            vectorized checks (guide 4.2)
  integrity.py                 IntegrityAgent: loading, orchestration, outputs (4.1, 4.3, 4.4)
  backtest.py                  backtest, trade attribution, bootstrap (5.3 to 5.5)
  sandbox_parent.py            starts the worker with limits (5.6)
  sandbox_runner.py            worker that runs client code and the look-ahead cuts (5.6, 5.7)
  evaluation_agent.py          EvaluationAgent: orchestration (5.2, 5.8)
  report.py                    Markdown report (5.9)
  templates.py                 summary templates (3.4)
examples/signals/              example client signals (good, baseline, deliberately bad)
tests/                         pytest suite; tests/conftest.py builds a synthetic workspace
```

## Data layout

Parquet, hive-partitioned by `symbol` and `date`; the partition keys live in the path, not in
the files. Defaults are set in `config/pilot.yaml`.

```text
data/events/symbol=ES/date=2026-10-05/*.parquet       ts_event, seq, action, side, price_tick, size, order_id
data/samples/symbol=ES/date=2026-10-05/*.parquet      ts_grid, channel_ms, bid/ask px and sz 1..10, ..., book_valid, n_unapplied
data/outputs/symbol=ES/date=2026-10-05/*.parquet      ts_grid, channel_ms, microprice ... p_*_200/1000, pred_entropy, quality_flag
artifacts/models/current/split.json                    {"test_days": ["2026-10-02", ...]}
artifacts/agents/                                      what the agents write
```

Expected conventions: times are int64 nanoseconds since the Unix epoch (UTC); prices are int64
ticks; an empty book level is null in both price and size; event `action` includes `snapshot`
and `reset` (they end a sequence gap); each sample has an `n_unapplied` count.

## Integrity agent

* Re-derives every check from the raw files; it does not trust `book_valid`.
* Reason codes (bit flags): `SEQ_GAP` 1, `CROSSED` 2, `STALE` 4, `BAD_VALUE` 8, `DEGRADED` 16.
  Quality flag 2 (invalid) for the first four, flag 1 (degraded) for `DEGRADED` alone.
* Stale checks apply only inside the sessions in `trading_hours`.
* Flags are computed on the 50 ms channel. A 200 ms sample takes the union of the reason bits
  of the 50 ms samples in the 200 ms before it.
* Outputs per run: `integrity_YYYYMMDD.json` (deterministic: sorted keys, no timestamps),
  `integrity_YYYYMMDD.meta.json` (run id, times, config hash, code version, input hashes) and
  `flags/symbol=.../date=.../flags.parquet`. The publish step should set the final
  `quality_flag` to the highest value across the book, feature and agent flags.
* `flag_mismatch` counts samples where "agent flag = 2" and `book_valid = false` disagree.

## Evaluation agent

Run by CME staff on signal files supplied by clients, on a machine with no production access.

1. Receive `signal.py` (and optionally `baseline_signal.py`). **Read the files first.**
2. Run the command above. Only dates inside the test split in the split manifest are accepted.
3. Review the report in `artifacts/agents/evaluation_<name>_<YYYYMMDD>.md` (and `.json`).

**Client contract:** the file defines `signal(df) -> Series` of -1, 0 or 1, one value per row
(the desired position after that row), using only the current and earlier rows, with no file
or network access. See `examples/signals/`.

* The baseline runs on the Raw columns; the client signal runs on the Pilot columns (Raw plus
  all output fields). Without a baseline file, the same signal runs on both, and the Raw run is
  reported as unavailable if it needs pilot columns.
* Backtest (guide 5.3): a decision is filled `latency_steps` (default 1, so 50 ms) later;
  `cost_ticks` (default 0.5) is charged per side per unit of position change; days end flat;
  rows with an invalid book are forced flat.
* The difference (Pilot minus Raw) is the mean daily net ticks with a seeded day-block
  bootstrap 95% interval. Fewer than 20 days triggers a warning.
* **Look-ahead check:** the worker reruns the signal on truncated data at random cut points; any
  change to earlier positions means the signal looks ahead, and the report then omits all
  performance numbers.
* Statuses: `ok`, `lookahead`, `failed` (the signal crashed, timed out or returned invalid
  output) and `no_data`.

### Sandbox: what it does and does not do

The worker runs in a fresh Python process in isolated mode with a minimal environment, a CPU
limit, a memory limit and a wall-clock timeout, and with **no network where `unshare -rn` works**
(`network_isolated` is recorded in every report; the run aborts if
`require_network_isolation` is true and isolation is unavailable). It does **not** stop client
code from reading files the process user can read, and it is not protection against a determined
attacker. Staff review plus a machine without production access are part of the procedure. Use a
container with a read-only file system before accepting code from unvetted parties.

## Configuration

See `config/pilot.yaml`. **The `trading_hours` values are placeholders**; set them from the real
exchange calendar, including the daily maintenance break and holidays. Raise `stale_ms` (per
instrument, via `stale_ms_overrides`) for quiet contracts.

## What has been verified, and what has not

* 51 automated tests pass (Python 3.12.3, numpy 2.4.4, pandas 3.0.2, pyarrow 26.0.0), and
  `ruff` is clean. The `requirements.txt` lower bounds are untested.
* The Integrity tests inject one fault of each kind into synthetic data and check, against an
  independent calculation, that exactly the right samples are flagged. The Evaluation tests
  cover known PnL, trade attribution, forced-flat rows, reproducible reports, look-ahead
  detection, timeouts, invalid output, rejected dates and, where the host allows it, blocked
  network access.
* **Everything was run on synthetic data only.** `pilot.synth` writes output probabilities that
  are correlated with the *future* price move by construction, so the demo's "pilot beats raw"
  result is a property of the fixture, not evidence about any model or market. Absolute PnL on
  synthetic data is meaningless: its price moves are large relative to the 0.5-tick cost.
* Not yet exercised against real CME message formats, real trading calendars or full-size days
  (about 1.7 million 50 ms samples per symbol-day). If memory is tight, process a session or an
  hour at a time.
* Phase 2, not built: calibration monitor, analyst agent, optional LLM summary layer.
