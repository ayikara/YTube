# CME Futures Microstructure Analysis Pipeline

High-performance CLOB + Transaction processing for 100 CME futures products using PyArrow streaming and Numba JIT compilation.

---

## Project Structure

```
microstructure_pipeline/
├── config/
│   └── pipeline_config.yaml        # Central configuration
├── src/
│   ├── __init__.py
│   ├── constants.py                 # Column names, metrics, parameters
│   ├── config.py                    # PipelineConfig dataclass
│   ├── numba_kernels.py             # All @njit kernels (7 functions)
│   ├── io_utils.py                  # PyArrow read/write/stream helpers
│   ├── phase_a_load.py              # Load, interleave, sweep detection
│   ├── phase_bcd_process.py         # Hourly streaming: timeline → metrics → windows
│   ├── phase_e_percentiles.py       # Hourly percentiles (Step 3)
│   ├── phase_f_aggregate.py         # Multi-day aggregation (Step 4)
│   ├── fan_chart.py                 # Fan chart visualization
│   ├── daily_pipeline.py            # Single-day orchestrator (Steps 1–3)
│   └── quarterly_pipeline.py        # Multi-day orchestrator (Step 4)
├── tests/
│   ├── generate_synthetic_data.py   # Synthetic CLOB + transaction generator
│   ├── test_numba_kernels.py        # Unit tests for all kernels
│   └── test_integration.py          # End-to-end integration test
└── requirements.txt
```

---

## Setup

```bash
pip install -r requirements.txt
```

---

## Testing — Stage by Stage

### Stage 1: Verify constants and config load

```bash
python -c "from src.constants import *; print(f'Metrics: {ALL_METRICS}'); print(f'Offsets: {WINDOW_OFFSETS}'); print(f'Hours: {HOUR_SEQUENCE_CST}')"
python -c "from src.config import PipelineConfig; c = PipelineConfig(); print(c.clob_path)"
```

### Stage 2: Test Numba kernels (unit tests)

```bash
python tests/test_numba_kernels.py
```

Expected: `✅ All 14 kernel tests passed.`

### Stage 3: Test I/O utilities

```bash
python -c "
from src.io_utils import get_day_start_ms, get_hour_boundaries_ms
ds = get_day_start_ms('2024-01-15')
print(f'Day start: {ds}')
h_start, h_end = get_hour_boundaries_ms('2024-01-15', 0)
print(f'Hour 0 (17:00 CST): {h_start} → {h_end}')
print(f'Duration: {h_end - h_start} ms = {(h_end - h_start) / 3600000} hours')
"
```

### Stage 4–7: Generate synthetic data and run full pipeline

```bash
# Generate test data
python -m tests.generate_synthetic_data --products ES --date 2024-01-15 --data-root ./data --num-clob 50000 --num-txn 2000

# Run daily pipeline
python -m src.daily_pipeline --product ES --date 2024-01-15 --data-root ./data

# Or run the full integration test
python tests/test_integration.py
```

### Stage 8–9: Multi-day aggregation (after running daily pipeline for multiple days)

```bash
# Generate data for multiple days
python -m tests.generate_synthetic_data --products ES --date 2024-01-15 --data-root ./data
python -m tests.generate_synthetic_data --products ES --date 2024-01-16 --data-root ./data
python -m tests.generate_synthetic_data --products ES --date 2024-01-17 --data-root ./data

# Run daily pipeline for each day
python -m src.daily_pipeline --product ES --date 2024-01-15 --data-root ./data
python -m src.daily_pipeline --product ES --date 2024-01-16 --data-root ./data
python -m src.daily_pipeline --product ES --date 2024-01-17 --data-root ./data

# Run quarterly aggregation
python -m src.quarterly_pipeline --product ES --date-start 2024-01-15 --date-end 2024-01-17 --data-root ./data
```

---

## Pipeline Flow

```
Phase A  (full day, 3 cols)    →  aggressor + sweep tags per trade
Phase B  (stream by hour)      →  forward-filled ms timeline
Phase C  (Numba parallel)      →  11 metrics per ms slot
Phase D  (Numba parallel)      →  14-offset event windows
Phase E  (NumPy)               →  hourly percentiles (Step 3)
Phase F  (multi-day, Step 4)   →  pooled percentiles + fan charts
```

---

## Production Usage

```bash
# Single product, single day
python -m src.daily_pipeline --product ES --date 2024-01-15 --data-root /data

# All 100 products, single day (sequential)
python -m src.daily_pipeline --product ES --date 2024-01-15 --data-root /data \
    --config config/pipeline_config.yaml --multi

# Quarterly aggregation with fan charts
python -m src.quarterly_pipeline --product ES \
    --date-start 2024-01-02 --date-end 2024-03-29 \
    --data-root /data --period-label Q1_2024
```
