"""
phase_a_load.py
===============
Phase A: Load raw data, interleave by sequence number, infer aggressor
side, and detect book sweeps.

Full-day scan but reads only 3 CLOB columns (seq_num, bid_px1, ask_px1)
for ~1.3 GB memory footprint on a liquid product.

Output: per-transaction aggressor_side and swept_flag arrays, plus
pre-computed ms_index for each transaction.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass

import numpy as np

from . import constants as C
from .config import PipelineConfig
from .io_utils import read_parquet_columns, get_day_start_ms
from .numba_kernels import merge_interleave_indices, infer_aggressor_and_sweep

logger = logging.getLogger(__name__)


@dataclass
class PhaseAResult:
    """Output of Phase A: per-transaction classification arrays."""

    txn_ts_ms: np.ndarray       # int64: absolute epoch ms per trade
    txn_price: np.ndarray       # float64: trade price
    txn_qty: np.ndarray         # float64: trade quantity
    txn_aggressor: np.ndarray   # int8: 1=BUY, -1=SELL, 0=UNKNOWN
    txn_swept: np.ndarray       # int8: 1=swept, 0=not
    txn_ms_index: np.ndarray    # int32: ms offset from day start
    day_start_ms: int           # epoch ms of trading day start

    @property
    def n_trades(self) -> int:
        return self.txn_ts_ms.shape[0]


def run_phase_a(config: PipelineConfig) -> PhaseAResult:
    """
    Execute Phase A:
      1. Read CLOB (3 columns only): seq_num, bid_px1, ask_px1
      2. Read Transactions: seq_num, timestamp_ms, price, qty
      3. Interleave by seq_num
      4. Walk interleaved stream -> aggressor_side, swept_flag
      5. Compute ms_index for each transaction
    """
    t0 = time.perf_counter()
    day_start_ms = get_day_start_ms(config.date)

    # ── Read CLOB (minimal columns) ──────────────────────────────
    logger.info(f"[Phase A] Loading CLOB BBO from {config.clob_path}")
    clob_data = read_parquet_columns(
        config.clob_path,
        columns=C.CLOB_PHASE_A_COLS,
    )

    clob_seq = clob_data[C.CLOB_SEQ_COL].astype(np.int64)
    clob_bid_px1 = clob_data["bid_px1"].astype(np.float64)
    clob_ask_px1 = clob_data["ask_px1"].astype(np.float64)
    logger.info(f"  CLOB: {clob_seq.shape[0]:,} updates loaded")

    # ── Read Transactions ─────────────────────────────────────────
    logger.info(f"[Phase A] Loading transactions from {config.txn_path}")
    txn_data = read_parquet_columns(
        config.txn_path,
        columns=C.TXN_ALL_COLS,
    )

    txn_seq = txn_data[C.TXN_SEQ_COL].astype(np.int64)
    txn_ts_ms = txn_data[C.TXN_TS_COL].astype(np.int64)
    txn_price = txn_data[C.TXN_PRICE_COL].astype(np.float64)
    txn_qty = txn_data[C.TXN_QTY_COL].astype(np.float64)
    logger.info(f"  Transactions: {txn_seq.shape[0]:,} trades loaded")

    # ── Verify sort order ─────────────────────────────────────────
    if clob_seq.shape[0] > 1:
        assert np.all(clob_seq[1:] >= clob_seq[:-1]), \
            "CLOB data must be sorted by seq_num"
    if txn_seq.shape[0] > 1:
        assert np.all(txn_seq[1:] >= txn_seq[:-1]), \
            "Transaction data must be sorted by seq_num"

    # ── Interleave by seq_num ─────────────────────────────────────
    logger.info("[Phase A] Interleaving by seq_num ...")
    merged_source, merged_idx, _ = merge_interleave_indices(clob_seq, txn_seq)
    logger.info(f"  Interleaved: {merged_source.shape[0]:,} records")

    # ── Infer aggressor + detect sweeps ───────────────────────────
    logger.info("[Phase A] Inferring aggressor side & detecting sweeps ...")
    aggressor, swept = infer_aggressor_and_sweep(
        merged_source, merged_idx,
        clob_bid_px1, clob_ask_px1, txn_price,
    )

    n_buy = int(np.sum(aggressor == C.AGGRESSOR_BUY))
    n_sell = int(np.sum(aggressor == C.AGGRESSOR_SELL))
    n_unknown = int(np.sum(aggressor == C.AGGRESSOR_UNKNOWN))
    n_swept = int(np.sum(swept == 1))
    logger.info(f"  Aggressor: BUY={n_buy:,}  SELL={n_sell:,}  UNKNOWN={n_unknown:,}")
    logger.info(f"  Sweeps: {n_swept:,} trades swept the book")

    # ── Compute ms_index per transaction ──────────────────────────
    txn_ms_index = (txn_ts_ms - day_start_ms).astype(np.int32)

    n_outside = int(np.sum((txn_ms_index < 0) | (txn_ms_index >= C.MS_PER_TRADING_DAY)))
    if n_outside > 0:
        logger.warning(f"  {n_outside:,} trades fall outside trading window")

    # ── Free CLOB arrays (no longer needed) ───────────────────────
    del clob_data, clob_seq, clob_bid_px1, clob_ask_px1
    del merged_source, merged_idx

    elapsed = time.perf_counter() - t0
    logger.info(f"[Phase A] Complete in {elapsed:.2f}s")

    return PhaseAResult(
        txn_ts_ms=txn_ts_ms,
        txn_price=txn_price,
        txn_qty=txn_qty,
        txn_aggressor=aggressor,
        txn_swept=swept,
        txn_ms_index=txn_ms_index,
        day_start_ms=day_start_ms,
    )
