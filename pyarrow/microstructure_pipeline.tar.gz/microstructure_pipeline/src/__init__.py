"""
CME Futures Microstructure Analysis Pipeline
=============================================
High-performance CLOB + Transaction processing using PyArrow streaming
and Numba JIT compilation.
"""

__version__ = "0.1.0"
