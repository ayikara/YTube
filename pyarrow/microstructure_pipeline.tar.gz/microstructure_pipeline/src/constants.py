"""
constants.py
============
Central location for all column names, metric definitions, and pipeline
constants. Change column names here if your Parquet schema differs.
"""

from __future__ import annotations

# ─────────────────────────────────────────────────────────────────────
# CLOB (Order Book) Parquet Column Names
# ─────────────────────────────────────────────────────────────────────

CLOB_SEQ_COL = "seq_num"
CLOB_TS_COL = "timestamp_ms"
CLOB_PRODUCT_COL = "product_id"

# Number of book levels available in the data
BOOK_DEPTH = 10

# Generate column names for all 10 levels: bid_px1..bid_px10, etc.
CLOB_BID_PX_COLS = [f"bid_px{i}" for i in range(1, BOOK_DEPTH + 1)]
CLOB_BID_SZ_COLS = [f"bid_sz{i}" for i in range(1, BOOK_DEPTH + 1)]
CLOB_ASK_PX_COLS = [f"ask_px{i}" for i in range(1, BOOK_DEPTH + 1)]
CLOB_ASK_SZ_COLS = [f"ask_sz{i}" for i in range(1, BOOK_DEPTH + 1)]

# All book data columns (40 total: 10 levels × 4 columns)
CLOB_BOOK_COLS = CLOB_BID_PX_COLS + CLOB_BID_SZ_COLS + CLOB_ASK_PX_COLS + CLOB_ASK_SZ_COLS

# Columns needed for Phase A (sweep detection) — minimal read
CLOB_PHASE_A_COLS = [CLOB_SEQ_COL, CLOB_TS_COL, "bid_px1", "ask_px1"]

# All CLOB columns (for Phase B full book read)
CLOB_ALL_COLS = [CLOB_SEQ_COL, CLOB_TS_COL] + CLOB_BOOK_COLS


# ─────────────────────────────────────────────────────────────────────
# Transaction Parquet Column Names
# ─────────────────────────────────────────────────────────────────────

TXN_SEQ_COL = "seq_num"
TXN_TS_COL = "timestamp_ms"
TXN_PRODUCT_COL = "product_id"
TXN_PRICE_COL = "price"
TXN_QTY_COL = "qty"

TXN_ALL_COLS = [TXN_SEQ_COL, TXN_TS_COL, TXN_PRICE_COL, TXN_QTY_COL]


# ─────────────────────────────────────────────────────────────────────
# Trading Day Parameters
# ─────────────────────────────────────────────────────────────────────

# CME Globex: 17:00 CST to 16:00 CST next day = 23 hours
TRADING_HOURS = 23
TRADING_START_HOUR_CST = 17  # 5:00 PM CST
TRADING_END_HOUR_CST = 16    # 4:00 PM CST next day

MS_PER_SECOND = 1_000
MS_PER_MINUTE = 60_000
MS_PER_HOUR = 3_600_000
MS_PER_TRADING_DAY = TRADING_HOURS * MS_PER_HOUR  # 82,800,000

# Hour sequence in CST: 17, 18, 19, 20, 21, 22, 23, 0, 1, ..., 15, 16
HOUR_SEQUENCE_CST = [(TRADING_START_HOUR_CST + i) % 24 for i in range(TRADING_HOURS)]


# ─────────────────────────────────────────────────────────────────────
# Event Window Parameters
# ─────────────────────────────────────────────────────────────────────

# Window offsets relative to event millisecond
WINDOW_OFFSETS = list(range(-5, 9))  # [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8]
NUM_OFFSETS = len(WINDOW_OFFSETS)     # 14
WINDOW_LOOKBACK = 5                   # ms before event
WINDOW_LOOKAHEAD = 8                  # ms after event

# Overlap buffer for hourly streaming (ms beyond hour boundaries)
HOUR_OVERLAP_MS = max(WINDOW_LOOKBACK, WINDOW_LOOKAHEAD) + 2  # 10 ms


# ─────────────────────────────────────────────────────────────────────
# Metric Definitions
# ─────────────────────────────────────────────────────────────────────

# Order book metrics (derived from forward-filled book state)
OB_METRICS = [
    "mid_price",
    "bid_ask_spread",
    "level1_bid_depth",
    "level1_ask_depth",
    "level2_bid_depth",
    "level2_ask_depth",
]

# Transaction metrics (derived from bucketed trades per ms)
TXN_METRICS = [
    "vwap",
    "num_transactions",
    "aggressor_buy_vol",
    "aggressor_sell_vol",
    "swept_book",
]

# All metrics in canonical order
ALL_METRICS = OB_METRICS + TXN_METRICS
NUM_METRICS = len(ALL_METRICS)  # 11

# Metric name to index mapping (for array-based access)
METRIC_INDEX = {name: i for i, name in enumerate(ALL_METRICS)}


# ─────────────────────────────────────────────────────────────────────
# Percentile Levels
# ─────────────────────────────────────────────────────────────────────

PERCENTILE_LEVELS = [5, 25, 50, 75, 95]
PERCENTILE_NAMES = ["p5", "p25", "p50", "p75", "p95"]


# ─────────────────────────────────────────────────────────────────────
# Aggressor Side Codes (int8 for Numba compatibility)
# ─────────────────────────────────────────────────────────────────────

AGGRESSOR_BUY = 1
AGGRESSOR_SELL = -1
AGGRESSOR_UNKNOWN = 0


# ─────────────────────────────────────────────────────────────────────
# Parquet Write Settings
# ─────────────────────────────────────────────────────────────────────

PARQUET_COMPRESSION = "zstd"
PARQUET_COMPRESSION_LEVEL = 3
PARQUET_ROW_GROUP_SIZE = 1_000_000
PARQUET_WRITE_STATISTICS = True
