"""
quarterly_pipeline.py
=====================
Orchestrator for multi-day aggregation (Step 4) and fan chart generation.

Usage:
  python -m src.quarterly_pipeline \
      --product ES --date-start 2024-01-02 --date-end 2024-03-29 \
      --data-root ./data
"""

from __future__ import annotations

import argparse
import gc
import logging
import sys
import time

from .config import PipelineConfig
from .phase_f_aggregate import run_aggregation
from .fan_chart import generate_period_charts

logger = logging.getLogger(__name__)


def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )


def run_quarterly_pipeline(
    config: PipelineConfig,
    date_start: str,
    date_end: str,
    period_label: str | None = None,
    generate_charts: bool = True,
) -> dict:
    """
    Run Step 4 aggregation + fan chart generation for a single product.

    Assumes all daily pipelines (Steps 1-3) have already been run for
    every trading day in the date range.
    """
    t0 = time.perf_counter()

    if period_label is None:
        period_label = f"{date_start}_to_{date_end}"

    logger.info("=" * 60)
    logger.info(f"QUARTERLY PIPELINE: {config.product} / {period_label}")
    logger.info("=" * 60)

    # ── Step 4: Multi-day aggregation ─────────────────────────────
    step4_path = run_aggregation(
        config=config,
        date_start=date_start,
        date_end=date_end,
        period_label=period_label,
    )

    # ── Fan charts ────────────────────────────────────────────────
    chart_paths = []
    if generate_charts:
        logger.info("\n[Charts] Generating fan charts...")
        chart_paths = generate_period_charts(
            config=config,
            step4_path=step4_path,
            period_label=period_label,
        )

    elapsed = time.perf_counter() - t0

    summary = {
        "product": config.product,
        "date_start": date_start,
        "date_end": date_end,
        "step4_path": step4_path,
        "n_charts": len(chart_paths),
        "elapsed_seconds": round(elapsed, 2),
    }

    logger.info(f"\nComplete: {elapsed:.2f}s  |  {len(chart_paths)} charts generated")
    return summary


def run_multi_product_quarterly(
    config: PipelineConfig,
    date_start: str,
    date_end: str,
    period_label: str | None = None,
    generate_charts: bool = True,
) -> list[dict]:
    """Run quarterly pipeline for all products in config.products."""
    summaries = []

    for i, product in enumerate(config.products):
        logger.info(f"\n{'#' * 60}")
        logger.info(f"# Product {i + 1}/{len(config.products)}: {product}")
        logger.info(f"{'#' * 60}\n")

        product_config = PipelineConfig(
            data_root=config.data_root,
            product=product,
            step2_subdir=config.step2_subdir,
            step4_subdir=config.step4_subdir,
            charts_subdir=config.charts_subdir,
        )

        try:
            summary = run_quarterly_pipeline(
                config=product_config,
                date_start=date_start,
                date_end=date_end,
                period_label=period_label,
                generate_charts=generate_charts,
            )
            summaries.append(summary)
        except Exception as e:
            logger.error(f"FAILED: {product}: {e}")
            summaries.append({"product": product, "error": str(e)})

        gc.collect()

    return summaries


# ─────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="CME Microstructure Quarterly Pipeline (Step 4)"
    )
    parser.add_argument("--product", default="ES")
    parser.add_argument("--date-start", required=True)
    parser.add_argument("--date-end", required=True)
    parser.add_argument("--data-root", default="./data")
    parser.add_argument("--period-label", default=None)
    parser.add_argument("--no-charts", action="store_true")
    parser.add_argument("--multi", action="store_true",
                        help="Run for all products in config")
    parser.add_argument("--config", default=None, help="YAML config path")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    setup_logging(verbose=args.verbose)

    if args.config:
        config = PipelineConfig.from_yaml(args.config)
        config.product = args.product
    else:
        config = PipelineConfig(
            data_root=args.data_root,
            product=args.product,
        )

    if args.multi:
        run_multi_product_quarterly(
            config=config,
            date_start=args.date_start,
            date_end=args.date_end,
            period_label=args.period_label,
            generate_charts=not args.no_charts,
        )
    else:
        run_quarterly_pipeline(
            config=config,
            date_start=args.date_start,
            date_end=args.date_end,
            period_label=args.period_label,
            generate_charts=not args.no_charts,
        )


if __name__ == "__main__":
    main()
