"""
fan_chart.py
============
Fan chart visualization for Step 3 (single day) or Step 4 (multi-day)
percentile data.

x-axis:  14 offsets [-5, -4, ..., 0, ..., +8]
bands:   P5-P95 (lightest), P25-P75 (medium), P50 (median line)
One chart per metric per hour per product.

Usage:
  from src.fan_chart import generate_fan_charts
  paths = generate_fan_charts(config, source_path="data/step3/.../date=2024-01-15.parquet")
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import numpy as np

try:
    import matplotlib
    matplotlib.use("Agg")  # non-interactive backend for server use
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

import pyarrow.parquet as pq

from . import constants as C
from .config import PipelineConfig

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# STYLING
# ─────────────────────────────────────────────────────────────────────

OUTER_COLOR = "#4A90D9"     # P5-P95 band
INNER_COLOR = "#2C5F9E"     # P25-P75 band
MEDIAN_COLOR = "#1A3A6E"    # P50 line
EVENT_COLOR = "#D94A4A"     # Transaction marker (offset=0)
OUTER_ALPHA = 0.18
INNER_ALPHA = 0.35

METRIC_LABELS = {
    "mid_price": "Mid Price",
    "bid_ask_spread": "Bid-Ask Spread",
    "level1_bid_depth": "Level 1 Bid Depth (contracts)",
    "level1_ask_depth": "Level 1 Ask Depth (contracts)",
    "level2_bid_depth": "Level 2 Bid Depth (contracts)",
    "level2_ask_depth": "Level 2 Ask Depth (contracts)",
    "vwap": "VWAP",
    "num_transactions": "Number of Transactions",
    "aggressor_buy_vol": "Aggressor Buy Volume",
    "aggressor_sell_vol": "Aggressor Sell Volume",
    "swept_book": "Book Sweep Flag",
}


# ─────────────────────────────────────────────────────────────────────
# MAIN CHART GENERATOR
# ─────────────────────────────────────────────────────────────────────

def generate_fan_charts(
    config: PipelineConfig,
    source_path: str,
    title_suffix: str = "",
    hours: Optional[list[int]] = None,
    metrics: Optional[list[str]] = None,
    output_dir: Optional[str] = None,
    dpi: int = 150,
) -> list[str]:
    """
    Generate fan charts from a Step 3 or Step 4 percentile Parquet file.

    Parameters
    ----------
    source_path : path to Step 3 or Step 4 Parquet file
    title_suffix : text appended to chart title (e.g., "ES / 2024-01-15")
    hours : specific CST hours to plot (default: all hours with data)
    metrics : specific metrics to plot (default: all)
    output_dir : directory for chart PNGs (default: config.charts_dir)
    dpi : image resolution

    Returns
    -------
    List of saved chart file paths.
    """
    if not HAS_MATPLOTLIB:
        logger.warning("matplotlib not installed — skipping fan charts")
        return []

    if not Path(source_path).exists():
        logger.warning(f"Source file not found: {source_path}")
        return []

    # Read percentile data
    table = pq.read_table(source_path)
    logger.info(f"[Fan Charts] Read {table.num_rows:,} rows from {source_path}")

    pct_hour = table.column("hour").to_numpy(zero_copy_only=False)
    pct_offset = table.column("offset").to_numpy(zero_copy_only=False)
    pct_metric = table.column("metric").to_pylist()
    pct_p5 = table.column("p5").to_numpy(zero_copy_only=False)
    pct_p25 = table.column("p25").to_numpy(zero_copy_only=False)
    pct_p50 = table.column("p50").to_numpy(zero_copy_only=False)
    pct_p75 = table.column("p75").to_numpy(zero_copy_only=False)
    pct_p95 = table.column("p95").to_numpy(zero_copy_only=False)
    pct_n = table.column("n_events").to_numpy(zero_copy_only=False)

    # Determine what to plot
    if hours is None:
        unique_hours = sorted(set(pct_hour.tolist()))
    else:
        unique_hours = hours

    if metrics is None:
        metric_list = C.ALL_METRICS
    else:
        metric_list = metrics

    # Output directory
    if output_dir is None:
        output_dir = config.charts_dir

    offsets_array = np.array(C.WINDOW_OFFSETS)
    saved_paths: list[str] = []

    for hour in unique_hours:
        for metric_name in metric_list:
            # Filter to this hour + metric
            mask = np.array([
                (h == hour and m == metric_name)
                for h, m in zip(pct_hour.tolist(), pct_metric)
            ])

            if not np.any(mask):
                continue

            row_offsets = pct_offset[mask]
            p5 = pct_p5[mask]
            p25 = pct_p25[mask]
            p50 = pct_p50[mask]
            p75 = pct_p75[mask]
            p95 = pct_p95[mask]
            n_ev = pct_n[mask]

            # Sort by offset
            sort_idx = np.argsort(row_offsets)
            x = row_offsets[sort_idx]
            p5 = p5[sort_idx]
            p25 = p25[sort_idx]
            p50 = p50[sort_idx]
            p75 = p75[sort_idx]
            p95 = p95[sort_idx]
            n_ev_sorted = n_ev[sort_idx]

            # Skip if all NaN
            if np.all(np.isnan(p50)):
                continue

            total_events = int(np.nanmax(n_ev_sorted)) if len(n_ev_sorted) > 0 else 0

            # ── Plot ──────────────────────────────────────────────
            fig, ax = plt.subplots(figsize=(11, 5.5))

            # Fan bands
            ax.fill_between(
                x, p5, p95,
                alpha=OUTER_ALPHA, color=OUTER_COLOR, label="P5–P95",
            )
            ax.fill_between(
                x, p25, p75,
                alpha=INNER_ALPHA, color=INNER_COLOR, label="P25–P75",
            )

            # Median line
            ax.plot(
                x, p50,
                color=MEDIAN_COLOR, linewidth=2.0,
                label="P50 (Median)", marker="o", markersize=4, zorder=5,
            )

            # Transaction event line (offset = 0)
            ax.axvline(
                x=0, color=EVENT_COLOR, linestyle="--", linewidth=1.2,
                alpha=0.6, label="Transaction (t=0)",
            )

            # Labels
            label = METRIC_LABELS.get(metric_name, metric_name)
            title = f"{label}"
            if title_suffix:
                title += f" — {title_suffix}"
            title += f"\nHour {hour:02d}:00 CST  |  {total_events:,} events"

            ax.set_title(title, fontsize=12, fontweight="bold")
            ax.set_xlabel("Offset from transaction (ms)", fontsize=10)
            ax.set_ylabel(label, fontsize=10)
            ax.legend(loc="upper left", fontsize=8, framealpha=0.9)
            ax.grid(True, alpha=0.3, linestyle="-")
            ax.set_xticks(offsets_array)
            ax.xaxis.set_minor_locator(ticker.NullLocator())

            # Tight layout
            fig.tight_layout()

            # ── Save ──────────────────────────────────────────────
            chart_dir = Path(output_dir) / f"hour={hour:02d}"
            chart_dir.mkdir(parents=True, exist_ok=True)

            chart_path = chart_dir / f"{metric_name}.png"
            fig.savefig(str(chart_path), dpi=dpi, bbox_inches="tight")
            plt.close(fig)

            saved_paths.append(str(chart_path))

    logger.info(f"  Generated {len(saved_paths)} fan charts in {output_dir}")
    return saved_paths


# ─────────────────────────────────────────────────────────────────────
# CONVENIENCE: Generate charts for a single day
# ─────────────────────────────────────────────────────────────────────

def generate_daily_charts(config: PipelineConfig) -> list[str]:
    """Generate fan charts from a single day's Step 3 output."""
    return generate_fan_charts(
        config=config,
        source_path=config.step3_output_path,
        title_suffix=f"{config.product} / {config.date}",
    )


def generate_period_charts(
    config: PipelineConfig,
    step4_path: str,
    period_label: str,
) -> list[str]:
    """Generate fan charts from a multi-day Step 4 output."""
    return generate_fan_charts(
        config=config,
        source_path=step4_path,
        title_suffix=f"{config.product} / {period_label}",
        output_dir=str(Path(config.charts_dir) / period_label),
    )
