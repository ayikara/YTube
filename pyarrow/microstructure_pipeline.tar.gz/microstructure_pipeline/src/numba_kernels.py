"""
numba_kernels.py
================
All Numba JIT-compiled kernels for the pipeline. These operate exclusively
on flat NumPy arrays — no Python objects, no strings, no dicts in the hot path.

Kernel inventory:
  Sequential (stateful scans):
    - merge_interleave_indices    : merge CLOB + TXN by seq_num
    - infer_aggressor_and_sweep   : walk interleaved stream, tag trades
    - map_last_per_ms             : find last CLOB update per ms slot
    - forward_fill_1d             : fill gaps in ms timeline
    - bucket_transactions         : aggregate trades into ms slots

  Parallel (independent per element):
    - compute_book_metrics        : mid, spread, depth from book state
    - gather_event_windows        : extract 14-offset windows per event
"""

from __future__ import annotations

import numba as nb
import numpy as np


# ─────────────────────────────────────────────────────────────────────
# 1.  MERGE INTERLEAVE BY SEQUENCE NUMBER
# ─────────────────────────────────────────────────────────────────────

@nb.njit(cache=True)
def merge_interleave_indices(
    clob_seq: np.ndarray,  # int64, sorted ascending
    txn_seq: np.ndarray,   # int64, sorted ascending
) -> tuple:
    """
    Merge two sorted seq_num arrays and produce:
      - merged_source: int8 array (0=CLOB, 1=TXN)
      - merged_idx:    int64 array (index into original CLOB or TXN array)

    Both outputs have length len(clob_seq) + len(txn_seq).
    Result is sorted by seq_num. When seq_nums are equal,
    CLOB comes first (book state before the trade at that seq).

    Returns: (merged_source, merged_idx, merged_seq)
    """
    nc = clob_seq.shape[0]
    nt = txn_seq.shape[0]
    total = nc + nt

    merged_source = np.empty(total, dtype=np.int8)
    merged_idx = np.empty(total, dtype=np.int64)
    merged_seq = np.empty(total, dtype=np.int64)

    i = 0  # CLOB pointer
    j = 0  # TXN pointer
    k = 0  # output pointer

    while i < nc and j < nt:
        if clob_seq[i] <= txn_seq[j]:
            merged_source[k] = 0
            merged_idx[k] = i
            merged_seq[k] = clob_seq[i]
            i += 1
        else:
            merged_source[k] = 1
            merged_idx[k] = j
            merged_seq[k] = txn_seq[j]
            j += 1
        k += 1

    while i < nc:
        merged_source[k] = 0
        merged_idx[k] = i
        merged_seq[k] = clob_seq[i]
        i += 1
        k += 1

    while j < nt:
        merged_source[k] = 1
        merged_idx[k] = j
        merged_seq[k] = txn_seq[j]
        j += 1
        k += 1

    return merged_source, merged_idx, merged_seq


# ─────────────────────────────────────────────────────────────────────
# 2.  INFER AGGRESSOR SIDE AND DETECT SWEEPS
# ─────────────────────────────────────────────────────────────────────

@nb.njit(cache=True)
def infer_aggressor_and_sweep(
    merged_source: np.ndarray,  # int8: 0=CLOB, 1=TXN
    merged_idx: np.ndarray,     # int64: index into source array
    clob_bid_px1: np.ndarray,   # float64: best bid from CLOB
    clob_ask_px1: np.ndarray,   # float64: best ask from CLOB
    txn_price: np.ndarray,      # float64: trade prices
) -> tuple:
    """
    Walk the interleaved stream. For each transaction, compare its
    price against the most recent book state to determine:
      - aggressor side: BUY(1), SELL(-1), UNKNOWN(0)
      - sweep flag: True if trade price is strictly beyond BBO

    Returns:
      aggressor_side: int8 array, length = len(txn_price)
      swept_flag:     int8 array, length = len(txn_price)
    """
    n_txn = txn_price.shape[0]
    aggressor_side = np.zeros(n_txn, dtype=np.int8)
    swept_flag = np.zeros(n_txn, dtype=np.int8)

    running_best_bid = np.nan
    running_best_ask = np.nan

    total = merged_source.shape[0]

    for k in range(total):
        if merged_source[k] == 0:
            idx = merged_idx[k]
            running_best_bid = clob_bid_px1[idx]
            running_best_ask = clob_ask_px1[idx]
        else:
            tidx = merged_idx[k]
            price = txn_price[tidx]

            if np.isnan(running_best_bid) or np.isnan(running_best_ask):
                aggressor_side[tidx] = 0
                swept_flag[tidx] = 0
                continue

            if price >= running_best_ask:
                aggressor_side[tidx] = 1   # BUY
            elif price <= running_best_bid:
                aggressor_side[tidx] = -1  # SELL
            else:
                aggressor_side[tidx] = 0   # UNKNOWN

            if price > running_best_ask or price < running_best_bid:
                swept_flag[tidx] = 1

    return aggressor_side, swept_flag


# ─────────────────────────────────────────────────────────────────────
# 3.  MAP CLOB UPDATES TO MS SLOTS (last per ms)
# ─────────────────────────────────────────────────────────────────────

@nb.njit(cache=True)
def map_last_per_ms(
    clob_ts_ms: np.ndarray,     # int64: absolute epoch ms
    day_start_ms: np.int64,
    n_ms_slots: np.int64,
) -> np.ndarray:
    """
    For each millisecond slot, find the INDEX of the last CLOB update
    that falls in that slot.  Value -1 means no update in that slot.
    Assumes clob_ts_ms is sorted ascending.
    """
    slot_last_idx = np.full(n_ms_slots, -1, dtype=np.int64)

    for i in range(clob_ts_ms.shape[0]):
        ms_offset = clob_ts_ms[i] - day_start_ms
        if 0 <= ms_offset < n_ms_slots:
            slot_last_idx[ms_offset] = i

    return slot_last_idx


# ─────────────────────────────────────────────────────────────────────
# 4.  FORWARD FILL ORDER BOOK
# ─────────────────────────────────────────────────────────────────────

@nb.njit(cache=True)
def forward_fill_1d(
    source: np.ndarray,         # float64: raw CLOB column values
    slot_last_idx: np.ndarray,  # int64: index of last update per ms slot
    n_slots: np.int64,
    initial_value: np.float64,
) -> np.ndarray:
    """
    Build a contiguous array of n_slots elements by:
      - Using source[slot_last_idx[t]] if an update exists at slot t
      - Otherwise carrying forward the previous value
    Called once per book column (bid_px1, bid_sz1, etc.).
    """
    out = np.empty(n_slots, dtype=np.float64)
    current = initial_value

    for t in range(n_slots):
        idx = slot_last_idx[t]
        if idx >= 0:
            current = source[idx]
        out[t] = current

    return out


# ─────────────────────────────────────────────────────────────────────
# 5.  BUCKET TRANSACTIONS INTO MS SLOTS
# ─────────────────────────────────────────────────────────────────────

@nb.njit(cache=True)
def bucket_transactions(
    txn_ts_ms: np.ndarray,       # int64
    txn_price: np.ndarray,       # float64
    txn_qty: np.ndarray,         # float64
    txn_aggressor: np.ndarray,   # int8: 1=BUY, -1=SELL, 0=UNKNOWN
    txn_swept: np.ndarray,       # int8
    day_start_ms: np.int64,
    n_ms_slots: np.int64,
) -> tuple:
    """
    Aggregate all transactions into millisecond buckets.
    Returns 5 arrays of length n_ms_slots:
      vwap, num_transactions, aggressor_buy_vol,
      aggressor_sell_vol, swept_book
    """
    vwap = np.full(n_ms_slots, np.nan, dtype=np.float64)
    num_txn = np.zeros(n_ms_slots, dtype=np.int32)
    buy_vol = np.zeros(n_ms_slots, dtype=np.float64)
    sell_vol = np.zeros(n_ms_slots, dtype=np.float64)
    swept = np.zeros(n_ms_slots, dtype=np.int8)

    sum_pv = np.zeros(n_ms_slots, dtype=np.float64)
    sum_v = np.zeros(n_ms_slots, dtype=np.float64)

    for i in range(txn_ts_ms.shape[0]):
        ms_offset = txn_ts_ms[i] - day_start_ms
        if ms_offset < 0 or ms_offset >= n_ms_slots:
            continue

        t = ms_offset
        num_txn[t] += 1
        sum_pv[t] += txn_price[i] * txn_qty[i]
        sum_v[t] += txn_qty[i]

        if txn_aggressor[i] == 1:
            buy_vol[t] += txn_qty[i]
        elif txn_aggressor[i] == -1:
            sell_vol[t] += txn_qty[i]

        if txn_swept[i] == 1:
            swept[t] = 1

    for t in range(n_ms_slots):
        if sum_v[t] > 0.0:
            vwap[t] = sum_pv[t] / sum_v[t]

    return vwap, num_txn, buy_vol, sell_vol, swept


# ─────────────────────────────────────────────────────────────────────
# 6.  COMPUTE ORDER BOOK METRICS (parallel)
# ─────────────────────────────────────────────────────────────────────

@nb.njit(parallel=True, cache=True)
def compute_book_metrics(
    bid_px1: np.ndarray,
    ask_px1: np.ndarray,
    bid_sz1: np.ndarray,
    ask_sz1: np.ndarray,
    bid_sz2: np.ndarray,
    ask_sz2: np.ndarray,
) -> tuple:
    """
    Compute order book metrics for all ms slots.
    Returns: (mid_price, bid_ask_spread, l1_bid_depth, l1_ask_depth,
              l2_bid_depth, l2_ask_depth)
    """
    n = bid_px1.shape[0]
    mid = np.empty(n, dtype=np.float64)
    spread = np.empty(n, dtype=np.float64)

    for i in nb.prange(n):
        mid[i] = 0.5 * (bid_px1[i] + ask_px1[i])
        spread[i] = ask_px1[i] - bid_px1[i]

    return mid, spread, bid_sz1, ask_sz1, bid_sz2, ask_sz2


# ─────────────────────────────────────────────────────────────────────
# 7.  GATHER EVENT WINDOWS (parallel)
# ─────────────────────────────────────────────────────────────────────

@nb.njit(parallel=True, cache=True)
def gather_event_windows(
    event_indices: np.ndarray,  # int64: ms indices where num_txn > 0
    metric_arrays: np.ndarray,  # float64, shape (n_metrics, n_ms_slots)
    offsets: np.ndarray,        # int64: [-5, -4, ..., 0, ..., +8]
    n_ms_slots: np.int64,
) -> np.ndarray:
    """
    For each event, gather metric values at each offset.
    Returns: float64 array of shape (n_events, n_offsets, n_metrics)
    Out-of-bounds offsets are NaN.
    """
    n_events = event_indices.shape[0]
    n_offsets = offsets.shape[0]
    n_metrics = metric_arrays.shape[0]

    windows = np.full((n_events, n_offsets, n_metrics), np.nan, dtype=np.float64)

    for e in nb.prange(n_events):
        t = event_indices[e]
        for k in range(n_offsets):
            src = t + offsets[k]
            if 0 <= src < n_ms_slots:
                for m in range(n_metrics):
                    windows[e, k, m] = metric_arrays[m, src]

    return windows


# ─────────────────────────────────────────────────────────────────────
# 8.  WARMUP
# ─────────────────────────────────────────────────────────────────────

def warmup_kernels() -> None:
    """Pre-compile all kernels with tiny dummy arrays."""
    seq3 = np.array([1, 2, 3], dtype=np.int64)
    f3 = np.array([1.0, 2.0, 3.0], dtype=np.float64)
    i3 = np.array([1, 0, 1], dtype=np.int8)

    merge_interleave_indices(seq3, seq3)

    src = np.array([0, 1, 0, 1, 0, 1], dtype=np.int8)
    idx = np.array([0, 0, 1, 1, 2, 2], dtype=np.int64)
    infer_aggressor_and_sweep(src, idx, f3, f3, f3)

    ts = np.array([100, 101, 102], dtype=np.int64)
    map_last_per_ms(ts, np.int64(100), np.int64(10))

    slot_idx = np.array([0, -1, 1, -1, 2], dtype=np.int64)
    forward_fill_1d(f3, slot_idx, np.int64(5), np.float64(0.0))

    bucket_transactions(ts, f3, f3, i3, i3, np.int64(100), np.int64(10))

    compute_book_metrics(f3, f3, f3, f3, f3, f3)

    events = np.array([5], dtype=np.int64)
    metrics = np.ones((2, 20), dtype=np.float64)
    offsets = np.array([-1, 0, 1], dtype=np.int64)
    gather_event_windows(events, metrics, offsets, np.int64(20))

    print("  [warmup] All Numba kernels compiled and cached.")
