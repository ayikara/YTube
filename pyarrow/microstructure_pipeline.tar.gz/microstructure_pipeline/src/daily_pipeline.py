"""
daily_pipeline.py
=================
Orchestrator for a single product, single day.
Runs Phases A through E in sequence, writes Step 2 and Step 3 outputs.

Usage:
  python -m src.daily_pipeline --product ES --date 2024-01-15 --data-root ./data
"""

from __future__ import annotations

import argparse
import gc
import logging
import sys
import time

from .config import PipelineConfig
from .numba_kernels import warmup_kernels
from .phase_a_load import run_phase_a
from .phase_bcd_process import run_phases_bcd
from .phase_e_percentiles import compute_hourly_percentiles, build_step2_table
from .io_utils import write_parquet

logger = logging.getLogger(__name__)


def setup_logging(verbose: bool = False) -> None:
    """Configure logging for the pipeline."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )


def run_daily_pipeline(config: PipelineConfig) -> dict:
    """
    Execute the full daily pipeline for a single product + date.

    Steps:
      1. Warmup Numba kernels
      2. Phase A: Load, interleave, sweep detection
      3. Phase B-D: Hourly streaming — timeline, metrics, windows
      4. Phase E: Build Step 2 table + compute Step 3 percentiles
      5. Write outputs to Parquet

    Returns: dict with summary statistics
    """
    t_total = time.perf_counter()
    logger.info("=" * 60)
    logger.info(f"DAILY PIPELINE: product={config.product}  date={config.date}")
    logger.info("=" * 60)

    # Ensure output directories exist
    config.ensure_output_dirs()

    # ── 1. Warmup ─────────────────────────────────────────────────
    logger.info("[Warmup] Compiling Numba kernels ...")
    warmup_kernels()

    # ── 2. Phase A ────────────────────────────────────────────────
    phase_a_result = run_phase_a(config)

    # ── 3. Phase B-D ──────────────────────────────────────────────
    hour_results = run_phases_bcd(config, phase_a_result)

    # ── 4. Phase E: Build outputs ─────────────────────────────────
    # Step 2: Event windows table
    step2_table = build_step2_table(hour_results)

    # Step 3: Hourly percentiles
    step3_table = compute_hourly_percentiles(hour_results)

    # ── 5. Write Parquet outputs ──────────────────────────────────
    logger.info("[Write] Saving Step 2 (event windows) ...")
    write_parquet(step2_table, config.step2_output_path, config)

    logger.info("[Write] Saving Step 3 (hourly percentiles) ...")
    write_parquet(step3_table, config.step3_output_path, config)

    # ── Summary ───────────────────────────────────────────────────
    total_events = sum(hr.n_events for hr in hour_results)
    elapsed = time.perf_counter() - t_total

    summary = {
        "product": config.product,
        "date": config.date,
        "n_trades": phase_a_result.n_trades,
        "n_events": total_events,
        "step2_rows": step2_table.num_rows,
        "step3_rows": step3_table.num_rows,
        "elapsed_seconds": round(elapsed, 2),
    }

    logger.info("=" * 60)
    logger.info(f"COMPLETE: {config.product} / {config.date}")
    logger.info(f"  Trades: {summary['n_trades']:,}")
    logger.info(f"  Events (ms with trades): {summary['n_events']:,}")
    logger.info(f"  Step 2 rows: {summary['step2_rows']:,}")
    logger.info(f"  Step 3 rows: {summary['step3_rows']:,}")
    logger.info(f"  Total time: {elapsed:.2f}s")
    logger.info("=" * 60)

    # Free memory
    del phase_a_result, hour_results, step2_table, step3_table
    gc.collect()

    return summary


def run_multi_product(config: PipelineConfig) -> list[dict]:
    """
    Run the daily pipeline for all products in config.products.
    Processes sequentially, freeing memory between products.
    """
    summaries = []

    for i, product in enumerate(config.products):
        logger.info(f"\n{'#' * 60}")
        logger.info(f"# Product {i + 1}/{len(config.products)}: {product}")
        logger.info(f"{'#' * 60}\n")

        # Create a product-specific config
        product_config = PipelineConfig(
            data_root=config.data_root,
            clob_subdir=config.clob_subdir,
            txn_subdir=config.txn_subdir,
            step1_subdir=config.step1_subdir,
            step2_subdir=config.step2_subdir,
            step3_subdir=config.step3_subdir,
            step4_subdir=config.step4_subdir,
            charts_subdir=config.charts_subdir,
            product=product,
            date=config.date,
            write_step1=config.write_step1,
            batch_size=config.batch_size,
            compression=config.compression,
            compression_level=config.compression_level,
            row_group_size=config.row_group_size,
        )

        try:
            summary = run_daily_pipeline(product_config)
            summaries.append(summary)
        except Exception as e:
            logger.error(f"FAILED: {product} / {config.date}: {e}")
            summaries.append({
                "product": product,
                "date": config.date,
                "error": str(e),
            })

        gc.collect()

    # Print final summary
    logger.info(f"\n{'=' * 60}")
    logger.info("MULTI-PRODUCT SUMMARY")
    logger.info(f"{'=' * 60}")
    for s in summaries:
        if "error" in s:
            logger.info(f"  {s['product']}: FAILED — {s['error']}")
        else:
            logger.info(f"  {s['product']}: {s['n_trades']:,} trades, "
                        f"{s['n_events']:,} events, {s['elapsed_seconds']}s")

    return summaries


# ─────────────────────────────────────────────────────────────────────
# CLI ENTRY POINT
# ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="CME Microstructure Daily Pipeline"
    )
    parser.add_argument("--product", default="ES",
                        help="Product symbol (e.g., ES, NQ, CL)")
    parser.add_argument("--date", required=True,
                        help="Trading date (YYYY-MM-DD)")
    parser.add_argument("--data-root", default="./data",
                        help="Root data directory")
    parser.add_argument("--config", default=None,
                        help="Path to YAML config file (overrides other args)")
    parser.add_argument("--write-step1", action="store_true",
                        help="Write optional Step 1 output (82.8M rows)")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Enable debug logging")
    parser.add_argument("--multi", action="store_true",
                        help="Run all products in config")
    args = parser.parse_args()

    setup_logging(verbose=args.verbose)

    if args.config:
        config = PipelineConfig.from_yaml(args.config)
        # Override with CLI args if provided
        if args.date:
            config.date = args.date
        if args.product != "ES":  # non-default
            config.product = args.product
    else:
        config = PipelineConfig(
            data_root=args.data_root,
            product=args.product,
            date=args.date,
            write_step1=args.write_step1,
        )

    if args.multi:
        run_multi_product(config)
    else:
        run_daily_pipeline(config)


if __name__ == "__main__":
    main()
