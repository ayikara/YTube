"""
phase_f_aggregate.py
====================
Phase F: Multi-day aggregation (Step 4).

Reads Step 2 event-window Parquet files across a date range,
pools all events by (hour, offset, metric), and recomputes
percentiles over the combined data.

Usage:
  from src.phase_f_aggregate import run_aggregation
  run_aggregation(config, date_start="2024-01-02", date_end="2024-03-29")
"""

from __future__ import annotations

import gc
import logging
import time
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from . import constants as C
from .config import PipelineConfig
from .io_utils import write_parquet

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# Step 4 Parquet schema (extends Step 3 with multi-day metadata)
# ─────────────────────────────────────────────────────────────────────

STEP4_SCHEMA = pa.schema([
    ("hour", pa.int8()),
    ("offset", pa.int8()),
    ("metric", pa.string()),
    ("p5", pa.float64()),
    ("p25", pa.float64()),
    ("p50", pa.float64()),
    ("p75", pa.float64()),
    ("p95", pa.float64()),
    ("n_events", pa.int32()),
    ("n_days", pa.int16()),
    ("date_start", pa.string()),
    ("date_end", pa.string()),
])


# ─────────────────────────────────────────────────────────────────────
# HELPER: Generate trading dates (weekdays only)
# ─────────────────────────────────────────────────────────────────────

def trading_dates(date_start: str, date_end: str) -> list[str]:
    """Generate all weekday dates in a range (approximate trading days)."""
    start = datetime.strptime(date_start, "%Y-%m-%d")
    end = datetime.strptime(date_end, "%Y-%m-%d")
    dates = []
    current = start
    while current <= end:
        if current.weekday() < 5:  # Mon-Fri
            dates.append(current.strftime("%Y-%m-%d"))
        current += timedelta(days=1)
    return dates


# ─────────────────────────────────────────────────────────────────────
# MAIN AGGREGATION
# ─────────────────────────────────────────────────────────────────────

def run_aggregation(
    config: PipelineConfig,
    date_start: str,
    date_end: str,
    period_label: str | None = None,
) -> str:
    """
    Aggregate Step 2 windows across multiple days for a single product.

    Reads each day's Step 2 Parquet, pools by (hour, offset, metric),
    and computes percentiles over the pooled data.

    Returns the output file path.
    """
    t0 = time.perf_counter()
    product = config.product

    if period_label is None:
        period_label = f"{date_start}_to_{date_end}"

    logger.info("=" * 60)
    logger.info(f"Step 4 Aggregation: {product} / {date_start} → {date_end}")
    logger.info("=" * 60)

    dates = trading_dates(date_start, date_end)
    logger.info(f"  Trading dates in range: {len(dates)}")

    # ── Build accumulator ─────────────────────────────────────────
    # Dict key: (hour, offset_index, metric_index) → list of values
    # We use lists and convert to arrays for percentile computation.
    accum: dict[tuple[int, int, int], list[float]] = {}
    for h in C.HOUR_SEQUENCE_CST:
        for k in range(C.NUM_OFFSETS):
            for m in range(C.NUM_METRICS):
                accum[(h, k, m)] = []

    n_days_loaded = 0
    n_days_missing = 0

    # ── Read each day's Step 2 file ───────────────────────────────
    for date in dates:
        # Build Step 2 path for this date
        step2_path = (
            f"{config.data_root}/{config.step2_subdir}"
            f"/product={product}/date={date}.parquet"
        )

        if not Path(step2_path).exists():
            logger.debug(f"    SKIP {date}: file not found")
            n_days_missing += 1
            continue

        table = pq.read_table(step2_path)
        if table.num_rows == 0:
            n_days_loaded += 1
            continue

        # Extract columns as numpy
        hour_col = table.column("hour").to_numpy(zero_copy_only=False)
        offset_col = table.column("offset").to_numpy(zero_copy_only=False)

        # Build offset-to-index mapping
        offset_to_idx = {off: idx for idx, off in enumerate(C.WINDOW_OFFSETS)}

        # Extract all metric columns
        metric_cols = {}
        for m_name in C.ALL_METRICS:
            metric_cols[m_name] = table.column(m_name).to_numpy(zero_copy_only=False)

        # Accumulate values into buckets
        for row_idx in range(table.num_rows):
            h = int(hour_col[row_idx])
            off = int(offset_col[row_idx])
            k = offset_to_idx.get(off)
            if k is None:
                continue

            for m, m_name in enumerate(C.ALL_METRICS):
                val = metric_cols[m_name][row_idx]
                if not np.isnan(val):
                    accum[(h, k, m)].append(val)

        n_days_loaded += 1
        del table
        gc.collect()

        if n_days_loaded % 10 == 0:
            logger.info(f"    Loaded {n_days_loaded}/{len(dates)} days...")

    logger.info(f"  Loaded: {n_days_loaded} days  |  Missing: {n_days_missing} days")

    # ── Compute percentiles ───────────────────────────────────────
    logger.info("  Computing pooled percentiles...")

    percentile_levels = np.array(C.PERCENTILE_LEVELS, dtype=np.float64)

    rows_hour = []
    rows_offset = []
    rows_metric = []
    rows_p5 = []
    rows_p25 = []
    rows_p50 = []
    rows_p75 = []
    rows_p95 = []
    rows_n = []

    for h in C.HOUR_SEQUENCE_CST:
        for k, offset_val in enumerate(C.WINDOW_OFFSETS):
            for m, metric_name in enumerate(C.ALL_METRICS):
                values = accum[(h, k, m)]

                rows_hour.append(h)
                rows_offset.append(offset_val)
                rows_metric.append(metric_name)
                rows_n.append(len(values))

                if len(values) > 0:
                    arr = np.array(values, dtype=np.float64)
                    pcts = np.percentile(arr, percentile_levels)
                    rows_p5.append(float(pcts[0]))
                    rows_p25.append(float(pcts[1]))
                    rows_p50.append(float(pcts[2]))
                    rows_p75.append(float(pcts[3]))
                    rows_p95.append(float(pcts[4]))
                else:
                    rows_p5.append(np.nan)
                    rows_p25.append(np.nan)
                    rows_p50.append(np.nan)
                    rows_p75.append(np.nan)
                    rows_p95.append(np.nan)

    # ── Build and write output table ──────────────────────────────
    n_rows = len(rows_hour)

    table = pa.table({
        "hour": pa.array(rows_hour, type=pa.int8()),
        "offset": pa.array(rows_offset, type=pa.int8()),
        "metric": pa.array(rows_metric, type=pa.string()),
        "p5": pa.array(rows_p5, type=pa.float64()),
        "p25": pa.array(rows_p25, type=pa.float64()),
        "p50": pa.array(rows_p50, type=pa.float64()),
        "p75": pa.array(rows_p75, type=pa.float64()),
        "p95": pa.array(rows_p95, type=pa.float64()),
        "n_events": pa.array(rows_n, type=pa.int32()),
        "n_days": pa.array([n_days_loaded] * n_rows, type=pa.int16()),
        "date_start": pa.array([date_start] * n_rows, type=pa.string()),
        "date_end": pa.array([date_end] * n_rows, type=pa.string()),
    }, schema=STEP4_SCHEMA)

    # Output path
    output_path = (
        f"{config.data_root}/{config.step4_subdir}"
        f"/product={product}/{period_label}.parquet"
    )

    write_parquet(table, output_path, config)

    elapsed = time.perf_counter() - t0
    total_events = sum(rows_n)

    logger.info(f"  Step 4 written: {output_path}")
    logger.info(f"  Rows: {table.num_rows:,}  |  Total pooled events: {total_events:,}")
    logger.info(f"  Elapsed: {elapsed:.2f}s")

    return output_path
