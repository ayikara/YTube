"""
config.py
=========
Pipeline configuration dataclass. Can be loaded from YAML or constructed
directly in code.
"""

from __future__ import annotations

import yaml
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from . import constants as C


@dataclass
class PipelineConfig:
    """Configuration for a single pipeline run."""

    # ── Data paths ────────────────────────────────────────────────
    data_root: str = "./data"

    # Subdirectories under data_root (Hive-partitioned)
    clob_subdir: str = "raw/clob"
    txn_subdir: str = "raw/transactions"
    step1_subdir: str = "step1"
    step2_subdir: str = "step2"
    step3_subdir: str = "step3"
    step4_subdir: str = "step4"
    charts_subdir: str = "charts"

    # ── Run parameters ────────────────────────────────────────────
    product: str = "ES"
    date: str = "2024-01-15"  # YYYY-MM-DD

    # ── Processing options ────────────────────────────────────────
    write_step1: bool = False  # Optionally materialise 82.8M-row Step 1
    batch_size: int = 500_000  # PyArrow scanner batch size

    # ── Parquet settings ──────────────────────────────────────────
    compression: str = C.PARQUET_COMPRESSION
    compression_level: int = C.PARQUET_COMPRESSION_LEVEL
    row_group_size: int = C.PARQUET_ROW_GROUP_SIZE

    # ── Products list (for multi-product runs) ────────────────────
    products: list[str] = field(default_factory=lambda: ["ES"])

    # ── Date range (for multi-day / quarterly runs) ───────────────
    date_start: Optional[str] = None
    date_end: Optional[str] = None

    # ── Derived paths (computed) ──────────────────────────────────

    @property
    def clob_path(self) -> str:
        return f"{self.data_root}/{self.clob_subdir}/date={self.date}/product={self.product}"

    @property
    def txn_path(self) -> str:
        return f"{self.data_root}/{self.txn_subdir}/date={self.date}/product={self.product}"

    @property
    def step1_output_path(self) -> str:
        return f"{self.data_root}/{self.step1_subdir}/product={self.product}/date={self.date}.parquet"

    @property
    def step2_output_path(self) -> str:
        return f"{self.data_root}/{self.step2_subdir}/product={self.product}/date={self.date}.parquet"

    @property
    def step3_output_path(self) -> str:
        return f"{self.data_root}/{self.step3_subdir}/product={self.product}/date={self.date}.parquet"

    @property
    def step4_output_path(self) -> str:
        period = f"{self.date_start}_to_{self.date_end}" if self.date_start else "single"
        return f"{self.data_root}/{self.step4_subdir}/product={self.product}/{period}.parquet"

    @property
    def charts_dir(self) -> str:
        return f"{self.data_root}/{self.charts_subdir}/product={self.product}"

    def ensure_output_dirs(self) -> None:
        """Create output directories if they don't exist."""
        for path_str in [
            self.step2_output_path,
            self.step3_output_path,
        ]:
            Path(path_str).parent.mkdir(parents=True, exist_ok=True)

        if self.write_step1:
            Path(self.step1_output_path).parent.mkdir(parents=True, exist_ok=True)

    @classmethod
    def from_yaml(cls, yaml_path: str) -> "PipelineConfig":
        """Load configuration from a YAML file."""
        with open(yaml_path, "r") as f:
            data = yaml.safe_load(f)
        return cls(**data)

    def to_yaml(self, yaml_path: str) -> None:
        """Save configuration to a YAML file."""
        from dataclasses import asdict

        with open(yaml_path, "w") as f:
            yaml.dump(asdict(self), f, default_flow_style=False, sort_keys=False)
