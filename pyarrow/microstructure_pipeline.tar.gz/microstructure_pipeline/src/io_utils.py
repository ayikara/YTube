"""
io_utils.py
===========
PyArrow I/O utilities for reading/writing Parquet files.
Handles both local filesystem and GCS (Phase II).

Key functions:
  - read_parquet_columns   : Read specific columns from a partition directory
  - stream_parquet_batches : Stream batches with timestamp filtering
  - write_parquet          : Write a PyArrow Table with standard settings
  - get_day_start_ms       : Compute epoch ms for trading day start
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Iterator, Optional

import numpy as np
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.dataset as ds
import pyarrow.parquet as pq

from . import constants as C
from .config import PipelineConfig

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# TIMESTAMP UTILITIES
# ─────────────────────────────────────────────────────────────────────

def get_day_start_ms(date_str: str) -> int:
    """
    Compute epoch milliseconds for the start of the trading day.

    Trading day starts at 17:00 CST on the PREVIOUS calendar day.
    For date_str="2024-01-15", trading starts at 2024-01-14 17:00 CST.

    CST = UTC-6.
    """
    date = datetime.strptime(date_str, "%Y-%m-%d")

    # Trading day "2024-01-15" starts the evening before
    prev_day = date - timedelta(days=1)

    # 17:00 CST = 23:00 UTC
    cst_offset = timedelta(hours=-6)
    start_dt = datetime(
        prev_day.year, prev_day.month, prev_day.day,
        C.TRADING_START_HOUR_CST, 0, 0,
        tzinfo=timezone(cst_offset),
    )

    epoch_ms = int(start_dt.timestamp() * 1000)
    return epoch_ms


def get_hour_boundaries_ms(date_str: str, hour_index: int) -> tuple[int, int]:
    """
    Get the start and end epoch ms for a specific hour of the trading day.

    hour_index: 0-based index into the trading day (0 = hour 17 CST, 1 = 18, ...)
    Returns: (hour_start_ms, hour_end_ms) as absolute epoch milliseconds.
    """
    day_start = get_day_start_ms(date_str)
    hour_start = day_start + hour_index * C.MS_PER_HOUR
    hour_end = hour_start + C.MS_PER_HOUR
    return hour_start, hour_end


# ─────────────────────────────────────────────────────────────────────
# PARQUET READING
# ─────────────────────────────────────────────────────────────────────

def read_parquet_columns(
    path: str,
    columns: list[str],
) -> dict[str, np.ndarray]:
    """
    Read specific columns from a Parquet partition directory (or file).
    Returns a dict of column_name → numpy array.

    Uses PyArrow Dataset API for partition-aware reading.
    """
    logger.info(f"  Reading {len(columns)} columns from {path}")

    # Handle both single file and directory
    p = Path(path)
    if p.is_file():
        table = pq.read_table(str(p), columns=columns)
    elif p.is_dir():
        # Read all parquet files in the directory
        dataset = ds.dataset(str(p), format="parquet")
        table = dataset.to_table(columns=columns)
    else:
        raise FileNotFoundError(f"Path not found: {path}")

    logger.info(f"    Loaded {table.num_rows:,} rows")

    # Convert to numpy dict
    result = {}
    for col in columns:
        arr = table.column(col)
        result[col] = arr.to_numpy(zero_copy_only=False)

    return result


def stream_hour_batches(
    path: str,
    columns: list[str],
    ts_col: str,
    hour_start_ms: int,
    hour_end_ms: int,
    overlap_ms: int = C.HOUR_OVERLAP_MS,
    batch_size: int = 500_000,
) -> Iterator[pa.RecordBatch]:
    """
    Stream Parquet batches for a specific hour window with overlap.

    Uses PyArrow Dataset scanner with predicate pushdown on the
    timestamp column to skip irrelevant row groups.

    Yields RecordBatches within [hour_start_ms - overlap, hour_end_ms + overlap).
    """
    p = Path(path)
    if p.is_file():
        dataset = ds.dataset(str(p), format="parquet")
    elif p.is_dir():
        dataset = ds.dataset(str(p), format="parquet")
    else:
        raise FileNotFoundError(f"Path not found: {path}")

    # Predicate pushdown for timestamp range with overlap
    filter_expr = (
        (ds.field(ts_col) >= (hour_start_ms - overlap_ms)) &
        (ds.field(ts_col) < (hour_end_ms + overlap_ms))
    )

    scanner = dataset.scanner(
        columns=columns,
        filter=filter_expr,
        batch_size=batch_size,
    )

    for batch in scanner.to_batches():
        if batch.num_rows > 0:
            yield batch


def collect_hour_data(
    path: str,
    columns: list[str],
    ts_col: str,
    hour_start_ms: int,
    hour_end_ms: int,
    overlap_ms: int = C.HOUR_OVERLAP_MS,
    batch_size: int = 500_000,
) -> dict[str, np.ndarray]:
    """
    Collect all data for an hour window into numpy arrays.
    Convenience wrapper over stream_hour_batches that concatenates batches.
    """
    batches = list(stream_hour_batches(
        path, columns, ts_col, hour_start_ms, hour_end_ms,
        overlap_ms, batch_size,
    ))

    if not batches:
        # Return empty arrays
        return {col: np.array([], dtype=np.float64) for col in columns}

    table = pa.Table.from_batches(batches)

    result = {}
    for col in columns:
        result[col] = table.column(col).to_numpy(zero_copy_only=False)

    return result


# ─────────────────────────────────────────────────────────────────────
# PARQUET WRITING
# ─────────────────────────────────────────────────────────────────────

def write_parquet(
    table: pa.Table,
    output_path: str,
    config: Optional[PipelineConfig] = None,
) -> None:
    """
    Write a PyArrow Table to Parquet with standard settings.
    Creates parent directories if needed.
    """
    compression = config.compression if config else C.PARQUET_COMPRESSION
    row_group_size = config.row_group_size if config else C.PARQUET_ROW_GROUP_SIZE

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    pq.write_table(
        table,
        output_path,
        compression=compression,
        row_group_size=row_group_size,
        write_statistics=C.PARQUET_WRITE_STATISTICS,
        use_dictionary=False,
    )

    file_size_mb = Path(output_path).stat().st_size / (1024 * 1024)
    logger.info(f"  Wrote {table.num_rows:,} rows to {output_path} ({file_size_mb:.1f} MB)")


# ─────────────────────────────────────────────────────────────────────
# SCHEMA DEFINITIONS FOR OUTPUT PARQUET FILES
# ─────────────────────────────────────────────────────────────────────

def get_step2_schema() -> pa.Schema:
    """Schema for Step 2 output: event windows."""
    return pa.schema([
        ("event_ms", pa.int32()),
        ("hour", pa.int8()),
        ("offset", pa.int8()),
        ("mid_price", pa.float64()),
        ("bid_ask_spread", pa.float64()),
        ("level1_bid_depth", pa.float64()),
        ("level1_ask_depth", pa.float64()),
        ("level2_bid_depth", pa.float64()),
        ("level2_ask_depth", pa.float64()),
        ("vwap", pa.float64()),
        ("num_transactions", pa.float64()),
        ("aggressor_buy_vol", pa.float64()),
        ("aggressor_sell_vol", pa.float64()),
        ("swept_book", pa.float64()),
    ])


def get_step3_schema() -> pa.Schema:
    """Schema for Step 3 output: hourly percentiles."""
    return pa.schema([
        ("hour", pa.int8()),
        ("offset", pa.int8()),
        ("metric", pa.string()),
        ("p5", pa.float64()),
        ("p25", pa.float64()),
        ("p50", pa.float64()),
        ("p75", pa.float64()),
        ("p95", pa.float64()),
        ("n_events", pa.int32()),
    ])
