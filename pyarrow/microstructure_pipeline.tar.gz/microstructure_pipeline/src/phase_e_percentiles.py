"""
phase_e_percentiles.py
======================
Phase E: Compute hourly percentiles (P5, P25, P50, P75, P95) for each
metric at each window offset.

Input:  List of HourResult objects from Phase B-D
Output: PyArrow Table conforming to Step 3 schema
"""

from __future__ import annotations

import logging
import time

import numpy as np
import pyarrow as pa

from . import constants as C
from .io_utils import get_step3_schema
from .phase_bcd_process import HourResult

logger = logging.getLogger(__name__)


def compute_hourly_percentiles(
    hour_results: list[HourResult],
) -> pa.Table:
    """
    For each hour, for each offset, for each metric:
      Gather all event values → compute P5, P25, P50, P75, P95.

    Returns a PyArrow Table with schema:
      hour(int8), offset(int8), metric(string),
      p5, p25, p50, p75, p95 (float64), n_events(int32)
    """
    t0 = time.perf_counter()
    logger.info("[Phase E] Computing hourly percentiles ...")

    rows_hour = []
    rows_offset = []
    rows_metric = []
    rows_p5 = []
    rows_p25 = []
    rows_p50 = []
    rows_p75 = []
    rows_p95 = []
    rows_n_events = []

    percentile_levels = np.array(C.PERCENTILE_LEVELS, dtype=np.float64)

    for hr in hour_results:
        # hr.windows shape: (n_events, 14, 11)
        if hr.n_events == 0:
            # Still emit rows with NaN percentiles so schema is complete
            for offset_idx, offset_val in enumerate(C.WINDOW_OFFSETS):
                for metric_idx, metric_name in enumerate(C.ALL_METRICS):
                    rows_hour.append(hr.hour_cst)
                    rows_offset.append(offset_val)
                    rows_metric.append(metric_name)
                    rows_p5.append(np.nan)
                    rows_p25.append(np.nan)
                    rows_p50.append(np.nan)
                    rows_p75.append(np.nan)
                    rows_p95.append(np.nan)
                    rows_n_events.append(0)
            continue

        for offset_idx, offset_val in enumerate(C.WINDOW_OFFSETS):
            for metric_idx, metric_name in enumerate(C.ALL_METRICS):
                # Extract all event values for this offset + metric
                values = hr.windows[:, offset_idx, metric_idx]

                # Remove NaN values (from out-of-bounds offsets)
                valid = values[~np.isnan(values)]

                if len(valid) > 0:
                    pcts = np.percentile(valid, percentile_levels)
                    p5, p25, p50, p75, p95 = pcts
                    n = len(valid)
                else:
                    p5 = p25 = p50 = p75 = p95 = np.nan
                    n = 0

                rows_hour.append(hr.hour_cst)
                rows_offset.append(offset_val)
                rows_metric.append(metric_name)
                rows_p5.append(p5)
                rows_p25.append(p25)
                rows_p50.append(p50)
                rows_p75.append(p75)
                rows_p95.append(p95)
                rows_n_events.append(n)

    # Build PyArrow Table
    table = pa.table(
        {
            "hour": pa.array(rows_hour, type=pa.int8()),
            "offset": pa.array(rows_offset, type=pa.int8()),
            "metric": pa.array(rows_metric, type=pa.string()),
            "p5": pa.array(rows_p5, type=pa.float64()),
            "p25": pa.array(rows_p25, type=pa.float64()),
            "p50": pa.array(rows_p50, type=pa.float64()),
            "p75": pa.array(rows_p75, type=pa.float64()),
            "p95": pa.array(rows_p95, type=pa.float64()),
            "n_events": pa.array(rows_n_events, type=pa.int32()),
        },
        schema=get_step3_schema(),
    )

    elapsed = time.perf_counter() - t0
    logger.info(f"[Phase E] Complete in {elapsed:.2f}s  ({table.num_rows:,} rows)")

    return table


def build_step2_table(hour_results: list[HourResult]) -> pa.Table:
    """
    Flatten all hour results into a single Step 2 PyArrow Table.

    Each row represents one (event, offset) pair with all metric values.
    Schema: event_ms, hour, offset, mid_price, spread, ...
    """
    t0 = time.perf_counter()
    logger.info("[Phase E] Building Step 2 table from event windows ...")

    # Pre-compute total rows
    total_rows = sum(hr.n_events * C.NUM_OFFSETS for hr in hour_results)

    if total_rows == 0:
        logger.warning("  No events found — returning empty Step 2 table")
        from .io_utils import get_step2_schema
        return pa.table(
            {name: pa.array([], type=field.type)
             for name, field in zip(
                 get_step2_schema().names,
                 get_step2_schema()
             )},
            schema=get_step2_schema(),
        )

    # Pre-allocate arrays
    event_ms_arr = np.empty(total_rows, dtype=np.int32)
    hour_arr = np.empty(total_rows, dtype=np.int8)
    offset_arr = np.empty(total_rows, dtype=np.int8)
    metric_arrays = np.empty((C.NUM_METRICS, total_rows), dtype=np.float64)

    row = 0
    for hr in hour_results:
        if hr.n_events == 0:
            continue

        for e in range(hr.n_events):
            for k, offset_val in enumerate(C.WINDOW_OFFSETS):
                event_ms_arr[row] = hr.event_ms_indices[e]
                hour_arr[row] = hr.hour_cst
                offset_arr[row] = offset_val
                for m in range(C.NUM_METRICS):
                    metric_arrays[m, row] = hr.windows[e, k, m]
                row += 1

    # Build PyArrow arrays
    from .io_utils import get_step2_schema
    schema = get_step2_schema()

    columns = {
        "event_ms": pa.array(event_ms_arr, type=pa.int32()),
        "hour": pa.array(hour_arr, type=pa.int8()),
        "offset": pa.array(offset_arr, type=pa.int8()),
    }

    for m, metric_name in enumerate(C.ALL_METRICS):
        columns[metric_name] = pa.array(metric_arrays[m], type=pa.float64())

    table = pa.table(columns, schema=schema)

    elapsed = time.perf_counter() - t0
    logger.info(f"  Step 2 table: {table.num_rows:,} rows built in {elapsed:.2f}s")

    return table
