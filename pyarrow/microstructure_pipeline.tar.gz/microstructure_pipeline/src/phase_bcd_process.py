"""
phase_bcd_process.py
====================
Phases B, C, D: For each hour of the trading day, stream CLOB data,
build the millisecond timeline, compute metrics, and extract event windows.

This module processes one hour at a time (~1.2 GB per chunk) to keep
memory usage low. Carryover state flows from hour to hour for
forward-fill continuity.

Output: accumulated event windows (Step 2) and per-hour event lists
for percentile computation (Step 3).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

import numpy as np

from . import constants as C
from .config import PipelineConfig
from .io_utils import collect_hour_data, get_day_start_ms
from .phase_a_load import PhaseAResult
from .numba_kernels import (
    map_last_per_ms,
    forward_fill_1d,
    bucket_transactions,
    compute_book_metrics,
    gather_event_windows,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# CARRYOVER STATE (passed between hours for forward-fill continuity)
# ─────────────────────────────────────────────────────────────────────

@dataclass
class CarryoverState:
    """
    Book state at the end of an hour, carried to the next hour.
    One float64 per book column (40 values for 10 levels × 4 sides).
    """
    values: dict[str, float] = field(default_factory=dict)

    def get(self, col: str) -> float:
        """Get carryover value for a column, NaN if not yet set."""
        return self.values.get(col, np.nan)

    def update_from_arrays(self, arrays: dict[str, np.ndarray]) -> None:
        """Update carryover from the last valid values of each array."""
        for col, arr in arrays.items():
            if len(arr) > 0:
                self.values[col] = float(arr[-1])


# ─────────────────────────────────────────────────────────────────────
# HOUR RESULT (output of processing a single hour)
# ─────────────────────────────────────────────────────────────────────

@dataclass
class HourResult:
    """Result from processing one hour."""
    hour_cst: int              # Hour in CST (0–23)
    hour_index: int            # 0-based index in trading day
    n_events: int              # Number of transaction-ms in this hour
    event_ms_indices: np.ndarray   # int32: ms offsets of events (day-relative)
    windows: np.ndarray        # float64: (n_events, 14, 11) metric windows


# ─────────────────────────────────────────────────────────────────────
# PROCESS SINGLE HOUR
# ─────────────────────────────────────────────────────────────────────

def process_single_hour(
    hour_index: int,
    config: PipelineConfig,
    phase_a: PhaseAResult,
    carryover: CarryoverState,
) -> HourResult:
    """
    Process one hour of the trading day:
      B1. Load CLOB data for this hour (all 43 columns)
      B2. Filter transactions to this hour
      B3. Build ms timeline (3.6M slots) + forward fill
      B4. Bucket transactions into ms slots
      C.  Compute all 11 metrics
      D.  Find events + gather 14-offset windows

    Updates carryover state for the next hour.
    """
    hour_cst = C.HOUR_SEQUENCE_CST[hour_index]
    day_start_ms = phase_a.day_start_ms

    # Absolute ms boundaries for this hour
    hour_start_ms = day_start_ms + hour_index * C.MS_PER_HOUR
    hour_end_ms = hour_start_ms + C.MS_PER_HOUR

    # Relative ms boundaries within the full trading day
    slot_start = hour_index * C.MS_PER_HOUR
    slot_end = slot_start + C.MS_PER_HOUR
    n_slots = C.MS_PER_HOUR  # 3,600,000

    logger.debug(f"  Hour {hour_cst:02d}:00 CST (index {hour_index}): "
                 f"slots [{slot_start:,} .. {slot_end:,})")

    # ── B1. Load CLOB data for this hour ──────────────────────────
    clob_cols = [C.CLOB_SEQ_COL, C.CLOB_TS_COL] + C.CLOB_BOOK_COLS
    clob_hour = collect_hour_data(
        path=config.clob_path,
        columns=clob_cols,
        ts_col=C.CLOB_TS_COL,
        hour_start_ms=hour_start_ms,
        hour_end_ms=hour_end_ms,
        overlap_ms=C.HOUR_OVERLAP_MS,
        batch_size=config.batch_size,
    )

    clob_ts = clob_hour.get(C.CLOB_TS_COL, np.array([], dtype=np.int64))
    if clob_ts.dtype != np.int64:
        clob_ts = clob_ts.astype(np.int64)
    n_clob = clob_ts.shape[0]

    # ── B2. Filter transactions to this hour ──────────────────────
    txn_mask = (
        (phase_a.txn_ms_index >= slot_start) &
        (phase_a.txn_ms_index < slot_end)
    )
    hour_txn_ts = phase_a.txn_ts_ms[txn_mask]
    hour_txn_price = phase_a.txn_price[txn_mask]
    hour_txn_qty = phase_a.txn_qty[txn_mask]
    hour_txn_agg = phase_a.txn_aggressor[txn_mask]
    hour_txn_swept = phase_a.txn_swept[txn_mask]
    n_txn = hour_txn_ts.shape[0]

    logger.debug(f"    CLOB updates: {n_clob:,}  Transactions: {n_txn:,}")

    # ── B3. Build ms timeline + forward fill ──────────────────────
    # Map CLOB updates to ms slots (relative to hour start)
    slot_last_idx = map_last_per_ms(clob_ts, hour_start_ms, np.int64(n_slots))

    # Forward-fill each book column
    book_arrays = {}
    book_cols_needed = ["bid_px1", "ask_px1", "bid_sz1", "ask_sz1", "bid_sz2", "ask_sz2"]

    for col in book_cols_needed:
        raw = clob_hour.get(col, np.array([], dtype=np.float64))
        if raw.dtype != np.float64:
            raw = raw.astype(np.float64)

        initial = carryover.get(col)
        book_arrays[col] = forward_fill_1d(
            raw, slot_last_idx, np.int64(n_slots), np.float64(initial),
        )

    # Update carryover for next hour (use last slot values)
    for col in C.CLOB_BOOK_COLS:
        raw = clob_hour.get(col, np.array([], dtype=np.float64))
        if raw.dtype != np.float64:
            raw = raw.astype(np.float64)

        if col in book_cols_needed:
            # Already forward-filled; take last value
            carryover.values[col] = float(book_arrays[col][-1])
        elif len(raw) > 0:
            # For levels 3–10 (not used in metrics but maintain carryover)
            ff = forward_fill_1d(
                raw, slot_last_idx, np.int64(n_slots),
                np.float64(carryover.get(col)),
            )
            carryover.values[col] = float(ff[-1])

    # Free raw CLOB data
    del clob_hour

    # ── B4. Bucket transactions into ms slots ─────────────────────
    vwap, num_txn, buy_vol, sell_vol, swept = bucket_transactions(
        hour_txn_ts, hour_txn_price, hour_txn_qty,
        hour_txn_agg, hour_txn_swept,
        hour_start_ms, np.int64(n_slots),
    )

    # ── C. Compute order book metrics ─────────────────────────────
    mid, spread, l1_bid, l1_ask, l2_bid, l2_ask = compute_book_metrics(
        book_arrays["bid_px1"], book_arrays["ask_px1"],
        book_arrays["bid_sz1"], book_arrays["ask_sz1"],
        book_arrays["bid_sz2"], book_arrays["ask_sz2"],
    )

    # ── D. Stack all 11 metrics into (11, n_slots) array ──────────
    # Order must match ALL_METRICS in constants.py:
    # [mid_price, bid_ask_spread, l1_bid_depth, l1_ask_depth,
    #  l2_bid_depth, l2_ask_depth, vwap, num_transactions,
    #  aggressor_buy_vol, aggressor_sell_vol, swept_book]
    metric_stack = np.stack([
        mid,
        spread,
        l1_bid.copy(),  # copy because compute_book_metrics returns input refs
        l1_ask.copy(),
        l2_bid.copy(),
        l2_ask.copy(),
        vwap,
        num_txn.astype(np.float64),
        buy_vol,
        sell_vol,
        swept.astype(np.float64),
    ], axis=0)  # shape: (11, 3_600_000)

    # ── D. Find events and gather windows ─────────────────────────
    event_local_indices = np.where(num_txn > 0)[0].astype(np.int64)
    n_events = event_local_indices.shape[0]

    logger.debug(f"    Events (ms with trades): {n_events:,}")

    if n_events > 0:
        offsets = np.array(C.WINDOW_OFFSETS, dtype=np.int64)
        windows = gather_event_windows(
            event_local_indices, metric_stack, offsets, np.int64(n_slots),
        )
    else:
        windows = np.empty((0, C.NUM_OFFSETS, C.NUM_METRICS), dtype=np.float64)

    # Convert local ms indices to day-relative for output
    event_day_indices = (event_local_indices + slot_start).astype(np.int32)

    return HourResult(
        hour_cst=hour_cst,
        hour_index=hour_index,
        n_events=n_events,
        event_ms_indices=event_day_indices,
        windows=windows,
    )


# ─────────────────────────────────────────────────────────────────────
# PROCESS ALL HOURS
# ─────────────────────────────────────────────────────────────────────

def run_phases_bcd(
    config: PipelineConfig,
    phase_a: PhaseAResult,
) -> list[HourResult]:
    """
    Process all 23 hours of the trading day sequentially.
    Returns a list of HourResult objects (one per hour).
    """
    t0 = time.perf_counter()
    logger.info(f"[Phase B-D] Processing {C.TRADING_HOURS} hours ...")

    carryover = CarryoverState()
    hour_results = []
    total_events = 0

    for hour_idx in range(C.TRADING_HOURS):
        hr = process_single_hour(hour_idx, config, phase_a, carryover)
        hour_results.append(hr)
        total_events += hr.n_events

        if (hour_idx + 1) % 5 == 0 or hour_idx == C.TRADING_HOURS - 1:
            logger.info(f"  Processed {hour_idx + 1}/{C.TRADING_HOURS} hours "
                        f"({total_events:,} events so far)")

    elapsed = time.perf_counter() - t0
    logger.info(f"[Phase B-D] Complete in {elapsed:.2f}s  "
                f"({total_events:,} total events)")

    return hour_results
