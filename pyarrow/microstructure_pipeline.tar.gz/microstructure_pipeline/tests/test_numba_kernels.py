"""
test_numba_kernels.py
=====================
Unit tests for all Numba kernels.

Run:
  python -m pytest tests/test_numba_kernels.py -v
  python tests/test_numba_kernels.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.numba_kernels import (
    merge_interleave_indices,
    infer_aggressor_and_sweep,
    map_last_per_ms,
    forward_fill_1d,
    bucket_transactions,
    compute_book_metrics,
    gather_event_windows,
)


# ─────────────────────────────────────────────────────────────────
# MERGE INTERLEAVE
# ─────────────────────────────────────────────────────────────────

def test_merge_interleave_basic():
    """Merge two sorted seq arrays into one sorted stream."""
    clob_seq = np.array([10, 30, 50, 70], dtype=np.int64)
    txn_seq = np.array([20, 40, 60], dtype=np.int64)

    source, idx, seq = merge_interleave_indices(clob_seq, txn_seq)

    assert np.all(seq == [10, 20, 30, 40, 50, 60, 70])
    assert np.all(source == [0, 1, 0, 1, 0, 1, 0])  # 0=CLOB, 1=TXN
    assert np.all(idx == [0, 0, 1, 1, 2, 2, 3])
    print("  ✓ test_merge_interleave_basic")


def test_merge_equal_seqnums():
    """When seq_nums are equal, CLOB should come first."""
    clob_seq = np.array([10, 20, 30], dtype=np.int64)
    txn_seq = np.array([20, 30], dtype=np.int64)

    source, idx, seq = merge_interleave_indices(clob_seq, txn_seq)

    assert np.all(seq == [10, 20, 20, 30, 30])
    # At seq=20: CLOB (source=0) before TXN (source=1)
    assert source[1] == 0  # CLOB at seq 20
    assert source[2] == 1  # TXN at seq 20
    print("  ✓ test_merge_equal_seqnums")


def test_merge_with_gaps():
    """Sequence gaps should not affect interleaving."""
    clob_seq = np.array([10, 20, 40], dtype=np.int64)  # gap at 30
    txn_seq = np.array([30, 50], dtype=np.int64)

    source, _, seq = merge_interleave_indices(clob_seq, txn_seq)

    assert np.all(seq == [10, 20, 30, 40, 50])
    assert np.all(source == [0, 0, 1, 0, 1])
    print("  ✓ test_merge_with_gaps")


def test_merge_empty_txn():
    """Handle case where there are no transactions."""
    clob_seq = np.array([10, 20, 30], dtype=np.int64)
    txn_seq = np.array([], dtype=np.int64)

    source, idx, seq = merge_interleave_indices(clob_seq, txn_seq)

    assert len(seq) == 3
    assert np.all(source == 0)
    print("  ✓ test_merge_empty_txn")


# ─────────────────────────────────────────────────────────────────
# AGGRESSOR AND SWEEP DETECTION
# ─────────────────────────────────────────────────────────────────

def test_aggressor_and_sweep():
    """Test aggressor inference and sweep detection."""
    # Scenario:
    # CLOB 0: bid=100, ask=101
    # CLOB 1: bid=100, ask=101
    # TXN  0: price=101 (buy at ask, no sweep: price == ask)
    # CLOB 2: bid=100, ask=101
    # TXN  1: price=102 (buy above ask → sweep!)
    # CLOB 3: bid=100, ask=101
    # TXN  2: price=100 (sell at bid, no sweep: price == bid)
    # TXN  3: price=99  (sell below bid → sweep!)

    merged_source = np.array([0, 0, 1, 0, 1, 0, 1, 1], dtype=np.int8)
    merged_idx =    np.array([0, 1, 0, 2, 1, 3, 2, 3], dtype=np.int64)

    clob_bid = np.array([100.0, 100.0, 100.0, 100.0], dtype=np.float64)
    clob_ask = np.array([101.0, 101.0, 101.0, 101.0], dtype=np.float64)
    txn_price = np.array([101.0, 102.0, 100.0, 99.0], dtype=np.float64)

    aggressor, swept = infer_aggressor_and_sweep(
        merged_source, merged_idx, clob_bid, clob_ask, txn_price,
    )

    assert aggressor[0] == 1   # BUY (price >= ask)
    assert swept[0] == 0       # Not swept (price == ask, not >)

    assert aggressor[1] == 1   # BUY
    assert swept[1] == 1       # Swept (price > ask)

    assert aggressor[2] == -1  # SELL (price <= bid)
    assert swept[2] == 0       # Not swept (price == bid)

    assert aggressor[3] == -1  # SELL
    assert swept[3] == 1       # Swept (price < bid)

    print("  ✓ test_aggressor_and_sweep")


def test_aggressor_no_book_state():
    """Transaction before first CLOB update → UNKNOWN."""
    # TXN first, then CLOB, then TXN
    merged_source = np.array([1, 0, 1], dtype=np.int8)
    merged_idx =    np.array([0, 0, 1], dtype=np.int64)

    clob_bid = np.array([100.0], dtype=np.float64)
    clob_ask = np.array([101.0], dtype=np.float64)
    txn_price = np.array([101.0, 100.0], dtype=np.float64)

    aggressor, swept = infer_aggressor_and_sweep(
        merged_source, merged_idx, clob_bid, clob_ask, txn_price,
    )

    assert aggressor[0] == 0   # UNKNOWN (no book yet)
    assert swept[0] == 0
    assert aggressor[1] == -1  # SELL (has book state now)
    print("  ✓ test_aggressor_no_book_state")


def test_aggressor_mid_price_trade():
    """Trade between bid and ask → UNKNOWN aggressor."""
    merged_source = np.array([0, 1], dtype=np.int8)
    merged_idx =    np.array([0, 0], dtype=np.int64)

    clob_bid = np.array([100.0], dtype=np.float64)
    clob_ask = np.array([102.0], dtype=np.float64)
    txn_price = np.array([101.0], dtype=np.float64)  # between bid and ask

    aggressor, swept = infer_aggressor_and_sweep(
        merged_source, merged_idx, clob_bid, clob_ask, txn_price,
    )

    assert aggressor[0] == 0  # UNKNOWN
    assert swept[0] == 0
    print("  ✓ test_aggressor_mid_price_trade")


# ─────────────────────────────────────────────────────────────────
# MAP LAST PER MS
# ─────────────────────────────────────────────────────────────────

def test_map_last_per_ms():
    """Map CLOB updates to ms slots, keeping last per slot."""
    # day_start_ms = 100; Two updates at ms offset 2, one at offset 5
    clob_ts = np.array([102, 102, 105], dtype=np.int64)

    result = map_last_per_ms(clob_ts, np.int64(100), np.int64(8))

    assert result[0] == -1  # no update
    assert result[1] == -1
    assert result[2] == 1   # two at ms 2, last one (idx 1) wins
    assert result[3] == -1
    assert result[4] == -1
    assert result[5] == 2   # one update (idx 2)
    print("  ✓ test_map_last_per_ms")


# ─────────────────────────────────────────────────────────────────
# FORWARD FILL
# ─────────────────────────────────────────────────────────────────

def test_forward_fill_with_carryover():
    """Forward fill with carryover from previous chunk."""
    source = np.array([10.0, 20.0], dtype=np.float64)
    slot_idx = np.array([-1, -1, 0, -1, 1, -1], dtype=np.int64)

    result = forward_fill_1d(source, slot_idx, np.int64(6), np.float64(5.0))

    expected = [5.0, 5.0, 10.0, 10.0, 20.0, 20.0]
    assert np.allclose(result, expected)
    print("  ✓ test_forward_fill_with_carryover")


def test_forward_fill_nan_carryover():
    """Forward fill with NaN carryover (start of day, no prior data)."""
    source = np.array([10.0], dtype=np.float64)
    slot_idx = np.array([-1, -1, 0], dtype=np.int64)

    result = forward_fill_1d(source, slot_idx, np.int64(3), np.float64(np.nan))

    assert np.isnan(result[0])
    assert np.isnan(result[1])
    assert result[2] == 10.0
    print("  ✓ test_forward_fill_nan_carryover")


# ─────────────────────────────────────────────────────────────────
# BUCKET TRANSACTIONS
# ─────────────────────────────────────────────────────────────────

def test_bucket_transactions():
    """Bucket transactions with VWAP, counts, aggressor, sweep."""
    # day_start_ms = 0
    txn_ts    = np.array([1, 1, 3, 5], dtype=np.int64)
    txn_price = np.array([100.0, 102.0, 101.0, 100.0], dtype=np.float64)
    txn_qty   = np.array([10.0, 20.0, 5.0, 15.0], dtype=np.float64)
    txn_agg   = np.array([1, 1, -1, -1], dtype=np.int8)
    txn_swept = np.array([0, 1, 0, 0], dtype=np.int8)

    vwap, num_txn, buy_vol, sell_vol, swept = bucket_transactions(
        txn_ts, txn_price, txn_qty, txn_agg, txn_swept,
        np.int64(0), np.int64(7),
    )

    # ms 0: no trades
    assert np.isnan(vwap[0])
    assert num_txn[0] == 0

    # ms 1: 2 trades — VWAP = (100*10 + 102*20) / 30 = 101.333...
    assert num_txn[1] == 2
    assert abs(vwap[1] - 101.333333) < 0.001
    assert buy_vol[1] == 30.0
    assert sell_vol[1] == 0.0
    assert swept[1] == 1  # one trade was a sweep

    # ms 3: 1 sell trade
    assert num_txn[3] == 1
    assert vwap[3] == 101.0
    assert sell_vol[3] == 5.0
    assert swept[3] == 0

    print("  ✓ test_bucket_transactions")


# ─────────────────────────────────────────────────────────────────
# BOOK METRICS
# ─────────────────────────────────────────────────────────────────

def test_compute_book_metrics():
    """Mid-price and spread computation."""
    bid = np.array([100.0, 101.0, 99.5], dtype=np.float64)
    ask = np.array([101.0, 102.0, 100.5], dtype=np.float64)
    sz = np.array([10.0, 20.0, 30.0], dtype=np.float64)

    mid, spread, l1b, l1a, l2b, l2a = compute_book_metrics(
        bid, ask, sz, sz, sz, sz,
    )

    assert np.allclose(mid, [100.5, 101.5, 100.0])
    assert np.allclose(spread, [1.0, 1.0, 1.0])
    # Depth arrays should pass through unchanged
    assert np.allclose(l1b, sz)
    assert np.allclose(l1a, sz)
    print("  ✓ test_compute_book_metrics")


# ─────────────────────────────────────────────────────────────────
# GATHER EVENT WINDOWS
# ─────────────────────────────────────────────────────────────────

def test_gather_event_windows():
    """Gather metric values at offsets around events."""
    n_slots = 10
    n_metrics = 2
    metrics = np.arange(n_metrics * n_slots, dtype=np.float64).reshape(
        n_metrics, n_slots,
    )
    # metrics[0] = [0,1,2,3,4,5,6,7,8,9]
    # metrics[1] = [10,11,12,13,14,15,16,17,18,19]

    events = np.array([3, 7], dtype=np.int64)
    offsets = np.array([-1, 0, 1], dtype=np.int64)

    windows = gather_event_windows(events, metrics, offsets, np.int64(n_slots))

    # Event at ms=3, offsets [-1, 0, 1] → ms [2, 3, 4]
    assert windows[0, 0, 0] == 2.0   # metric 0, ms 2
    assert windows[0, 1, 0] == 3.0   # metric 0, ms 3
    assert windows[0, 2, 0] == 4.0   # metric 0, ms 4
    assert windows[0, 0, 1] == 12.0  # metric 1, ms 2

    # Event at ms=7, offset +1 → ms 8
    assert windows[1, 2, 0] == 8.0
    print("  ✓ test_gather_event_windows")


def test_gather_boundary():
    """Window offsets beyond array bounds should be NaN."""
    metrics = np.ones((1, 5), dtype=np.float64)
    events = np.array([0, 4], dtype=np.int64)
    offsets = np.array([-1, 0, 1], dtype=np.int64)

    windows = gather_event_windows(events, metrics, offsets, np.int64(5))

    # Event at ms=0, offset -1 → out of bounds → NaN
    assert np.isnan(windows[0, 0, 0])
    assert windows[0, 1, 0] == 1.0

    # Event at ms=4, offset +1 → out of bounds → NaN
    assert np.isnan(windows[1, 2, 0])
    assert windows[1, 1, 0] == 1.0
    print("  ✓ test_gather_boundary")


# ─────────────────────────────────────────────────────────────────
# RUNNER
# ─────────────────────────────────────────────────────────────────

def run_all_tests():
    print("\nRunning Numba kernel unit tests...\n")

    test_merge_interleave_basic()
    test_merge_equal_seqnums()
    test_merge_with_gaps()
    test_merge_empty_txn()
    test_aggressor_and_sweep()
    test_aggressor_no_book_state()
    test_aggressor_mid_price_trade()
    test_map_last_per_ms()
    test_forward_fill_with_carryover()
    test_forward_fill_nan_carryover()
    test_bucket_transactions()
    test_compute_book_metrics()
    test_gather_event_windows()
    test_gather_boundary()

    print("\n✅ All 14 kernel tests passed.\n")


if __name__ == "__main__":
    run_all_tests()
