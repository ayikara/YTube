"""
generate_synthetic_data.py
==========================
Generate synthetic CLOB and transaction Parquet files for testing.

Creates realistic data with:
  - Shared seq_num between CLOB and transactions (with gaps for cancels)
  - 10-level order book with price/size structure
  - Transactions at BBO and sweeps through level 1
  - Timestamps spanning a full CME trading day (23 hours)

Usage:
  python -m tests.generate_synthetic_data --products ES NQ --date 2024-01-15

From code:
  from tests.generate_synthetic_data import generate_day
  generate_day("ES", "2024-01-15", data_root="./data")
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

# Add parent to path so we can import src
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import constants as C
from src.io_utils import get_day_start_ms


def generate_day(
    product: str = "ES",
    date: str = "2024-01-15",
    data_root: str = "./data",
    num_clob_updates: int = 500_000,
    num_transactions: int = 20_000,
    base_price: float = 5000.0,
    tick_size: float = 0.25,
    seed: int = 42,
) -> dict:
    """
    Generate one day of synthetic CLOB and transaction data.

    Returns dict with paths and summary stats.
    """
    rng = np.random.default_rng(seed)
    day_start_ms = get_day_start_ms(date)

    # ── Generate sequence numbers ─────────────────────────────────
    # Total messages includes CLOB + transactions; ~20% gaps for cancels
    total_messages = num_clob_updates + num_transactions
    max_seq = int(total_messages * 1.2)
    all_seqs = np.sort(
        rng.choice(max_seq, size=total_messages, replace=False)
    ).astype(np.int64) + 1000  # offset to avoid seq=0

    # Assign: some are CLOB updates, rest are transactions
    is_txn = np.zeros(total_messages, dtype=bool)
    txn_positions = rng.choice(total_messages, size=num_transactions, replace=False)
    is_txn[txn_positions] = True

    clob_seqs = all_seqs[~is_txn]
    txn_seqs = all_seqs[is_txn]

    # ── Generate timestamps ───────────────────────────────────────
    # Map sequence position to time proportionally across the trading day
    clob_frac = np.searchsorted(all_seqs, clob_seqs) / total_messages
    txn_frac = np.searchsorted(all_seqs, txn_seqs) / total_messages

    clob_ts = (day_start_ms + clob_frac * C.MS_PER_TRADING_DAY).astype(np.int64)
    txn_ts = (day_start_ms + txn_frac * C.MS_PER_TRADING_DAY).astype(np.int64)

    # ── Generate order book data (10 levels) ──────────────────────
    n_clob = len(clob_seqs)

    # Random walk for mid-price
    mid_changes = rng.choice(
        [-tick_size, 0, 0, 0, tick_size],
        size=n_clob,
    )
    mid_prices = base_price + np.cumsum(mid_changes)

    book_arrays = {}
    for lvl in range(1, C.BOOK_DEPTH + 1):
        offset = (lvl - 1) * tick_size
        half_spread = tick_size  # 1-tick spread at BBO

        book_arrays[f"bid_px{lvl}"] = mid_prices - half_spread - offset
        book_arrays[f"ask_px{lvl}"] = mid_prices + half_spread + offset

        # Sizes: level 1 has most liquidity, decreasing with depth
        base_sz = max(1, 100 // lvl)
        book_arrays[f"bid_sz{lvl}"] = rng.integers(
            max(1, base_sz // 2), base_sz * 2, size=n_clob
        ).astype(np.float64)
        book_arrays[f"ask_sz{lvl}"] = rng.integers(
            max(1, base_sz // 2), base_sz * 2, size=n_clob
        ).astype(np.float64)

    # ── Generate transactions ─────────────────────────────────────
    n_txn = len(txn_seqs)

    # For each transaction, find the most recent CLOB update
    clob_idx_for_txn = np.searchsorted(clob_seqs, txn_seqs, side="right") - 1
    clob_idx_for_txn = np.clip(clob_idx_for_txn, 0, n_clob - 1)

    bbo_bid = book_arrays["bid_px1"][clob_idx_for_txn]
    bbo_ask = book_arrays["ask_px1"][clob_idx_for_txn]

    # Trade prices: ~45% buy at ask, ~45% sell at bid, ~5% buy sweep, ~5% sell sweep
    trade_prices = np.empty(n_txn, dtype=np.float64)
    trade_qty = rng.integers(1, 50, size=n_txn).astype(np.float64)

    for i in range(n_txn):
        r = rng.random()
        if r < 0.45:
            trade_prices[i] = bbo_ask[i]           # Buy at ask (no sweep)
        elif r < 0.90:
            trade_prices[i] = bbo_bid[i]           # Sell at bid (no sweep)
        elif r < 0.95:
            trade_prices[i] = bbo_ask[i] + tick_size * rng.integers(1, 4)  # Buy sweep
        else:
            trade_prices[i] = bbo_bid[i] - tick_size * rng.integers(1, 4)  # Sell sweep

    # ── Write CLOB Parquet ────────────────────────────────────────
    clob_dir = Path(data_root) / C.PipelineConfig_CLOB_SUBDIR(data_root) if False else \
        Path(data_root) / "raw" / "clob" / f"date={date}" / f"product={product}"
    clob_dir.mkdir(parents=True, exist_ok=True)

    clob_data = {
        C.CLOB_SEQ_COL: clob_seqs,
        C.CLOB_TS_COL: clob_ts,
    }
    clob_data.update({k: v.astype(np.float64) for k, v in book_arrays.items()})

    clob_table = pa.table(clob_data)
    clob_path = str(clob_dir / "part-00000.parquet")
    pq.write_table(
        clob_table, clob_path,
        compression=C.PARQUET_COMPRESSION,
        row_group_size=C.PARQUET_ROW_GROUP_SIZE,
        write_statistics=True,
    )

    # ── Write Transaction Parquet ─────────────────────────────────
    txn_dir = Path(data_root) / "raw" / "transactions" / f"date={date}" / f"product={product}"
    txn_dir.mkdir(parents=True, exist_ok=True)

    txn_table = pa.table({
        C.TXN_SEQ_COL: txn_seqs,
        C.TXN_TS_COL: txn_ts,
        C.TXN_PRICE_COL: trade_prices,
        C.TXN_QTY_COL: trade_qty,
    })
    txn_path = str(txn_dir / "part-00000.parquet")
    pq.write_table(
        txn_table, txn_path,
        compression=C.PARQUET_COMPRESSION,
        row_group_size=C.PARQUET_ROW_GROUP_SIZE,
        write_statistics=True,
    )

    # ── Summary ───────────────────────────────────────────────────
    n_sweeps = int(np.sum(
        (trade_prices > bbo_ask) | (trade_prices < bbo_bid)
    ))

    clob_mb = Path(clob_path).stat().st_size / (1024 * 1024)
    txn_mb = Path(txn_path).stat().st_size / (1024 * 1024)

    print(f"  Generated {product}/{date}:")
    print(f"    CLOB updates : {n_clob:>10,}  ({clob_mb:.1f} MB)")
    print(f"    Transactions : {n_txn:>10,}  ({txn_mb:.1f} MB)")
    print(f"    Sweeps       : {n_sweeps:>10,} ({100 * n_sweeps / n_txn:.1f}%)")
    print(f"    Seq range    : {all_seqs[0]:,} → {all_seqs[-1]:,}")
    print(f"    Gaps (approx): {max_seq - total_messages:,}")
    print(f"    CLOB path    : {clob_dir}")
    print(f"    TXN path     : {txn_dir}")

    return {
        "clob_dir": str(clob_dir),
        "txn_dir": str(txn_dir),
        "n_clob": n_clob,
        "n_txn": n_txn,
        "n_sweeps": n_sweeps,
    }


def main():
    parser = argparse.ArgumentParser(description="Generate synthetic test data")
    parser.add_argument("--products", nargs="+", default=["ES", "NQ"])
    parser.add_argument("--date", default="2024-01-15")
    parser.add_argument("--data-root", default="./data")
    parser.add_argument("--num-clob", type=int, default=500_000)
    parser.add_argument("--num-txn", type=int, default=20_000)
    args = parser.parse_args()

    print("Generating synthetic data...")
    print(f"  Data root: {Path(args.data_root).resolve()}")
    print()

    for product in args.products:
        generate_day(
            product=product,
            date=args.date,
            data_root=args.data_root,
            num_clob_updates=args.num_clob,
            num_transactions=args.num_txn,
            seed=42 + hash(product) % 1000,
        )
        print()

    print("Done.")


if __name__ == "__main__":
    main()
