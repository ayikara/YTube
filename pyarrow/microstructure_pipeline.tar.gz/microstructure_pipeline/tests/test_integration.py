"""
test_integration.py
===================
End-to-end integration test: generate synthetic data → run pipeline
→ validate outputs.

Run:
  python tests/test_integration.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import constants as C
from src.config import PipelineConfig
from src.daily_pipeline import run_daily_pipeline, setup_logging
from tests.generate_synthetic_data import generate_day


def test_full_pipeline():
    """Run the complete pipeline on synthetic data and validate outputs."""
    data_root = "./data_test"
    product = "ES"
    date = "2024-01-15"

    # ── Step 1: Generate synthetic data ──────────────────────────
    print("=" * 60)
    print("INTEGRATION TEST: Full Pipeline")
    print("=" * 60)

    print("\n[1] Generating synthetic data...")
    gen_result = generate_day(
        product=product,
        date=date,
        data_root=data_root,
        num_clob_updates=50_000,   # smaller for fast test
        num_transactions=2_000,
        seed=42,
    )

    # ── Step 2: Run pipeline ─────────────────────────────────────
    print("\n[2] Running daily pipeline...")
    config = PipelineConfig(
        data_root=data_root,
        product=product,
        date=date,
    )

    setup_logging(verbose=False)
    summary = run_daily_pipeline(config)

    # ── Step 3: Validate outputs ─────────────────────────────────
    print("\n[3] Validating outputs...")
    errors = []

    # Check summary
    assert summary["product"] == product
    assert summary["date"] == date
    assert summary["n_trades"] > 0, "Should have trades"
    assert summary["n_events"] > 0, "Should have events"
    print(f"  Summary: {summary['n_trades']} trades, {summary['n_events']} events")

    # ── Validate Step 2 output ────────────────────────────────────
    step2_path = config.step2_output_path
    assert Path(step2_path).exists(), f"Step 2 file missing: {step2_path}"

    step2 = pq.read_table(step2_path)
    print(f"  Step 2: {step2.num_rows:,} rows, {step2.num_columns} columns")

    # Should have expected columns
    expected_cols = {"event_ms", "hour", "offset"} | set(C.ALL_METRICS)
    actual_cols = set(step2.schema.names)
    missing = expected_cols - actual_cols
    if missing:
        errors.append(f"Step 2 missing columns: {missing}")

    # Every event should produce exactly 14 rows (one per offset)
    if step2.num_rows > 0:
        n_events_from_rows = step2.num_rows / C.NUM_OFFSETS
        if n_events_from_rows != int(n_events_from_rows):
            errors.append(f"Step 2 row count {step2.num_rows} not divisible by {C.NUM_OFFSETS}")

        # Check offset values
        offsets = step2.column("offset").to_numpy()
        unique_offsets = sorted(set(offsets.tolist()))
        if unique_offsets != C.WINDOW_OFFSETS:
            errors.append(f"Step 2 offsets {unique_offsets} != expected {C.WINDOW_OFFSETS}")

        # Check hour values are valid CST hours
        hours = step2.column("hour").to_numpy()
        for h in set(hours.tolist()):
            if h not in C.HOUR_SEQUENCE_CST:
                errors.append(f"Step 2 invalid hour: {h}")

        # Mid price should be reasonable (not NaN for offset=0 rows)
        offset_0_mask = offsets == 0
        mid_at_event = step2.column("mid_price").to_numpy()[offset_0_mask]
        if np.all(np.isnan(mid_at_event)):
            errors.append("Step 2: all mid_price values are NaN at offset 0")
        else:
            print(f"  Step 2 mid_price range at t=0: "
                  f"[{np.nanmin(mid_at_event):.2f}, {np.nanmax(mid_at_event):.2f}]")

        # num_transactions at offset=0 should all be > 0
        ntx_at_event = step2.column("num_transactions").to_numpy()[offset_0_mask]
        if np.any(ntx_at_event == 0):
            errors.append("Step 2: some events have 0 transactions at offset 0")

    # ── Validate Step 3 output ────────────────────────────────────
    step3_path = config.step3_output_path
    assert Path(step3_path).exists(), f"Step 3 file missing: {step3_path}"

    step3 = pq.read_table(step3_path)
    print(f"  Step 3: {step3.num_rows:,} rows, {step3.num_columns} columns")

    # Expected rows: 23 hours × 14 offsets × 11 metrics = 3,542
    expected_step3_rows = C.TRADING_HOURS * C.NUM_OFFSETS * C.NUM_METRICS
    if step3.num_rows != expected_step3_rows:
        errors.append(
            f"Step 3 rows: {step3.num_rows} != expected {expected_step3_rows}"
        )

    # Check that at least some percentiles are non-NaN
    p50 = step3.column("p50").to_numpy()
    n_valid = int(np.sum(~np.isnan(p50)))
    print(f"  Step 3: {n_valid}/{len(p50)} P50 values are non-NaN")
    if n_valid == 0:
        errors.append("Step 3: all P50 values are NaN")

    # P25 <= P50 <= P75 where all are non-NaN
    p25 = step3.column("p25").to_numpy()
    p75 = step3.column("p75").to_numpy()
    valid = ~np.isnan(p25) & ~np.isnan(p50) & ~np.isnan(p75)
    if np.any(valid):
        if np.any(p25[valid] > p50[valid] + 1e-10):
            errors.append("Step 3: some P25 > P50")
        if np.any(p50[valid] > p75[valid] + 1e-10):
            errors.append("Step 3: some P50 > P75")

    # ── Report ────────────────────────────────────────────────────
    print()
    if errors:
        print(f"❌ FAILED with {len(errors)} error(s):")
        for e in errors:
            print(f"   - {e}")
        return False
    else:
        print("✅ All integration checks passed.")
        return True


if __name__ == "__main__":
    success = test_full_pipeline()
    sys.exit(0 if success else 1)
